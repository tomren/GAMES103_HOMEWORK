# GAMES103 Lab1
ren zhixiong

## 完成内容
1. 完成 Basic Tasks， 实现 Impulse 算法
2. 完成 Bonus Tasks， 实现 Shape Matching 算法

# 1. Basic Tasks
1. 在 Impulse 算法中，当物体移动相对平稳后，通过 punish_threshold 阈值将小量移动和转动逐渐惩罚到 0 值
2. 通过 collision_type 变量控制使用 Impulse 或 Penalty 算法
3. 练习了 Penalty 算法，参数难调节，效果不理想 (log_barrier_flag 标记是否使用 log barrier)
4. 与 Impulse 相比 Penalty 需要使用更小的步长防止模型穿透墙面和地面
<table border="0">
	<tr>
		<td align='center'>Impulse 算法</td>
	</tr>
	<tr>
		<td align='center'><img src='./images/impulse.gif' width='100%' hight='100%'/></td>
	</tr>
	<tr>
		<td align='center'>Penalty 算法</td>
	</tr>
	<tr>
		<td align='center'><img src='./images/penalty.gif' width='100%' hight='100%'/></td>
	</tr>
</table>

## 2. Bonus Tasks
1. 实现 Shape Matching 算法
<table border="0">
    <tr>
		<td align='center'><img src='./images/shape_matching.gif' width='100%' hight='100%'/></td>
	</tr>
</table>
