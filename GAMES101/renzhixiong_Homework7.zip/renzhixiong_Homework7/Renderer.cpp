//
// Created by goksu on 2/25/20.
//

#include <fstream>
#include <optional>
#include <unistd.h>
#include <pthread.h>
#include <omp.h>
#include "Scene.hpp"
#include "Renderer.hpp"

const float EPSILON = 0.00001f;

// =========================
// 渲染线程使用的数据
// =========================
typedef struct RenderThreadData
{
    Renderer*   renderer;
    const Scene*scene;
    Vector3f*   framebuffer;

    uint32_t    beginHeight;
    uint32_t    endHeight;

    int32_t     subPixNum;
    float       subPixStep;
    float       renderInvSPP;
    float       imageAspectRatio;
    float       scale;
    Vector3f    eye_pos;
}RenderThreadData;

inline float deg2rad(const float& deg) { return deg * M_PI / 180.0; }

// =========================
// 渲染线程
// =========================
void* render_thread(void* userData)
{
    RenderThreadData* data = (RenderThreadData*)userData;
    if (nullptr == data)
    {
        return nullptr;
    }

    Renderer* renderer = data->renderer;
    const Scene* scene = data->scene;
    Vector3f color;
    IsectBuilder isectBuilder;

    do
    {
        Ray ray(data->eye_pos, Vector3f(0.f, 0.f, 0.f));
        for (uint32_t j = data->beginHeight, idx = data->beginHeight * scene->width; j < data->endHeight; ++j)
        {
            for (uint32_t i = 0; i < scene->width; ++i)
            {
                // 在同一个像素区域内随机采样，避免集中同一点产生的锯齿
                for (int row = 1; row <= data->subPixNum; ++row)
                {
                    for (int col = 1; col <= data->subPixNum; ++col)
                    {
                        // 在同一个像素区域内随机采样，避免集中同一点产生的锯齿
                        float x = (2 * (i + col*data->subPixStep) / (float)scene->width - 1) * data->imageAspectRatio * data->scale;
                        float y = (1 - 2 * (j + row*data->subPixStep) / (float)scene->height) * data->scale;

                        ray.setDir(-x, y, 1);
                        scene->castRay(isectBuilder, ray, 0, color);
                        data->framebuffer[idx] += color * data->renderInvSPP;
                    }
                }
                ++idx;
            }

            renderer->IncRenderCount(scene->width);
        }
    }while(false);

    delete data;

    return nullptr;
}

// The main render function. This where we iterate over all pixels in the image,
// generate primary rays and cast these rays into the scene. The content of the
// framebuffer is saved to a file.
void Renderer::Render(const Scene& scene)
{
    Vector3f* framebuffer = new Vector3f[scene.width * scene.height];
    Vector3f eye_pos(278, 273, -800);
    float scale = tan(deg2rad(scene.fov * 0.5));

    // change the spp value to change sample ammount
    std::cout << "SPP: " << SPP << "\n";

    int32_t subPixNum = sqrtf(SPP);
    int32_t renderSPP = subPixNum * subPixNum;
    if (renderSPP < SPP) { ++subPixNum; }
    float renderInvSPP = 1.f / renderSPP;
    float subPixStep = 1.f / (subPixNum + 2);

// 使用多线程
#if MUTIL_THREAD
    float halfWidth = (float)scene.width * 0.5f;
    float halfHeight = (float)scene.height * 0.5f;
    float heightScale = 2.0f / (float)scene.height * scale;
    float imageAspectRatio = scene.width / (float)scene.height;

    mBufferCount = scene.height * scene.width;  // 设置 IsOk 计数
    pthread_t thandle[THREAD_COUNT];
    RenderThreadData* threadData[THREAD_COUNT];

    uint32_t segmentLen  = scene.height / THREAD_COUNT;
    uint32_t idx = 0;

    for (int i = 0; i < THREAD_COUNT; ++i)
    {
        RenderThreadData*& data = threadData[i];
        data = new RenderThreadData();
        data->renderer      = this;
        data->scene         = &scene;
        data->framebuffer   = framebuffer;

        // -------------------------
        data->beginHeight   = idx;          // 每个线程的起始高度
        // 绘制区间
        if (0 == idx)
        {
            idx += scene.height - segmentLen * (THREAD_COUNT - 1);
        }
        else
        {
            idx += segmentLen;
        }
        data->endHeight     = idx;          // 结束高度
        // -------------------------
        data->subPixNum     = subPixNum;
        data->subPixStep    = subPixStep;
        data->renderInvSPP  = renderInvSPP;
        data->imageAspectRatio = imageAspectRatio;
        data->scale         = scale;
        data->eye_pos       = eye_pos;

        if (-1 == (pthread_create(&thandle[i], nullptr, render_thread, (void*)threadData[i])))
        {
            std::cout << "Create pthread:% " << i << " failed." << std::endl;
        }
    }

    while(!IsOk())
    {
        usleep(10);
    }
#else   // 不开启线程
    Vector3f color;
    IsectBuilder isectBuilder;
    int m = 0;
    for (uint32_t j = 0; j < scene.height; ++j)
    {
        for (uint32_t i = 0; i < scene.width; ++i)
        {
            // generate primary ray direction
            //float x = (2 * (i + 0.5) / (float)scene.width - 1) * imageAspectRatio * scale;
            //float y = (1 - 2 * (j + 0.5) / (float)scene.height) * scale;
            for (int row = 1; row <= subPixNum; ++row)
            {
                for (int col = 1; col <= subPixNum; ++col)
                {
                    // 在同一个像素区域内随机采样，避免集中同一点产生的锯齿
                    float x = (2 * (i + col*subPixStep) / (float)scene.width - 1) * imageAspectRatio * scale;
                    float y = (1 - 2 * (j + row*subPixStep) / (float)scene.height) * scale;
                    Vector3f dir = Vector3f(-x, y, 1);
                    normalize(dir);
                    scene.castRay(isectBuilder, Ray(eye_pos, dir), 0, color);
                    framebuffer[m] += color * renderInvSPP;
                }
            }
            ++m;
        }

        if (0 == (j % 10))
        {
            UpdateProgress(j / (float)scene.height);
        }
    }
    UpdateProgress(1.f);
#endif

    // save framebuffer to file
    SaveImage("binary.ppm", framebuffer, scene.width, scene.height);

    delete framebuffer;
}

// =========================
// 单线程保存图像
// =========================
bool Renderer::SaveImage(const char* path, const Vector3f* buffer, int32_t width, int32_t height)
{
    FILE* fp = fopen(path, "wb");
    if (nullptr == fp)
    {
        return false;
    }

    (void)fprintf(fp, "P6\n%d %d\n255\n", width, height);
    int32_t len = height * width;
    for (int32_t i = 0; i < len; ++i)
    {
        static unsigned char color[3];
        color[0] = (unsigned char)(255 * std::pow(clamp(0, 1, buffer[i].x), 0.6f));
        color[1] = (unsigned char)(255 * std::pow(clamp(0, 1, buffer[i].y), 0.6f));
        color[2] = (unsigned char)(255 * std::pow(clamp(0, 1, buffer[i].z), 0.6f));
        fwrite(color, 1, 3, fp);
    }

    fclose(fp);
    return true;
}
