## 完成内容

- 完成 Path Tracing  算法
- 完成 多线程
- 完成 Microfacet  材质


## 其他优化

- 只实例化一个 get_random_float 中的随机函数对象，大幅提升渲染时间
- SPP 采样时，随机像素点范围内随机采样，消除锯齿
- 预计算 emit 物体的总面积，采样时只遍历 emit 物体列表

```c++
global.hpp 添加新的定义

// 是否使用多线程 0:不使用, 1:使用
#define MUTIL_THREAD 1
// 线程数量
#define THREAD_COUNT 5
// 采样数
#define SPP 16
const float INV_SPP = 1.f / (float)(SPP);
```

```c++
Material.hpp

扩充微表面使用的材料类
enum MaterialType { DIFFUSE, GLOSSY };

添加微表面用到的函数
    inline float fresnelSchlick(const Vector3f& wi, const Vector3f &N);
    inline float geometryShadowing(const Vector3f& l, const Vector3f &v,
                                   const Vector3f& n, const Vector3f &h);
    inline float distributionGGX(const Vector3f& n, const Vector3f &h, float a);
```
#### 采样方法补充
1. 多线程使用像素点内随机采样
2. 单线程使用方形阵列采样
## 样例

### Path Tracing 
#### {CornellBox} 有锯齿 SPP2048
![](images\spp2048.png) 

#### {CornellBox} 无锯齿 SPP2048
![](images\mx2048.png)

#### {bunny} SPP2048
![](images\by2048.png)

### 微表面 SPP2048
![](images\xby2048.png)
![](images\bby2048.png)

### 单线程时间
![](images\single_thread.png)

### 多线程时间

![](images\mutil_thread.png)