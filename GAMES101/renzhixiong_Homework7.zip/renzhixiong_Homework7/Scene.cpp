//
// Created by Göksu Güvendiren on 2019-05-14.
//

#include "Scene.hpp"

void Scene::buildBVH()
{
    printf(" - Generating BVH...\n\n");
    this->bvh = new BVHAccel(objects, 1, BVHAccel::SplitMethod::NAIVE);
}

Intersection* Scene::intersect(IsectBuilder& isectBuilder, const Ray &ray) const
{
    return bvh->Intersect(isectBuilder, ray);
}

void Scene::sampleLight(Intersection &pos, float &pdf) const
{
//    float emit_area_sum = 0;
//    for (uint32_t k = 0; k < objects.size(); ++k) {
//        if (objects[k]->hasEmit()){
//            emit_area_sum += objects[k]->getArea();
//        }
//    }
    float p = get_random_float() * emitAreaSum;
    float emit_area_sum = 0.f;

    for (uint32_t k = 0; k < emitObjs.size(); ++k)
    {
        emit_area_sum += emitObjs[k]->getArea();
        if (p <= emit_area_sum)
        {
            emitObjs[k]->Sample(pos, pdf);
            break;
        }
    }
}

bool Scene::trace(
        const Ray &ray,
        const std::vector<Object*> &objects,
        float &tNear, uint32_t &index, Object **hitObject)
{
    *hitObject = nullptr;
    for (uint32_t k = 0; k < objects.size(); ++k) {
        float tNearK = kInfinity;
        uint32_t indexK;
        Vector2f uvK;
        if (objects[k]->intersect(ray, tNearK, indexK) && tNearK < tNear) {
            *hitObject = objects[k];
            tNear = tNearK;
            index = indexK;
        }
    }

    return (*hitObject != nullptr);
}

// Implementation of Path Tracing
void Scene::castRay(IsectBuilder& isectBuilder, const Ray &ray, int depth, Vector3f& color) const
{
    color = backgroundColor;

    // TODO Implement Path Tracing Algorithm here
    if (depth > maxDepth)
    {
        return;
    }

    Intersection* rayIsect = Scene::intersect(isectBuilder, ray);
    if (nullptr == rayIsect)
    {
        return;
    }

    Intersection* lightIsect = nullptr;
    Intersection* blockIsect = nullptr;
    Intersection* objIsect   = nullptr;
    Vector3f      wo         = -ray.direction;
    float         pdf        = 0.f;

    do
    {
        if (rayIsect->obj->hasEmit())
        {
            if(depth < 1)
            {
                color += rayIsect->m->getEmission();
            }
        }
        else
        {
            // Light
            if (nullptr == (lightIsect = isectBuilder.NewIntersection()))
            {
                return;
            }
            lightIsect->Clear();

            sampleLight(*lightIsect, pdf);

            if (!lightIsect->obj->hasEmit() || (nullptr == lightIsect->obj) || (nullptr == lightIsect->m))
            {
                break;
            }

            Vector3f ws = lightIsect->coords - rayIsect->coords;
            normalize(ws);
            Ray lightRay(rayIsect->coords, ws);

            blockIsect = Scene::intersect(isectBuilder, lightRay);
            if ((nullptr != blockIsect) && (blockIsect->obj == lightIsect->obj))
            {
                float d2 = (lightIsect->coords - rayIsect->coords).normSquare();
                Vector3f fr = rayIsect->m->eval(wo, ws, rayIsect->normal);
                float cos1 = dotProduct(ws, rayIsect->normal);
                float cos2 = dotProduct(-ws, lightIsect->normal);
                color += lightIsect->emit * fr * cos1 * cos2 / d2 / pdf;
            }
        }

        // Object
        float randomNum = get_random_float();
        if (randomNum > RussianRoulette)
        {
            break;
        }

        Vector3f wi = rayIsect->m->sample(wo, rayIsect->normal);
        Ray ray(rayIsect->coords, wi);
        objIsect = Scene::intersect(isectBuilder, ray);
        if (nullptr == objIsect) break;
        if (objIsect->obj->hasEmit()) break;

        Vector3f in_fr = rayIsect->m->eval(wi, wo, rayIsect->normal);
        float in_cos1 = dotProduct(wi, rayIsect->normal);
        float in_cos2 = rayIsect->m->pdf(wi, wo, rayIsect->normal);
        Vector3f dd;
        castRay(isectBuilder, ray, depth + 1, dd);
        Vector3f L_indir = dd * in_fr * in_cos1 / in_cos2 / RussianRoulette;

        color += L_indir;
    } while(false);

    if (nullptr != objIsect)
    {
        isectBuilder.DelIntersection(objIsect);
    }

    if (nullptr != blockIsect)
    {
        isectBuilder.DelIntersection(blockIsect);
    }

    isectBuilder.DelIntersection(lightIsect);
    isectBuilder.DelIntersection(rayIsect);
}
