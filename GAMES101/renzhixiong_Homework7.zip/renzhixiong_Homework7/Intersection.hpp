//
// Created by LEI XU on 5/16/19.
//

#ifndef RAYTRACING_INTERSECTION_H
#define RAYTRACING_INTERSECTION_H
#include <list>
#include "Vector.hpp"
#include "Material.hpp"

class Object;
class Sphere;

typedef struct Intersection
{
    Intersection()
    {
        distance= std::numeric_limits<double>::max();
        obj     =nullptr;
        m       =nullptr;
    }

    void Clear()
    {
        coords   = {0.f, 0.f, 0.f};
        tcoords  = {0.f, 0.f, 0.f};
        normal   = {0.f, 0.f, 0.f};
        emit     = {0.f, 0.f, 0.f};
        distance = std::numeric_limits<double>::max();
        obj      = nullptr;
        m        = nullptr;
    }

    Vector3f coords;
    Vector3f tcoords;
    Vector3f normal;
    Vector3f emit;
    double distance;
    Object* obj;
    Material* m;
}Intersection;

class IsectBuilder
{
public:
    IsectBuilder()
    {

    }
    ~IsectBuilder()
    {
        for(auto it = list.begin(); it != list.end(); ++it)
        {
            delete(*it);
        }
        list.clear();
    }

    // 生成信息 Intersection 节点
    inline Intersection* NewIntersection()
    {
        if(list.empty())
        {
            return new Intersection();
        }

        Intersection* insect = list.front();
        list.pop_front();
        return insect;
    }

    // 销毁 Intersection 节点
    inline void DelIntersection(Intersection* isect)
    {
        if (nullptr == isect)
        {
            return;
        }

        list.push_front(isect);
    }

private:
    std::list<Intersection*> list;
};

#endif //RAYTRACING_INTERSECTION_H
