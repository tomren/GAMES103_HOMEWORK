#pragma once
#include <iostream>
#include <cmath>
#include <random>

#undef M_PI
#define M_PI 3.141592653589793f

// --------------------------------------------------------------------------------
// 是否使用多线程 0:不使用, 1:使用
#define MUTIL_THREAD 1
// 线程数量
#define THREAD_COUNT 16
// 采样数
#define SPP 16

// 定义三个坐标轴枚举
enum AXIS_DIR
{
    X_AXIS  = 0,
    Y_AXIS  = 1,
    Z_AXIS  = 2,
};

// --------------------------------------------------------------------------------

extern const float  EPSILON;
const float kInfinity = std::numeric_limits<float>::max();

const float MAX_FLOAT = std::numeric_limits<float>::max();
const float MIN_FLOAT = std::numeric_limits<float>::lowest();

extern std::random_device RANDOM_DEV;
extern std::mt19937 RANDOM_MT19937;
extern std::uniform_real_distribution<float> RANDOM_DIST;

// --------------------------------------------------------------------------------

inline float clamp(const float &lo, const float &hi, const float &v)
{ return std::max(lo, std::min(hi, v)); }

inline  bool solveQuadratic(const float &a, const float &b, const float &c, float &x0, float &x1)
{
    float discr = b * b - 4 * a * c;
    if (discr < 0) return false;
    else if (discr == 0) x0 = x1 = - 0.5 * b / a;
    else {
        float q = (b > 0) ?
                  -0.5 * (b + sqrt(discr)) :
                  -0.5 * (b - sqrt(discr));
        x0 = q / a;
        x1 = c / q;
    }
    if (x0 > x1) std::swap(x0, x1);
    return true;
}

inline float get_random_float()
{
    //std::random_device dev;
    //std::mt19937 rng(dev());
    //std::uniform_real_distribution<float> dist(0.f, 1.f); // distribution in range [1, 6]

    return RANDOM_DIST(RANDOM_MT19937);
}

inline void UpdateProgress(float progress)
{
    int barWidth = 70;

    std::cout << "[";
    int pos = barWidth * progress;
    for (int i = 0; i < barWidth; ++i) {
        if (i < pos) std::cout << "=";
        else if (i == pos) std::cout << ">";
        else std::cout << " ";
    }
    std::cout << "] " << int(progress * 100.0) << " %\r";
    std::cout.flush();
};
