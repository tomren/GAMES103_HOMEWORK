//
// Created by goksu on 2/25/20.
//
#include "Scene.hpp"
#include <pthread.h>

#pragma once
struct hit_payload
{
    float tNear;
    uint32_t index;
    Vector2f uv;
    Object* hit_obj;
};

class Renderer
{
public:
    // 构造函数
    Renderer() : mRenderCount(0), mBufferCount(0)
    {
        pthread_mutex_init(&mCountLock, NULL);
    }

    ~Renderer()
    {
        pthread_mutex_destroy(&mCountLock);
    }

    // 渲染函数
    void Render(const Scene& scene);

    // 是否完成渲染
    bool IsOk() { return mRenderCount == mBufferCount; }

    inline void IncRenderCount(uint32_t val)
    {
        pthread_mutex_lock(&mCountLock);
        mRenderCount += val;
        UpdateProgress((float)mRenderCount/(float)mBufferCount);
        pthread_mutex_unlock(&mCountLock);
    }

private:
    // 保存图像
    bool SaveImage(const char* path, const Vector3f* buffer, int32_t width, int32_t height);

    pthread_mutex_t     mCountLock;

    uint32_t            mRenderCount;
    uint32_t            mBufferCount;
};
