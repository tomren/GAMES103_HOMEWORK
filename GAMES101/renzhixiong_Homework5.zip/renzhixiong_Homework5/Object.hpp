#pragma once

#include <float.h>
#include <iostream>
#include "Vector.hpp"
#include "global.hpp"

// --------------------------------------------------

class AABB
{
public:
    AABB()
    {
        clear();
    }

    void clear()
    {
        min.x = FLT_MAX;
        min.y = FLT_MAX;
        min.z = FLT_MAX;

        max.x = -FLT_MAX;
        max.y = -FLT_MAX;
        max.z = -FLT_MAX;
    }

    bool intersect(const Vector3f& orig, const Vector3f& dir) const
    {
        float tmin = (min.x - orig.x) / dir.x;
        float tmax = (max.x - orig.x) / dir.x;

        if (tmin > tmax) std::swap(tmin, tmax);

        float tymin = (min.y - orig.y) / dir.y;
        float tymax = (max.y - orig.y) / dir.y;

        if (tymin > tymax) std::swap(tymin, tymax);

        if ((tmin > tymax) || (tymin > tmax))
            return false;

        if (tymin > tmin)
            tmin = tymin;

        if (tymax < tmax)
            tmax = tymax;

        float tzmin = (min.z - orig.z) / dir.z;
        float tzmax = (max.z - orig.z) / dir.z;

        if (tzmin > tzmax) std::swap(tzmin, tzmax);

        if ((tmin > tzmax) || (tzmin > tmax))
            return false;

        if (tzmin > tmin)
            tmin = tzmin;

        if (tzmax < tmax)
            tmax = tzmax;

        return true;
    }

    void update(const Vector3f& p)
    {
        if (p.x < min.x) min.x = p.x;
        if (p.y < min.y) min.y = p.y;
        if (p.z < min.z) min.z = p.z;
        if (p.x > max.x) max.x = p.x;
        if (p.y > max.y) max.y = p.y;
        if (p.z > max.z) max.z = p.z;
    }

    void update(const AABB& aabb)
    {
        if (aabb.min.x < min.x) min.x = aabb.min.x;
        if (aabb.min.y < min.y) min.y = aabb.min.y;
        if (aabb.min.z < min.z) min.z = aabb.min.z;
        if (aabb.max.x > max.x) max.x = aabb.max.x;
        if (aabb.max.y > max.y) max.y = aabb.max.y;
        if (aabb.max.z > max.z) max.z = aabb.max.z;
    }

    Vector3f min;
    Vector3f max;
    Vector3f center;
};

// --------------------------------------------------

class Object
{
public:
    Object()
        : materialType(DIFFUSE_AND_GLOSSY)
        , ior(1.3)
        , Kd(0.8)
        , Ks(0.2)
        , diffuseColor(0.2)
        , specularExponent(25)
    {

    }

    virtual ~Object() = default;

    virtual void calcAABB() = 0;

    const AABB& getAABB() { return aabb; }

    virtual bool intersect(const Vector3f&, const Vector3f&, float&, uint32_t&, Vector2f&) const = 0;

    virtual void getSurfaceProperties(const Vector3f&, const Vector3f&, const uint32_t&, const Vector2f&, Vector3f&,
                                      Vector2f&) const = 0;

    virtual Vector3f evalDiffuseColor(const Vector2f&) const
    {
        return diffuseColor;
    }

    // material properties
    MaterialType    materialType;
    float           ior;
    float           Kd, Ks;
    Vector3f        diffuseColor;
    float           specularExponent;
    AABB            aabb;
};
