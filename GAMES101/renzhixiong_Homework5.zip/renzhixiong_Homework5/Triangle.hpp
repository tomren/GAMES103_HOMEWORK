#pragma once

#include "Object.hpp"

#include <cstring>

bool rayTriangleIntersect(const Vector3f& v0, const Vector3f& v1, const Vector3f& v2, const Vector3f& orig,
                          const Vector3f& dir, float& tnear, float& u, float& v)
{
    // TODO: Implement this function that tests whether the triangle
    // that's specified bt v0, v1 and v2 intersects with the ray (whose
    // origin is *orig* and direction is *dir*)
    // Also don't forget to update tnear, u and v.

    const float EPSILON = FLT_EPSILON;

    Vector3f E1 = v1 - v0;
    Vector3f E2 = v2 - v0;
    Vector3f S1 = crossProduct(dir, E2);

    float S1E1 = dotProduct(S1, E1);
    // This ray is parallel to this triangle.
    if ((S1E1 > -EPSILON) && (S1E1 < EPSILON))
    {
        return false;
    }

    float invS1E1 = 1.0f / S1E1;
    Vector3f S = orig - v0;

    float b1 = invS1E1 * dotProduct(S1, S);
    if ((b1 < 0.0f) || (b1 > 1.0f))
    {
        return false;
    }

    Vector3f S2 = crossProduct(S, E1);
    float b2 = invS1E1 * dotProduct(S2, dir);
    if ((b2 < 0.0f) || ((b1 + b2) > 1.0f))
    {
        return false;
    }

    // At this stage we can compute t to find out where the intersection point is on the line.
    float t = invS1E1 * dotProduct(S2, E2);

    // This means that there is a line intersection but not a ray intersection.
    if (t <= EPSILON)
    {
        return false;
    }

    tnear = t;
    u = b1;
    v = b2;
    // ray intersection
    //outIntersectionPoint = orig + dir * t;

    return true;
}

class MeshTriangle : public Object
{
public:
    MeshTriangle(const Vector3f* verts, const uint32_t* vertsIndex, const uint32_t& numTris, const Vector2f* st)
    {
        uint32_t maxIndex = 0;
        uint32_t pointNum = numTris * 3;
        for (uint32_t i = 0; i < pointNum; ++i)
        {
            if (vertsIndex[i] > maxIndex)
            {
                maxIndex = vertsIndex[i];
            }
        }

        maxIndex += 1;
        vertices = std::unique_ptr<Vector3f[]>(new Vector3f[maxIndex]);
        memcpy(vertices.get(), verts, sizeof(Vector3f) * maxIndex);
        vertexIndex = std::unique_ptr<uint32_t[]>(new uint32_t[pointNum]);
        memcpy(vertexIndex.get(), vertsIndex, sizeof(uint32_t) * pointNum);
        numTriangles = numTris;
        stCoordinates = std::unique_ptr<Vector2f[]>(new Vector2f[maxIndex]);
        memcpy(stCoordinates.get(), st, sizeof(Vector2f) * maxIndex);

        calcAABB();
    }

    virtual void calcAABB()
    {
        for (uint32_t k = 0; k < numTriangles; ++k)
        {
            const Vector3f& v0 = vertices[vertexIndex[k * 3]];
            const Vector3f& v1 = vertices[vertexIndex[k * 3 + 1]];
            const Vector3f& v2 = vertices[vertexIndex[k * 3 + 2]];

            aabb.update(v0);
            aabb.update(v1);
            aabb.update(v2);
        }

        aabb.center = (aabb.min + aabb.max) * 0.5f;
    }

    bool intersect(const Vector3f& orig, const Vector3f& dir,
                   float& tnear, uint32_t& index, Vector2f& uv) const override
    {
        bool intersect = false;
        if (!(intersect = aabb.intersect(orig, dir)))
        {
            return intersect;
        }

        for (uint32_t k = 0; k < numTriangles; ++k)
        {
            uint32_t idx = k * 3;
            const Vector3f& v0 = vertices[vertexIndex[idx]];
            const Vector3f& v1 = vertices[vertexIndex[idx + 1]];
            const Vector3f& v2 = vertices[vertexIndex[idx + 2]];
            float t, u, v;

            if (rayTriangleIntersect(v0, v1, v2, orig, dir, t, u, v) && t < tnear)
            {
                tnear = t;
                uv.x = u;
                uv.y = v;
                index = k;
                intersect |= true;
            }
        }

        return intersect;
    }

    void getSurfaceProperties(const Vector3f&, const Vector3f&, const uint32_t& index, const Vector2f& uv, Vector3f& N,
                              Vector2f& st) const override
    {
        const Vector3f& v0 = vertices[vertexIndex[index * 3]];
        const Vector3f& v1 = vertices[vertexIndex[index * 3 + 1]];
        const Vector3f& v2 = vertices[vertexIndex[index * 3 + 2]];
        Vector3f e0 = normalize(v1 - v0);
        Vector3f e1 = normalize(v2 - v1);
        N = normalize(crossProduct(e0, e1));
        const Vector2f& st0 = stCoordinates[vertexIndex[index * 3]];
        const Vector2f& st1 = stCoordinates[vertexIndex[index * 3 + 1]];
        const Vector2f& st2 = stCoordinates[vertexIndex[index * 3 + 2]];
        st = st0 * (1 - uv.x - uv.y) + st1 * uv.x + st2 * uv.y;
    }

    Vector3f evalDiffuseColor(const Vector2f& st) const override
    {
        float scale = 5;
        float pattern = (fmodf(st.x * scale, 1) > 0.5) ^ (fmodf(st.y * scale, 1) > 0.5);
        return lerp(Vector3f(0.815, 0.235, 0.031), Vector3f(0.937, 0.937, 0.231), pattern);
    }

    std::unique_ptr<Vector3f[]> vertices;
    uint32_t numTriangles;
    std::unique_ptr<uint32_t[]> vertexIndex;
    std::unique_ptr<Vector2f[]> stCoordinates;
};
