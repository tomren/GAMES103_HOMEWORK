#include "Scene.hpp"
#include "Sphere.hpp"
#include "Triangle.hpp"
#include "Light.hpp"
#include "Renderer.hpp"

// In the main function of the program, we create the scene (create objects and lights)
// as well as set the options for the render (image width and height, maximum recursion
// depth, field-of-view, etc.). We then call the render function().
int main()
{
    Scene scene(1280, 960);

    // Sphere
    // --------------------------------------------------
    auto sph1 = std::make_unique<Sphere>(Vector3f(-1.0f, 0.0f, -12.0f), 2.0f);
    sph1->materialType = DIFFUSE_AND_GLOSSY;
    sph1->diffuseColor = Vector3f(0.6f, 0.7f, 0.8f);

    auto sph2 = std::make_unique<Sphere>(Vector3f(0.5f, -0.5f, -8.0f), 1.5f);
    sph2->ior = 1.5f;
    sph2->materialType = REFLECTION_AND_REFRACTION;

    scene.Add(std::move(sph1));
    scene.Add(std::move(sph2));

    // Plane
    // --------------------------------------------------
    Vector3f verts[4] = {{-5.f,-3.f,-6.f}, {5.f,-3.f,-6.f}, {5.f,-3.f,-16.f}, {-5.f,-3.f,-16.f}};
    uint32_t vertIndex[6] = {0, 1, 3, 1, 2, 3};
    Vector2f st[4] = {{0.f, 0.f}, {1.f, 0.f}, {1.f, 1.f}, {0.f, 1.f}};
    auto mesh = std::make_unique<MeshTriangle>(verts, vertIndex, 2, st);
    mesh->materialType = DIFFUSE_AND_GLOSSY;
    scene.Add(std::move(mesh));

    scene.InitBVH();

    // Light
    // --------------------------------------------------
    scene.Add(std::make_unique<Light>(Vector3f(-20.f, 70.f,  20.f), 0.5f));
    scene.Add(std::make_unique<Light>(Vector3f( 30.f, 50.f, -12.f), 0.5f));

    // Render
    // --------------------------------------------------
    Renderer r;
    r.Render(scene);

    return EXIT_SUCCESS;
}