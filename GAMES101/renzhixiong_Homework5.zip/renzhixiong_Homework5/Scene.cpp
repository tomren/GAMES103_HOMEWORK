//
// Created by Göksu Güvendiren on 2019-05-14.
//

#include "Scene.hpp"

// =========================
// Calculate Split Flag
// =========================
void BVHNode::CalcSplitFlag()
{
    if (BVHSPLIT_NONE != splitFlag)
    {
        return;
    }

    float lenA = aabb.max.x - aabb.min.x;
    float lenB = aabb.max.y - aabb.min.y;

    if (lenB > lenA)
    {
        lenA = lenB;
        splitFlag = BVHNode::BVHSPLIT::BVHSPLIT_Y;
    }
    else
    {
        splitFlag = BVHNode::BVHSPLIT::BVHSPLIT_X;
    }

    lenB = aabb.max.z - aabb.min.z;
    if (lenB > lenA)
    {
        splitFlag = BVHNode::BVHSPLIT::BVHSPLIT_Z;
    }
}

// =========================
// Split AABB By Axis
// =========================
void BVHNode::SplitByAxis()
{
    left = new BVHNode();
    right = new BVHNode();

    switch(splitFlag)
    {
        case BVHNode::BVHSPLIT::BVHSPLIT_X:
        {
            left->aabb.max.x *= 0.5f;
            right->aabb.min.x = right->aabb.max.x * 0.5f;
            break;
        }
        case BVHNode::BVHSPLIT::BVHSPLIT_Y:
        {
            left->aabb.max.y *= 0.5f;
            right->aabb.min.y = right->aabb.max.y * 0.5f;
            break;
        }
        case BVHNode::BVHSPLIT::BVHSPLIT_Z:
        {
            left->aabb.max.z *= 0.5f;
            right->aabb.min.z = right->aabb.max.z * 0.5f;
            break;
        }
        default:
        {
            break;
        }
    }
}

// =========================
// Create BVH Breanch
// =========================
void BVHNode::CreateNode(BVHNode* bvh)
{
    if ((nullptr == bvh) || (bvh->objects.size() <= 2))
    {
        return;
    }

    bvh->CalcSplitFlag();
    bvh->SplitByAxis();

    uint32_t splitIdx = bvh->objects.size() / 2;
    quickSelect(bvh->right->objects, 0, bvh->objects.size() - 1, splitIdx, bvh->splitFlag);

    for (uint32_t i = 0; i < bvh->objects.size(); ++i)
    {
        Object* obj = bvh->objects[i];
        if (i <= splitIdx)
        {
            bvh->left->objects.push_back(obj);
            bvh->left->aabb.update(obj->aabb);
        }
        else
        {
            bvh->right->objects.push_back(obj);
            bvh->right->aabb.update(obj->aabb);
        }
    }

    bvh->objects.clear();

    bvh->CreateNode(bvh->left);
    bvh->CreateNode(bvh->right);
}

// =========================
// Quick Qartition
// =========================
uint32_t BVHNode::quickQartition(std::vector<Object*>& list, uint32_t left, uint32_t right, uint32_t pivotIndex, uint8_t flag)
{
    Object* pivotValue = list[pivotIndex];
    std::swap(list[pivotIndex], list[right]);
    uint32_t storeIndex = left;

    for (uint32_t i = left; i < right; ++i)
    {
        bool isLess = false;
        switch(flag)
        {
            case BVHNode::BVHSPLIT::BVHSPLIT_X:
            {
                isLess = list[i]->aabb.center.x < pivotValue->aabb.center.x;
                break;
            }
            case BVHNode::BVHSPLIT::BVHSPLIT_Y:
            {
                isLess = list[i]->aabb.center.y < pivotValue->aabb.center.y;
                break;
            }
            case BVHNode::BVHSPLIT::BVHSPLIT_Z:
            {
                isLess = list[i]->aabb.center.z < pivotValue->aabb.center.z;
                break;
            }
            default:
            {
                break;
            }
        }

        if (isLess)
        {
            std::swap(list[storeIndex], list[i]);
            ++storeIndex;
        }
    }

    std::swap(list[right], list[storeIndex]);

    return storeIndex;
}

// =========================
// Quick Select
// =========================
Object* BVHNode::quickSelect(std::vector<Object*>& list, uint32_t left, uint32_t right, uint32_t k, uint8_t flag)
{
    if ((right >= list.size()) || (left >= right)|| (k > right))
    {
        return nullptr;
    }

    for(uint32_t pivotIndex = k;;)
    {
        pivotIndex = quickQartition(list, left, right, pivotIndex, flag);

        if (k == pivotIndex)
        {
            break;
        }

        if(k < pivotIndex)
        {
            right = pivotIndex - 1;
            continue;
        }

        left = pivotIndex + 1;
    }

    return list[k];
}

void Scene::InitBVH()
{
    bvh = new BVHNode();

    // AABB
    for (const auto& obj : objects)
    {
        bvh->aabb.update(obj->aabb);
        bvh->objects.push_back(obj.get());
    }

    bvh->CreateNode(bvh);
}