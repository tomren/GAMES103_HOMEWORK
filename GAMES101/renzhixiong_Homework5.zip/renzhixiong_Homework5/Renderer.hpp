#pragma once
#include "Scene.hpp"

struct hit_payload
{
    float           tNear;
    uint32_t        index;
    Vector2f        uv;
    const Object*   hit_obj;
};

class Renderer
{
public:
    void Render(const Scene& scene);

private:
    void SaveImage(const char* path, const std::vector<Vector3f>& buffer, int32_t width, int32_t height);
};