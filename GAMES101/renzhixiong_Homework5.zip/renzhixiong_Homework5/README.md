## 完成内容

- 完成光线生成
- 完成 Moller-Trumbore  算法

## 样例

#### 01 每像素使用1条射线
![](images\01.png)

#### 02 每像素使用4条射线采样
![](images\02.png)
