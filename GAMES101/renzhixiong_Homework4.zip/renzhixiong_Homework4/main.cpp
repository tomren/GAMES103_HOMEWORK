#include <chrono>
#include <iostream>
#include <opencv2/opencv.hpp>

#define WIN_WIDTH 700
#define WIN_HEIGHT 700

#define CALC_DRAW_IDX(x, y) (((uint32_t)(y) << 16) | (uint32_t)(x))
#define CALC_DIST(x) (((x)>=0.5f)? ((x)-0.5f): (0.5f-(x)))

#define GET_IDX_X(idx) (0xFFFF & idx)
#define GET_IDX_Y(idx) (idx >> 16)

#define CONTROL_POINT_DRAW_RADIUS 3.f
#define CONTROL_POINT_CHECK_SQUARE_RADIUS 81.f

#define ASCII_Esc 27
#define ASCII_a 97
#define ASCII_c 99
#define ASCII_e 101
#define ASCII_s 115

//std::vector<cv::Point2f> control_points;

// =========================
// Canvas Point
// =========================
typedef struct DrawPoint
{
    DrawPoint(float x, float y, const cv::Vec3b& color) : x(x), y(y), color(color)
    {

    }

    void clear()
    {
        x = 0.f;
        y = 0.f;
        color.zeros();
    }

    float x;
    float y;
    cv::Vec3b color;
} DrawPoint;

// =========================
// Canvas
// =========================
class DrawCanvas
{
public:
    DrawCanvas(cv::Mat& window) : m_win(window), m_is_anti(true), m_is_edge(true)
    {
        clear();
    }

    ~DrawCanvas()
    {
        clear();
    }

    void clear()
    {
        m_is_dirty = false;
        m_active_point = nullptr;
        m_control_points.clear();
        m_points.clear();
        m_anti_alising_points.clear();
    }

    bool isDirty() { return m_is_dirty; }
    void setDirty() { m_is_dirty = true; }
    void resetDirty() { m_is_dirty = false; }

    bool isAnit() { return m_is_anti; }
    void reverseAnit() { m_is_anti = !m_is_anti; }

    bool isEdge() { return m_is_edge; }
    bool reverseEdge() { m_is_edge = !m_is_edge; }

    std::vector<cv::Point2f>& getControlPoints() { return m_control_points; }

    // --------------------------------------------------
    // Mouse Function
    void onMouseLeftButton(float x, float y)
    {
        if (nullptr != m_active_point)
        {
            m_active_point = nullptr;
            return;
        }

        cv::Point2f* point = findControlPointByRadius(x, y);

        if (nullptr != point)
        {
            m_active_point = point;
            return;
        }

        m_control_points.emplace_back(x, y);
    }

    void onMouseRightButton(float x, float y)
    {
        if (nullptr != m_active_point)
        {
            m_active_point = nullptr;
            return;
        }

        if (m_control_points.size() < 1)
        {
            return;
        }

        delControlPointByRadius(x, y);
    }

    void onMouseMove(float x, float y)
    {
        if (nullptr == m_active_point)
        {
            return;
        }

        m_active_point->x = x;
        m_active_point->y = y;

        setDirty();
    }

    // --------------------------------------------------
    // Control Point
    cv::Point2f* findControlPointByRadius(float x, float y)
    {
        float dist = 0.f;

        for (auto it = m_control_points.begin(); it != m_control_points.end(); ++it)
        {
            float dx = x - it->x;
            float dy = y - it->y;
            dist =  dx * dx + dy * dy;

            if (dist <= CONTROL_POINT_CHECK_SQUARE_RADIUS)
            {
                return &*it;
            }
        }

        return nullptr;
    }

    void delControlPointByRadius(float x, float y)
    {
        float dist = 0.f;

        for (auto it = m_control_points.begin(); it != m_control_points.end(); ++it)
        {
            float dx = x - it->x;
            float dy = y - it->y;
            dist =  dx * dx + dy * dy;

            if (dist <= CONTROL_POINT_CHECK_SQUARE_RADIUS)
            {
                m_control_points.erase(it);
                setDirty();
                return;
            }
        }
    }

    void drawControlPoints()
    {
        static cv::Vec3b normal_color = {255, 255, 255};
        static cv::Vec3b active_color = {52, 73, 251};
        //static cv::Vec3b control_line_color = {104, 130, 145};
        static cv::Vec3b control_line_color = {147, 161, 127};
        //static cv::Vec3b active_color = {155, 134, 211};

        for (size_t i = 0; i < m_control_points.size(); ++i)
        {
            if (isEdge())
            {
                if ((i + 1) < m_control_points.size())
                {
                    cv::line(m_win, m_control_points[i], m_control_points[i+1], control_line_color, 1, cv::LINE_AA);
                }
            }

            if ((nullptr != m_active_point) && (m_active_point == &m_control_points[i]))
            {
                cv::circle(m_win, m_control_points[i], CONTROL_POINT_DRAW_RADIUS, active_color, CONTROL_POINT_DRAW_RADIUS);
            }
            else
            {
                cv::circle(m_win, m_control_points[i], CONTROL_POINT_DRAW_RADIUS, normal_color, CONTROL_POINT_DRAW_RADIUS);
            }
        }
    }

    // --------------------------------------------------
    // Draw Points
    void draw(float x, float y, const cv::Vec3b& color)
    {
        if((x < 0) || (x >= WIN_WIDTH) || (y < 0) || (y >= WIN_HEIGHT))
        {
            return;
        }

        uint32_t idx = CALC_DRAW_IDX(x, y);

        if (m_points.find(idx) != m_points.end())
        {
            return;
        }

        m_points.emplace(idx, DrawPoint(x, y, color));
    }

//    float calcMidDistance(float x, float y)
//    {
//        float dx = std::fmod(x, 1.0f);
//        float dy = std::fmod(y, 1.0f);
//
//        dx = CALC_DIST(dx);
//        dy = CALC_DIST(dy);
//
//        return (dx + dy) * 0.5f;
//    }

    void calcAntiAlising()
    {
        if (!isAnit())
        {
            return;
        }

        for(auto p : m_points)
        {
            int32_t x = GET_IDX_X(p.first);
            int32_t y = GET_IDX_Y(p.first);

            float dx = std::fmod(p.second.x, 1.0f);
            float dy = std::fmod(p.second.y, 1.0f);

            if (dx >= 0.5f)
            {
                if (dy >= 0.5f)
                {
                    calcAntiPoint(x + 1, y);
                    calcAntiPoint(x, y + 1);
                    calcAntiPoint(x + 1, y + 1);
                }
                else
                {
                    calcAntiPoint(x + 1, y);
                    calcAntiPoint(x, y - 1);
                    calcAntiPoint(x + 1, y - 1);
                }
            }
            else
            {
                if (dy >= 0.5f)
                {
                    calcAntiPoint(x - 1, y);
                    calcAntiPoint(x, y + 1);
                    calcAntiPoint(x - 1, y + 1);
                }
                else
                {
                    calcAntiPoint(x - 1, y);
                    calcAntiPoint(x, y - 1);
                    calcAntiPoint(x - 1, y - 1);
                }
            }
        }
    }

    //void calcAntiPoint(cv::Vec3b& col, float dist, int32_t x, int32_t y)
    void calcAntiPoint(int32_t x, int32_t y)
    {
        if((x < 0) || (x >= WIN_WIDTH) || (y < 0) || (y >= WIN_HEIGHT))
        {
            return;
        }

        uint32_t idx = CALC_DRAW_IDX(x, y);

        if(m_anti_alising_points.find(idx) != m_anti_alising_points.end())
        {
            return;
        }

        cv::Vec3i color = {0, 0, 0};

        int32_t count = 0;

        if(getColor(x - 1, y + 1, color)) ++count;
        if(getColor(x, y + 1, color)) ++count;
        if(getColor(x + 1, y + 1, color)) ++count;

        if(getColor(x - 1, y, color)) ++count;
        if(getColor(x + 1, y, color)) ++count;

        if(getColor(x - 1, y - 1, color)) ++count;
        if(getColor(x, y - 1, color)) ++count;
        if(getColor(x + 1, y - 1, color)) ++count;

        if (count < 1)
        {
            return;
        }

        color /= 8.0f;

        auto it = m_anti_alising_points.find(idx);
        if (it != m_anti_alising_points.end())
        {
            color += it->second;
            it->second =  color * 0.5f;
        }
        else
        {
            m_anti_alising_points.emplace(idx, color);
        }
    }

    bool getColor(int32_t x, int32_t y, cv::Vec3i& color)
    {
        uint32_t idx = CALC_DRAW_IDX(x, y);

        const auto it = m_points.find(idx);
        if (it == m_points.end())
        {
            return false;
        }

        color += it->second.color;

        return true;
    }

    void show()
    {
        if (isAnit())
        {
            for(const auto& p : m_anti_alising_points)
            {
                int32_t x = GET_IDX_X(p.first);
                int32_t y = GET_IDX_Y(p.first);

                m_win.at<cv::Vec3b>(y, x) = p.second;
            }
        }

        for(const auto& p : m_points)
        {
            int32_t x = GET_IDX_X(p.first);
            int32_t y = GET_IDX_Y(p.first);

            m_win.at<cv::Vec3b>(y, x) = p.second.color;
        }

        drawControlPoints();
    }

    void erase()
    {
        static cv::Vec3b blackColor = {0, 0, 0};

        for (int i = 0; i < WIN_HEIGHT; ++i)
        {
            for (int j = 0; j < WIN_WIDTH; ++j)
            {
                m_win.at<cv::Vec3b>(i, j) = blackColor;
            }
        }

//        for(const auto& p : m_points)
//        {
//            int32_t x = GET_IDX_X(p.first);
//            int32_t y = GET_IDX_Y(p.first);
//
//            m_win.at<cv::Vec3b>(y, x) = blackColor;
//        }
//
//        for(const auto& p : m_anti_alising_points)
//        {
//            int32_t x = GET_IDX_X(p.first);
//            int32_t y = GET_IDX_Y(p.first);
//
//            m_win.at<cv::Vec3b>(y, x) = blackColor;
//        }

        m_points.clear();
        m_anti_alising_points.clear();
    }

private:
    cv::Mat&                        m_win;
    bool                            m_is_dirty;
    bool                            m_is_anti;
    bool                            m_is_edge;

    cv::Point2f*                    m_active_point;
    std::vector<cv::Point2f>        m_control_points;
    std::map<uint32_t, DrawPoint>   m_points;
    std::map<uint32_t, cv::Vec3b>   m_anti_alising_points;
};

// --------------------------------------------------------------------------------

// =========================
// Handle mouse callback
// =========================
void mouse_handler(int event, int x, int y, int flags, void *userdata) 
{
    DrawCanvas* canvas = (DrawCanvas*)userdata;

    if((x < 0) || (x >= WIN_WIDTH) || (y < 0) || (y >= WIN_HEIGHT))
    {
        return;
    }

    //if (event == cv::EVENT_LBUTTONDOWN && control_points.size() < 4)
    switch(event)
    {
        case cv::EVENT_LBUTTONDOWN:
        {
            std::cout << "Left button of the mouse is clicked - position (" << x << ", "
                      << y << ")" << '\n';
            //control_points.emplace_back(x, y);

            if (nullptr != canvas)
            {
                canvas->onMouseLeftButton(x, y);
                canvas->setDirty();
            }

            break;
        }
        case cv::EVENT_RBUTTONDOWN:
        {
            if (nullptr != canvas)
            {
                canvas->onMouseRightButton(x, y);
                canvas->setDirty();
            }
            break;
        }
        case cv::EVENT_MOUSEMOVE:
        {
            if (nullptr != canvas)
            {
                canvas->onMouseMove(x, y);
            }
            break;
        }
        default:
        {
            break;
        }
    }
}

void naive_bezier(const std::vector<cv::Point2f> &points, cv::Mat &window) 
{
    auto &p_0 = points[0];
    auto &p_1 = points[1];
    auto &p_2 = points[2];
    auto &p_3 = points[3];

    for (double t = 0.0; t <= 1.0; t += 0.001)
    {
        auto point = std::pow(1 - t, 3) * p_0 + 3 * t * std::pow(1 - t, 2) * p_1 +
                 3 * std::pow(t, 2) * (1 - t) * p_2 + std::pow(t, 3) * p_3;

        if((point.x < 0) || (point.x >= WIN_WIDTH) || (point.y < 0) || (point.y >= WIN_HEIGHT))
        {
            continue;
        }

        window.at<cv::Vec3b>(point.y, point.x)[2] = 255;
    }
}

cv::Point2f& recursive_bezier(const std::vector<cv::Point2f> &control_points, float t)
{
    // TODO: Implement de Casteljau's algorithm
    static cv::Point2f p;

    p.x = 0.f;
    p.y = 0.f;

    if (control_points.size() < 3)
    {
        return p;
    }

    int32_t n = (int32_t)control_points.size()-1;

    for (int32_t j = 0; j <= n; ++j)
    {
        int32_t m = n - j;
        int32_t pn = 1;
        int32_t pk = 1;

        for (int z = m; z < n; ++z) { pn *= z+1; }
        for (int z = 1; z <= j; ++z) { pk *= z; }

        p += control_points[j] * (float)pn/(float)pk * std::pow(t, j) * std::pow(1-t, n-j);
    }

    return p;
}

//void bezier(const std::vector<cv::Point2f> &control_points, cv::Mat &window)
void bezier(const std::vector<cv::Point2f> &control_points, DrawCanvas& canvas)
{
    if(!canvas.isDirty())
    {
        return;
    }

    // TODO: Iterate through all t = 0 to t = 1 with small steps, and call de Casteljau's 
    // recursive Bezier algorithm.
    const static cv::Vec3b color = {0, 255, 0};

    canvas.erase();

    //for (double t = 0.0; t <= 1.0; t += 0.001)
    for (double t = 0.0; t <= 1.0; t += 0.00001)
    {
        cv::Point2f& point = recursive_bezier(control_points, t);

        canvas.draw(point.x, point.y, color);

        //window.at<cv::Vec3b>(point.y, point.x)[1] = 255;
    }

    canvas.calcAntiAlising();
    canvas.show();
    canvas.resetDirty();
}

// =========================
// Main Function
// =========================
int main() 
{
    cv::Mat window = cv::Mat(WIN_HEIGHT, WIN_WIDTH, CV_8UC3, cv::Scalar(0));
    cv::cvtColor(window, window, cv::COLOR_BGR2RGB);
    cv::namedWindow("Bezier Curve", cv::WINDOW_AUTOSIZE);

    DrawCanvas canvas(window);

    cv::setMouseCallback("Bezier Curve", mouse_handler, &canvas);

    int key = -1;
    while (ASCII_Esc != key)
    {
        const auto& control_points = canvas.getControlPoints();

        //canvas.drawControlPoints();

        if (control_points.size() == 4)
        {
            naive_bezier(control_points, window);
            //bezier(control_points, window);

            //cv::imshow("Bezier Curve", window);

            //key = cv::waitKey(0);
            //return 0;
        }

        bezier(control_points, canvas);

        cv::imshow("Bezier Curve", window);
        key = cv::waitKey(20);
        switch(key)
        {
            case ASCII_a:   // reverse anti alising
            {
                canvas.reverseAnit();
                canvas.setDirty();
                break;
            }
            case ASCII_c:   // clean canvas
            {
                canvas.clear();
                canvas.setDirty();
                break;
            }
            case ASCII_e:   // show control point edge
            {
                canvas.reverseEdge();
                canvas.setDirty();
                break;
            }
            case ASCII_s:   // save image
            {
                cv::imwrite("my_bezier_curve.png", window);
                break;
            }
            default:
            {
                break;
            }
        }
    }

    return EXIT_SUCCESS;
}
