## 完成内容

- 完成 De Casteljau 算法
- 完成提高 反走样

### 其他
- 鼠标左键控制点拖动
- 鼠标右键控制点删除
- 按键 a 开启/关闭 反走样
- 按键 e 绘制/不绘制 控制线
- 按键 c 清除画板
- 按键 s 保存  my_bezier_curve.png 图片

## 样例

#### 01 与样例重合的图像
![](images\01.png)

#### 02 无反走样
![](images\02.png)

#### 03 开启反走样
![](images\03.png)

#### 04 选取控制点、有连线
![](images\04.png)

## 函数说明
#### DrawCanvas 类
含有 window 类引用
标记数据脏，标记反走样、标记绘制边
保存控制点、绘制定点，反走样点
##### 鼠标相关
- onMouseLeftButton 实现鼠标左键选取
- onMouseRightButton 鼠标右键删除
- onMouseMove 鼠标移动

##### 控制点相关
- findControlPointByRadius 按点击范围找控制点
- delControlPointByRadius 删除控制点
- drawControlPoints 绘制控制点（激活红色，不激活白色）

##### 绘制
- draw 绘制曲线

##### 反走样
- calcAntiAlising 计算反走样涉及的点
- calcAntiPoint 计算反走样点颜色融合

#### 其他
实现了 bezier 和 recursive_bezier 函数