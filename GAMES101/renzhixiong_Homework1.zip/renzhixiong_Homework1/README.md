完成提高题  

```cpp
Eigen::Matrix4f get_rotation(Vector3f axis, float angle)
{
    Eigen::Matrix4f model = Eigen::Matrix4f::Identity();
    const float angle2radian = MY_PI / 180.f;
    float radian = angle * angle2radian;

    float c = std::cos(radian);
    float nc = 1 - c;
    float s = std::sin(radian);

    float x = axis.x();
    float y = axis.y();
    float z = axis.z();

    model << c + x*x*nc,   x*y*nc - z*s, y*s + x*z*nc,  0,
             z*s + x*y*nc, c + y*y*nc,   -x*s + y*z*nc, 0,
             -y*s+x*z*nc,  x*s+y*z*nc,   c+z*z*nc,      0,
             0,            0,            0,             1;

    return model;
}
```

