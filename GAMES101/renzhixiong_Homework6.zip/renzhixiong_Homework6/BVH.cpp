#include <algorithm>
#include <cassert>
#include <chrono>
#include "BVH.hpp"
#include <list>

std::list<Intersection*> BVHAccel::isectList;
std::atomic_flag         BVHAccel::isectLock = ATOMIC_FLAG_INIT;

BVHAccel::~BVHAccel()
{

}

BVHAccel::BVHAccel(const std::vector<Object*>& objects, int maxPrimsInNode, SplitMethod splitMethod)
    : maxPrimsInNode(std::min(255, maxPrimsInNode)), splitMethod(splitMethod), primitives(std::move(objects))
{
    auto start = std::chrono::system_clock::now();

    if (primitives.empty())
    {
        return;
    }

    if (BVHAccel::SplitMethod::SAH == splitMethod)
    {
        root = SAHBuild(primitives);
    }
    else
    {
        root = recursiveBuild(primitives);
    }

    auto stop = std::chrono::system_clock::now();
    auto diff = stop - start;

    printf("\rBVH Generation complete: \nTime Taken: %ld msecs\n\n", std::chrono::duration_cast<std::chrono::milliseconds>(diff).count());
}

// =========================
// Middle
// =========================
BVHBuildNode* BVHAccel::recursiveBuild(std::vector<Object*>& objects)
{
    BVHBuildNode* node = new BVHBuildNode();

    // 计算节点包围盒
    for (const auto& obj: objects)
    {
        if (nullptr == obj)
        {
            continue;
        }
        node->bounds.UpdateBounds(obj->getBounds());
    }

    // Compute bounds of all primitives in BVH node
    if (1 == objects.size())
    {
        // Create leaf _BVHBuildNode_
        node->object = objects[0];
        return node;
    }

    // 拆分2个叶子节点
    if (2 == objects.size())
    {
        std::vector<Object*> leftList = std::vector{objects[0]};
        node->left = recursiveBuild(leftList);

        std::vector<Object*> rightList = std::vector{objects[1]};
        node->right = recursiveBuild(rightList);

        return node;
    }

    // 取排列在中间位置节点作为拆分点
    int dim = node->bounds.maxExtent();
    uint32_t splitIdx = objects.size() * 0.5f;

    // Quick Select
    QuickSelect(objects, 0, objects.size() - 1, splitIdx, dim);

    // 按分块标记，重新划分两块
    auto middling = objects.begin() + splitIdx;
    auto leftshapes = std::vector<Object*>(objects.begin(), middling);
    auto rightshapes = std::vector<Object*>(middling, objects.end());

    assert(objects.size() == (leftshapes.size() + rightshapes.size()));

    node->left = recursiveBuild(leftshapes);
    node->right = recursiveBuild(rightshapes);

    return node;
}

// =========================
// SAH
// =========================
BVHBuildNode* BVHAccel::SAHBuild(std::vector<Object*>& objects)
{
    BVHBuildNode* node = new BVHBuildNode();

    // 计算节点包围盒
    for (const auto& obj: objects)
    {
        if (nullptr == obj)
        {
            continue;
        }
        node->bounds.UpdateBounds(obj->getBounds());
    }

    // Compute bounds of all primitives in BVH node
    if (1 == objects.size())
    {
        // Create leaf _BVHBuildNode_
        node->object = objects[0];
        return node;
    }

    // 拆分2个叶子节点
    if (2 == objects.size())
    {
        std::vector<Object*> leftList = std::vector{objects[0]};
        node->left = SAHBuild(leftList);

        std::vector<Object*> rightList = std::vector{objects[1]};
        node->right = SAHBuild(rightList);

        return node;
    }

    // 计算出最大的轴向
    int dim = node->bounds.maxExtent();
    // 将物体按这个轴由小到大排序
    SortObjectsByAxis(objects, dim);

    // 计算轴距
    float axisDist = 0.f;
    float axisMin  = 0.f;
    float axisMax  = 0.f;
    node->bounds.getAxisBound(dim, axisMin, axisMax);
    axisDist = axisMax - axisMin;

    // 分桶，计算每个桶的步长
    const int32_t stepCount = 31;
    float splitStep = axisDist / stepCount;

    float   minCost = std::numeric_limits<float>::max();
    int32_t minIdx  = 0;

    Bounds3 leftBounds;     // 从低到高的包围盒
    Bounds3 rightBounds;    // 从高到低的包围盒
    int32_t objIdx = 0;
    bool    dirty = false;
    int32_t objSize = objects.size();

    // 从低到高按步长移动，当有变更时计算 cost
    for (float left = axisMin + splitStep; left < axisMax; left += splitStep)
    {
        // 如果物体进入桶的范围，则重新计算 left 包围盒
        for (; objIdx < objSize; ++objIdx)
        {
            float dist = objects[objIdx]->getBounds().CentroidByAxis(dim);
            if (dist > left)
            {
                break;
            }

            leftBounds.UpdateBounds(objects[objIdx]->getBounds());
            dirty |= true;
        }

        if (!dirty)
        {
            continue;
        }

        // 重置标记，并计算 right 包围盒
        dirty = false;
        rightBounds.Clear();
        for (int32_t i = objIdx; i < objSize; ++i)
        {
            rightBounds.UpdateBounds(objects[i]->getBounds());
        }

        //if (objIdx < 1) { continue; }

        float cost = .125f + (float)(objIdx + 1) * leftBounds.SurfaceArea();
              cost += (float)(objSize - objIdx) * rightBounds.SurfaceArea();
              cost /= node->bounds.SurfaceArea();

        // 保留最小消耗的数值，并记录下标
        if (cost < minCost)
        {
            minCost = cost;
            minIdx = objIdx;
        }
    }

    // 如果左区小于1个，则至少添加1个
    if (minIdx < 1)
    {
        minIdx = 1;
    }
    // 如果右区小于1个，则至少添加1个
    else if(minIdx == objSize)
    {
        minIdx = objSize -1;
    }

    // 按最小标记为，重新划分两块
    auto middling = objects.begin() + minIdx;
    auto leftshapes = std::vector<Object*>(objects.begin(), middling);
    auto rightshapes = std::vector<Object*>(middling, objects.end());

    assert(objects.size() == (leftshapes.size() + rightshapes.size()));

    node->left = SAHBuild(leftshapes);
    node->right = SAHBuild(rightshapes);

    return node;
}

// =========================
// Quick Qartition
// =========================
uint32_t BVHAccel::QuickPartition(std::vector<Object*>& list, uint32_t left, uint32_t right, uint32_t pivotIndex, uint8_t flag)
{
    Object* pivotValue = list[pivotIndex];
    std::swap(list[pivotIndex], list[right]);
    uint32_t storeIndex = left;

    for (uint32_t i = left; i < right; ++i)
    {
        bool isLess = false;
        switch(flag)
        {
            case X_AXIS:
            {
                isLess = list[i]->getBounds().Centroid().x < pivotValue->getBounds().Centroid().x;
                break;
            }
            case Y_AXIS:
            {
                isLess = list[i]->getBounds().Centroid().y < pivotValue->getBounds().Centroid().y;
                break;
            }
            case Z_AXIS:
            {
                isLess = list[i]->getBounds().Centroid().z < pivotValue->getBounds().Centroid().z;
                break;
            }
            default:
            {
                break;
            }
        }

        if (isLess)
        {
            std::swap(list[storeIndex], list[i]);
            ++storeIndex;
        }
    }

    std::swap(list[right], list[storeIndex]);

    return storeIndex;
}

// =========================
// Quick Select
// =========================
Object* BVHAccel::QuickSelect(std::vector<Object*>& list, uint32_t left, uint32_t right, uint32_t k, uint8_t flag)
{
    if ((right >= list.size()) || (left >= right)|| (k > right))
    {
        return nullptr;
    }

    for(uint32_t pivotIndex = k;;)
    {
        pivotIndex = QuickPartition(list, left, right, pivotIndex, flag);

        if (k == pivotIndex)
        {
            break;
        }

        if(k < pivotIndex)
        {
            right = pivotIndex - 1;
            continue;
        }

        left = pivotIndex + 1;
    }

    return list[k];
}
// =========================
// Sort Objects By Axis
// =========================
void BVHAccel::SortObjectsByAxis(std::vector<Object*>& list, int dim)
{
    switch (dim)
    {
        case 0:
            std::sort(list.begin(), list.end(), [](auto f1, auto f2)
            {
                return f1->getBounds().Centroid().x < f2->getBounds().Centroid().x;
            });
            break;
        case 1:
            std::sort(list.begin(), list.end(), [](auto f1, auto f2)
            {
                return f1->getBounds().Centroid().y < f2->getBounds().Centroid().y;
            });
            break;
        case 2:
            std::sort(list.begin(), list.end(), [](auto f1, auto f2)
            {
                return f1->getBounds().Centroid().z < f2->getBounds().Centroid().z;
            });
            break;
        default:
            break;
    }
}

// =========================
// 获得碰撞节点信息
// =========================
Intersection* BVHAccel::getIntersection(const BVHBuildNode* node, const Ray& ray, float& dist, bool& flag) const
{
    // TODO Traverse the BVH to find intersection
    if (nullptr == node)
    {
        return nullptr;
    }

    // Leaf Node
    if (nullptr != node->object)
    {
        Intersection* inter = node->object->getIntersection(ray);
        if (nullptr == inter)
        {
            return nullptr;
        }

        if (inter->distance > dist)
        {
            BVHAccel::delIntersection(inter);
            return nullptr;
        }

        dist = inter->distance;
        flag |= true;
        return inter;
    }

    Intersection* leftIsect = nullptr;
    float tmin = std::numeric_limits<float>::max();
    if (node->left->bounds.IntersectP(ray, &tmin))
    {
        if (flag)
        {
            if (tmin < dist)
            {
                leftIsect = getIntersection(node->left, ray, dist, flag);
            }
        }
        else
        {
            leftIsect = getIntersection(node->left, ray, dist, flag);
        }
    }

    Intersection* rightIsect = nullptr;
    tmin = std::numeric_limits<float>::max();
    if (node->right->bounds.IntersectP(ray, &tmin))
    {
        if (flag)
        {
            if (tmin < dist)
            {
                rightIsect = getIntersection(node->right, ray, dist, flag);
            }
        }
        else
        {
            rightIsect = getIntersection(node->right, ray, dist, flag);
        }
    }

    if (nullptr == leftIsect)
    {
        return rightIsect;
    }

    if (nullptr == rightIsect)
    {
        return leftIsect;
    }

    if (leftIsect->distance < rightIsect->distance)
    {
        BVHAccel::delIntersection(rightIsect);
        return leftIsect;
    }

    BVHAccel::delIntersection(leftIsect);
    return rightIsect;
}