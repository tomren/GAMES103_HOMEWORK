//
// Created by goksu on 2/25/20.
//
#include <unistd.h>
#include <pthread.h>
#include "Scene.hpp"

#pragma once

class Renderer
{
public:
    Renderer();
    void Render(const Scene& scene);

    // 是否完成渲染
    bool IsOk() { return mRenderCount == mBufferCount; }

    inline Ray* PopRay();
    inline void PushRay(Ray* ray);

    // 设置光线
    inline void SetRay(const Vector3f& ori, const Vector3f& dir, Vector3f* buf);

    inline void IncRenderCount(uint32_t val)
    {
        while(mCountLock.test_and_set());
        mRenderCount += val;
        mCountLock.clear();
    }

private:
    // 保存图像
    bool SaveImage(const char* path, const Vector3f* buffer, int32_t width, int32_t height);

    std::atomic_flag    mCountLock;

    std::atomic_flag    mWrLock;
    std::vector<Ray*>   mWrList;

    std::atomic_flag    mRdLock;
    std::vector<Ray*>   mRdList;

    uint32_t            mRenderCount;
    uint32_t            mBufferCount;
};

inline Ray* Renderer::PopRay()
{
    while(mWrLock.test_and_set());
    if (mWrList.empty())
    {
        mWrLock.clear();
        return nullptr;
    }

    Ray* ray = mWrList.back();
    mWrList.pop_back();
    mWrLock.clear();
    return ray;
}

inline void Renderer::PushRay(Ray* ray)
{
    if (nullptr == ray) { return; }

    while(mRdLock.test_and_set());
    mRdList.push_back(ray);
    ++mRenderCount;
    mRdLock.clear();
}

inline void Renderer::SetRay(const Vector3f& ori, const Vector3f& dir, Vector3f* buf)
{
    Ray* ray = nullptr;

    while(mRdLock.test_and_set());
    if (!mRdList.empty())
    {
        ray = mRdList.back();
        mRdList.pop_back();
    }
    mRdLock.clear();

    if (nullptr == ray)
    {
        ray = new Ray(ori, dir);
    }
    else
    {
        ray->setDir(dir.x, dir.y, dir.z);
    }

    ray->buf = buf;

    while(mWrLock.test_and_set());
    mWrList.push_back(ray);
    mWrLock.clear();
}