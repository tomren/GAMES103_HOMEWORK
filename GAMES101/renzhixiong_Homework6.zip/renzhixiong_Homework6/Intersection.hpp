//
// Created by LEI XU on 5/16/19.
//

#ifndef RAYTRACING_INTERSECTION_H
#define RAYTRACING_INTERSECTION_H
#include "Vector.hpp"
#include "Material.hpp"
class Object;
class Sphere;

struct Intersection
{
    Intersection()
    {
        Clear();
    }

    void Clear()
    {
        coords   = {0.f, 0.f, 0.f};
        normal   = {0.f, 0.f, 0.f};
        distance = std::numeric_limits<float>::max();
        obj      = nullptr;
        m        = nullptr;
    }

    Vector3f    coords;
    Vector3f    normal;
    float       distance;
    Object*     obj;
    Material*   m;
};

#endif //RAYTRACING_INTERSECTION_H
