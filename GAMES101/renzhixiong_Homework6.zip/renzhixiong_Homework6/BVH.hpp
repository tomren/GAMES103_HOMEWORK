//
// Created by LEI XU on 5/16/19.
//

#ifndef RAYTRACING_BVH_H
#define RAYTRACING_BVH_H

#include <atomic>
#include <vector>
#include <memory>
#include <ctime>
#include <list>
#include "Object.hpp"
#include "Ray.hpp"
#include "Bounds3.hpp"
#include "Intersection.hpp"
#include "Vector.hpp"

struct BVHBuildNode;
// BVHAccel Forward Declarations
struct BVHPrimitiveInfo;

// BVHAccel Declarations
inline int leafNodes, totalLeafNodes, totalPrimitives, interiorNodes;

struct BVHBuildNode
{
    Bounds3         bounds;
    BVHBuildNode*   left;
    BVHBuildNode*   right;
    Object*         object;

public:
    int splitAxis=0, firstPrimOffset=0, nPrimitives=0;
    // BVHBuildNode Public Methods
    BVHBuildNode()
    {
        bounds = Bounds3();
        left = nullptr;
        right = nullptr;
        object = nullptr;
    }
};

class BVHAccel
{
public:
    // BVHAccel Public Types
    enum class SplitMethod { NAIVE, SAH };

    // BVHAccel Public Methods
    BVHAccel(const std::vector<Object*>& objects, int maxPrimsInNode = 1, SplitMethod splitMethod = SplitMethod::NAIVE);

    //Bounds3 WorldBound() const;
    ~BVHAccel();

    inline Intersection* Intersect(const Ray &ray) const
    {
        if (!root->bounds.IntersectP(ray))
        {
            return nullptr;
        }

        float tmin = std::numeric_limits<float>::max();
        bool flag = false;
        return BVHAccel::getIntersection(root, ray, tmin, flag);
    }

    Intersection* getIntersection(const BVHBuildNode* node, const Ray& ray, float& dist, bool& flag) const;

    bool IntersectP(const Ray &ray) const;

    // BVHAccel Private Methods
    BVHBuildNode* recursiveBuild(std::vector<Object*>& objects);
    BVHBuildNode* SAHBuild(std::vector<Object*>& objects);

    // ------------------------------
    // 快速划分，会改变传入的 list 序列
    uint32_t QuickPartition(std::vector<Object*>& list, uint32_t left, uint32_t right, uint32_t pivotIndex, uint8_t flag);
    // 快速选择，会改变传入的 list 序列
    Object* QuickSelect(std::vector<Object*>& list, uint32_t left, uint32_t right, uint32_t k, uint8_t flag);

    // ------------------------------
    // 按坐标轴排序
    void SortObjectsByAxis(std::vector<Object*>& list, int dim);

    // 生成信息 Intersection 节点
    static inline Intersection* NewIntersection()
    {
#if MUTIL_THREAD
        while(isectLock.test_and_set());
#endif
        if(isectList.empty())
        {
#if MUTIL_THREAD
            isectLock.clear();
#endif
            return new Intersection();
        }

        Intersection* insect = isectList.front();
        isectList.pop_front();
#if MUTIL_THREAD
        isectLock.clear();
#endif
        return insect;
    }

    // 销毁 Intersection 节点
    static inline void delIntersection(Intersection* isect)
    {
        if (nullptr == isect)
        {
            return;
        }

#if MUTIL_THREAD
        while(isectLock.test_and_set());
#endif
        isectList.push_front(isect);
#if MUTIL_THREAD
        isectLock.clear();
#endif
    }

    // BVHAccel Private Data
    const int               maxPrimsInNode;
    const SplitMethod       splitMethod;
    std::vector<Object*>    primitives;

    BVHBuildNode*           root;

private:
    static std::list<Intersection*> isectList;
    static std::atomic_flag         isectLock;
};

#endif //RAYTRACING_BVH_H
