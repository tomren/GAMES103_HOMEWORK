//
// Created by LEI XU on 5/13/19.
//

#ifndef RAYTRACING_SPHERE_H
#define RAYTRACING_SPHERE_H

#include "Object.hpp"
#include "Vector.hpp"
#include "Bounds3.hpp"
#include "Material.hpp"
#include "BVH.hpp"

class Sphere : public Object
{
public:
    float       radius;
    float       radius2;
    Material*   m;
    Vector3f    center;
    Bounds3     bounds;

    Sphere(const Vector3f &c, const float &r) : radius(r), radius2(r * r), m(new Material()), center(c)
    {
        bounds = Bounds3({center.x - radius, center.y - radius, center.z - radius},
                         {center.x+radius, center.y+radius, center.z+radius});
    }

    inline bool intersect(const Ray& ray)
    {
        // analytic solution
        Vector3f L = ray.origin - center;
        float a = dotProduct(ray.direction, ray.direction);
        float b = 2 * dotProduct(ray.direction, L);
        float c = dotProduct(L, L) - radius2;
        float t0, t1;
        if (!solveQuadratic(a, b, c, t0, t1)) return false;
        if (t0 < 0) t0 = t1;
        if (t0 < 0) return false;
        return true;
    }

    inline bool intersect(const Ray& ray, float &tnear, uint32_t &index) const
    {
        // analytic solution
        Vector3f L = ray.origin - center;
        float a = dotProduct(ray.direction, ray.direction);
        float b = 2 * dotProduct(ray.direction, L);
        float c = dotProduct(L, L) - radius2;
        float t0, t1;
        if (!solveQuadratic(a, b, c, t0, t1)) return false;
        if (t0 < 0) t0 = t1;
        if (t0 < 0) return false;
        tnear = t0;

        return true;
    }

    inline Intersection* getIntersection(const Ray& ray)
    {
        Vector3f L = ray.origin - center;
        float a = dotProduct(ray.direction, ray.direction);
        float b = 2 * dotProduct(ray.direction, L);
        float c = dotProduct(L, L) - radius2;
        float t0, t1;

        if (!solveQuadratic(a, b, c, t0, t1)) { return nullptr; }
        if (t0 < 0) { t0 = t1; }
        if (t0 < 0) { return nullptr; }

        Intersection* isect = BVHAccel::NewIntersection();
        if (nullptr == isect)
        {
            return nullptr;
        }

        isect->coords   = Vector3f(ray.origin + ray.direction * t0);
        isect->normal   = Vector3f(isect->coords - center);
        normalize(isect->normal);
        isect->m        = this->m;
        isect->obj      = this;
        isect->distance = t0;

        return isect;
    }

    void getSurfaceProperties(const Vector3f &P, const Vector3f &I, const uint32_t &index, const Vector2f &uv, Vector3f &N, Vector2f &st) const
    {
        N = P - center;
        normalize(N);
    }

    Vector3f evalDiffuseColor(const Vector2f &st)const
    {
        return m->getColor();
    }

    const Bounds3& getBounds()
    {
        return bounds;
    }
};




#endif //RAYTRACING_SPHERE_H
