## 完成内容

- 完成 包围盒求交
- 完成 BVH 查找
- 完成 SAH 加速


## 其他优化

- BVH Middle 快速选择
- 判断包围盒时，检查是否距离大于已获得的距离
- 优化碰撞返回信息为指针
- NAIVE 和 SAH 使用不同的多线程执行方式，是因为各取了最优执行速度的方法

```c++
global.hpp 添加新的定义

// 是否使用多线程 0:不使用, 1:使用
#define MUTIL_THREAD 1

// BVH 使用 SAH
#define BVH_SPLIT_TYPE BVHAccel::SplitMethod::SAH
// BVH 使用 NAIVE
//#define BVH_SPLIT_TYPE BVHAccel::SplitMethod::NAIVE

// 定义三个坐标轴枚举
enum AXIS_DIR
{
    X_AXIS  = 0,
    Y_AXIS  = 1,
    Z_AXIS  = 2,
};
```

## 样例

#### 01 BVH Middle 方法生成图
![](images\01.png)

#####  单线程
![](images\bvh_middle.png)

##### 多线程
![](images\bvh_middle_thread.png)

#### 02 BVH SAH 方法生成图
![](images\02.png)
#####  单线程
![](images\bvh_sah.png)
##### 多线程
![](images\bvh_sah_thread.png)