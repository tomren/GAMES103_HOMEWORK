//
// Created by goksu on 2/25/20.
//

#include <fstream>
#include <optional>
#include <unistd.h>
#include <pthread.h>
#include "Scene.hpp"
#include "Renderer.hpp"

const float EPSILON = 0.00001;

typedef struct RenderThreadData
{
    Renderer*   renderer;
    const Scene*scene;
    Vector3f*   framebuffer;

    uint32_t    beginHeight;
    uint32_t    endHeight;

    float       halfWidth;
    float       halfHeight;
    float       heightScale;
    Vector3f    eye_pos;
}RenderThreadData;

// =========================
// 角度转弧度
// =========================
inline float deg2rad(const float& deg)
{
    return deg * M_PI / 180.0;
}

// =========================
// 渲染线程
// =========================
void* render_thread(void* userData)
{
    RenderThreadData* data = (RenderThreadData*)userData;
    if (nullptr == data)
    {
        return nullptr;
    }

    Renderer* renderer = data->renderer;
    const Scene* scene = data->scene;

    if(BVH_SPLIT_TYPE == BVHAccel::SplitMethod::SAH)
    {
        do
        {
            Ray ray(data->eye_pos, Vector3f(0.f, 0.f, 0.f));
            for (uint32_t j = data->beginHeight, idx = data->beginHeight * scene->width; j < data->endHeight; ++j)
            {
                for (uint32_t i = 0; i < scene->width; ++i)
                {
                    float x = ((float(i) + 0.5f) - data->halfWidth) * data->heightScale;
                    float y = (data->halfHeight - (float(j) + 0.5f)) * data->heightScale;

                    ray.setDir(x, y, -1.f);
                    scene->castRay(ray, 0.f, data->framebuffer[idx++]);
                }

                renderer->IncRenderCount(scene->width);
            }
        }while(false);
    }
    else
    {
        Ray* ray = nullptr;
        while(!renderer->IsOk())
        {
            ray = renderer->PopRay();
            if (nullptr == ray)
            {
                usleep(1);
                continue;
            }

            scene->castRay(*ray, 0.f, *(ray->buf));
            renderer->PushRay(ray);
        }
    }

    delete data;

    return nullptr;
}

// =========================
// 构造函数
// =========================
Renderer::Renderer() : mCountLock(ATOMIC_FLAG_INIT), mWrLock(ATOMIC_FLAG_INIT), mRdLock(ATOMIC_FLAG_INIT),
                       mRenderCount(0), mBufferCount(false)
{

}

// The main render function. This where we iterate over all pixels in the image,
// generate primary rays and cast these rays into the scene. The content of the
// framebuffer is saved to a file.
void Renderer::Render(const Scene& scene)
{
    Vector3f* framebuffer = new Vector3f[scene.width * scene.height];

    float scale = tan(deg2rad(scene.fov * 0.5));
    //float imageAspectRatio = scene.width / (float)scene.height;

    float halfWidth = (float)scene.width * 0.5f;
    float halfHeight = (float)scene.height * 0.5f;
    float heightScale = 2.0f / (float)scene.height * scale;

    Vector3f eye_pos(-1.f, 5.f, 10.f);

// 使用多线程
#if MUTIL_THREAD
    mBufferCount = scene.height * scene.width;  // 设置 IsOk 计数

    const uint32_t threadCount = 5;             // 线程数量
    pthread_t thandle[threadCount];

    uint32_t segmentLen  = scene.height / threadCount;
    uint32_t idx = 0;

    for (pthread_t& i : thandle)
    {
        RenderThreadData* data = new RenderThreadData();
        data->renderer      = this;
        data->scene         = &scene;
        data->framebuffer   = framebuffer;

        // -------------------------
        data->beginHeight   = idx;          // 每个线程的起始高度
        idx                += segmentLen;   // 绘制区间
        data->endHeight     = idx;          // 结束高度
        // -------------------------
        data->halfWidth     = halfWidth;
        data->halfHeight    = halfHeight;
        data->heightScale   = heightScale;
        data->eye_pos       = eye_pos;

        if (-1 == (pthread_create(&i, nullptr, render_thread, (void*)data)))
        {
            std::cout << "Create pthread:% " << i << " failed." << std::endl;
        }
    }

    if(BVH_SPLIT_TYPE == BVHAccel::SplitMethod::NAIVE)
    {
        for (uint32_t j = 0, idx = 0; j < scene.height; ++j)
        {
            for (uint32_t i = 0; i < scene.width; ++i)
            {
                float x = ((float(i) + 0.5f) - halfWidth) * heightScale;
                float y = (halfHeight - (float(j) + 0.5f)) * heightScale;

                SetRay(eye_pos, {x, y, -1.f}, &framebuffer[idx++]);
            }
        }
    }

    while(!IsOk())
    {
        usleep(1);
    }

    UpdateProgress(1.f);
// 不开启线程
#else
    Ray ray(eye_pos, Vector3f(0.f, 0.f, 0.f));

    for (uint32_t j = 0, idx = 0; j < scene.height; ++j)
    {
        for (uint32_t i = 0; i < scene.width; ++i)
        {
            // generate primary ray direction
            //float x = (2 * (i + 0.5) / (float)scene.width - 1) * imageAspectRatio * scale;
            //float y = (1 - 2 * (j + 0.5) / (float)scene.height) * scale;
            float x = ((float(i) + 0.5f) - halfWidth) * heightScale;
            float y = (halfHeight - (float(j) + 0.5f)) * heightScale;

            // TODO: Find the x and y positions of the current pixel to get the
            ray.setDir(x, y, -1.f);
            scene.castRay(ray, 0.f, framebuffer[idx++]);
        }

        if (0 == ((j+1) % 20))
        {
            UpdateProgress((j+1) / (float)scene.height);
        }
    }
#endif

    // save framebuffer to file
    SaveImage("binary.ppm", framebuffer, scene.width, scene.height);

    delete framebuffer;
}

// =========================
// 单线程保存图像
// =========================
bool Renderer::SaveImage(const char* path, const Vector3f* buffer, int32_t width, int32_t height)
{
    FILE* fp = fopen(path, "wb");
    if (nullptr == fp)
    {
        return false;
    }

    (void)fprintf(fp, "P6\n%d %d\n255\n", width, height);
    int32_t len = height * width;
    for (int32_t i = 0; i < len; ++i)
    {
        static unsigned char color[3];
        color[0] = (unsigned char)(255 * clamp(0, 1, buffer[i].x));
        color[1] = (unsigned char)(255 * clamp(0, 1, buffer[i].y));
        color[2] = (unsigned char)(255 * clamp(0, 1, buffer[i].z));
        fwrite(color, sizeof(unsigned char), 3, fp);
    }

    fclose(fp);
    return true;
}