//
// Created by Göksu Güvendiren on 2019-05-14.
//

#pragma once

#include "Vector.hpp"

class Light
{
public:
    enum E_LIGHT
    {
        POINT_LIGHT = 1,
        AREA_LIGHT  = 2
    };

    Light(const Vector3f &p, const Vector3f &i, int32_t _type = POINT_LIGHT) :
          position(p), intensity(i), type(_type)
    {

    }

    virtual ~Light() = default;
    int32_t  type;
    Vector3f position;
    Vector3f intensity;
};
