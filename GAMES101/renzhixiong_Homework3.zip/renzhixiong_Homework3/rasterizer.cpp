//
// Created by goksu on 4/6/19.
//

#include <algorithm>
#include <opencv2/opencv.hpp>
#include <math.h>
#include "rasterizer.hpp"

#define NEW_BUF(buf, type, len)\
    if (buf)\
    {\
        delete [] buf;\
    }\
    buf = new type[len];

#define DEL_BUF(buf)\
    if (buf)\
    {\
        delete [] buf;\
    }

rst::pos_buf_id rst::rasterizer::load_positions(const std::vector<Eigen::Vector3f> &positions)
{
    auto id = get_next_id();
    pos_buf.emplace(id, positions);

    return {id};
}

rst::ind_buf_id rst::rasterizer::load_indices(const std::vector<Eigen::Vector3i> &indices)
{
    auto id = get_next_id();
    ind_buf.emplace(id, indices);

    return {id};
}

rst::col_buf_id rst::rasterizer::load_colors(const std::vector<Eigen::Vector3f> &cols)
{
    auto id = get_next_id();
    col_buf.emplace(id, cols);

    return {id};
}

rst::col_buf_id rst::rasterizer::load_normals(const std::vector<Eigen::Vector3f>& normals)
{
    auto id = get_next_id();
    nor_buf.emplace(id, normals);

    normal_id = id;

    return {id};
}


// Bresenham's line drawing algorithm
void rst::rasterizer::draw_line(Eigen::Vector3f begin, Eigen::Vector3f end)
{
    auto x1 = begin.x();
    auto y1 = begin.y();
    auto x2 = end.x();
    auto y2 = end.y();

    Eigen::Vector3f line_color = {255, 255, 255};

    int x,y,dx,dy,dx1,dy1,px,py,xe,ye,i;

    dx=x2-x1;
    dy=y2-y1;
    dx1=fabs(dx);
    dy1=fabs(dy);
    px=2*dy1-dx1;
    py=2*dx1-dy1;

    if(dy1<=dx1)
    {
        if(dx>=0)
        {
            x=x1;
            y=y1;
            xe=x2;
        }
        else
        {
            x=x2;
            y=y2;
            xe=x1;
        }
        Eigen::Vector2i point = Eigen::Vector2i(x, y);
        set_pixel(point,line_color);
        for(i=0;x<xe;i++)
        {
            x=x+1;
            if(px<0)
            {
                px=px+2*dy1;
            }
            else
            {
                if((dx<0 && dy<0) || (dx>0 && dy>0))
                {
                    y=y+1;
                }
                else
                {
                    y=y-1;
                }
                px=px+2*(dy1-dx1);
            }
//            delay(0);
            Eigen::Vector2i point = Eigen::Vector2i(x, y);
            set_pixel(point,line_color);
        }
    }
    else
    {
        if(dy>=0)
        {
            x=x1;
            y=y1;
            ye=y2;
        }
        else
        {
            x=x2;
            y=y2;
            ye=y1;
        }
        Eigen::Vector2i point = Eigen::Vector2i(x, y);
        set_pixel(point,line_color);
        for(i=0;y<ye;i++)
        {
            y=y+1;
            if(py<=0)
            {
                py=py+2*dx1;
            }
            else
            {
                if((dx<0 && dy<0) || (dx>0 && dy>0))
                {
                    x=x+1;
                }
                else
                {
                    x=x-1;
                }
                py=py+2*(dx1-dy1);
            }
//            delay(0);
            Eigen::Vector2i point = Eigen::Vector2i(x, y);
            set_pixel(point,line_color);
        }
    }
}

auto to_vec4(const Eigen::Vector3f& v3, float w = 1.0f)
{
    return Vector4f(v3.x(), v3.y(), v3.z(), w);
}

static bool insideTriangle(float x, float y, const Vector4f* _v){
    Vector3f v[3];
    for(int i=0;i<3;i++)
        v[i] = {_v[i].x(),_v[i].y(), 1.0};
    Vector3f f0,f1,f2;
    f0 = v[1].cross(v[0]);
    f1 = v[2].cross(v[1]);
    f2 = v[0].cross(v[2]);
    Vector3f p(x,y,1.);
    if((p.dot(f0)*f0.dot(v[2])>0) && (p.dot(f1)*f1.dot(v[0])>0) && (p.dot(f2)*f2.dot(v[1])>0))
        return true;
    return false;
}

static std::tuple<float, float, float> computeBarycentric2D(float x, float y, const Vector4f* v){
    float c1 = (x*(v[1].y() - v[2].y()) + (v[2].x() - v[1].x())*y + v[1].x()*v[2].y() - v[2].x()*v[1].y()) / (v[0].x()*(v[1].y() - v[2].y()) + (v[2].x() - v[1].x())*v[0].y() + v[1].x()*v[2].y() - v[2].x()*v[1].y());
    float c2 = (x*(v[2].y() - v[0].y()) + (v[0].x() - v[2].x())*y + v[2].x()*v[0].y() - v[0].x()*v[2].y()) / (v[1].x()*(v[2].y() - v[0].y()) + (v[0].x() - v[2].x())*v[1].y() + v[2].x()*v[0].y() - v[0].x()*v[2].y());
    float c3 = (x*(v[0].y() - v[1].y()) + (v[1].x() - v[0].x())*y + v[0].x()*v[1].y() - v[1].x()*v[0].y()) / (v[2].x()*(v[0].y() - v[1].y()) + (v[1].x() - v[0].x())*v[2].y() + v[0].x()*v[1].y() - v[1].x()*v[0].y());
    return {c1,c2,c3};
}

//void rst::draw(std::vector<Triangle *> &TriangleList)
void rst::rasterizer::draw(const DrawObj* drawObj)
{

    float f1 = (50 - 0.1) / 2.0;
    float f2 = (50 + 0.1) / 2.0;

    int draw_num = 0;
    int ignore_num = 0;
    AABB aabb;
    static Triangle triangle;

    Eigen::Matrix4f mvp = projection * view * model;

    for (const auto& m:drawObj->meshs)
    {
        for (const auto& t:m->triangles)
        {
            aabb.Clear();

            triangle = *t;

            std::array<Eigen::Vector4f, 3> mm
            {
                (view * model * t->v[0]),
                (view * model * t->v[1]),
                (view * model * t->v[2])
            };

            std::array<Eigen::Vector3f, 3> viewspace_pos;
            std::transform(mm.begin(), mm.end(), viewspace_pos.begin(), [](auto& v)
            {
                return v.template head<3>();
            });

            Eigen::Vector4f v[] = {mvp * t->v[0], mvp * t->v[1], mvp * t->v[2]};

            //Homogeneous division
            for (auto& vec : v)
            {
                vec.x()/=vec.w();
                vec.y()/=vec.w();
                vec.z()/=vec.w();
            }

            // Culling Triangle
            // ----------------------------------------
            // Triangle AABB bounding box
            aabb.Clear();
            for (auto& p : v)
            {
                aabb.Calc(p.x(), p.y(), p.z());
            }

            if (!aabb.Test(-1.f, -1.f, -1.f, 1.f, 1.f, 1.f))
            {
                continue;
            }

            // Backface Culling
            Eigen::Vector3f a = {v[0].x()-v[1].x(), v[0].y()-v[1].y(), v[0].z()-v[1].z()};
            Eigen::Vector3f b = {v[0].x()-v[2].x(), v[0].y()-v[2].y(), v[0].z()-v[2].z()};
            Eigen::Vector3f tri_n = a.cross(b).normalized();
            Eigen::Vector3f face = {0.f, 0.f, -1.f};
            float angle = tri_n.dot(face);
            if (angle > 0.f)
            {
                continue;
            }
            // ----------------------------------------

            Eigen::Matrix4f inv_trans = (view * model).inverse().transpose();
            Eigen::Vector4f n[] = {
                    inv_trans * to_vec4(t->normal[0], 0.0f),
                    inv_trans * to_vec4(t->normal[1], 0.0f),
                    inv_trans * to_vec4(t->normal[2], 0.0f)
            };

            aabb.min.x() = 0.5*width*(aabb.min.x()+1.0);
            aabb.min.y() = 0.5*height*(aabb.min.y()+1.0);
            aabb.min.z() = aabb.min.z() * f1 + f2;

            aabb.max.x() = 0.5*width*(aabb.max.x()+1.0);
            aabb.max.y() = 0.5*height*(aabb.max.y()+1.0);
            aabb.max.z() = aabb.max.z() * f1 + f2;

            //Viewport transformation
            for (auto & vert : v)
            {
                vert.x() = 0.5*width*(vert.x()+1.0);
                vert.y() = 0.5*height*(vert.y()+1.0);
                vert.z() = vert.z() * f1 + f2;
            }

            for (int i = 0; i < 3; ++i)
            {
                //screen space coordinates
                triangle.setVertex(i, v[i]);
            }

            for (int i = 0; i < 3; ++i)
            {
                //view space normal
                triangle.setNormal(i, n[i].head<3>());
            }

            triangle.setColor(0, 148, 121.0, 92.0);
            triangle.setColor(1, 148, 121.0, 92.0);
            triangle.setColor(2, 148, 121.0, 92.0);

            // Also pass view space vertice position
            if(rasterize_triangle_msaa(m->material, triangle, aabb, viewspace_pos))
            //if(rasterize_triangle(m->material, triangle, aabb, viewspace_pos))
            {
                ++draw_num;
            }
            else
            {
                ++ignore_num;
            }
        }
    }

    std::cout << "draw_num:" << draw_num << ", ignore_num" << ignore_num << std::endl;
}

static Eigen::Vector3f interpolate(float alpha, float beta, float gamma, const Eigen::Vector3f& vert1, const Eigen::Vector3f& vert2, const Eigen::Vector3f& vert3, float weight)
{
    return (alpha * vert1 + beta * vert2 + gamma * vert3) / weight;
}

static Eigen::Vector2f interpolate(float alpha, float beta, float gamma, const Eigen::Vector2f& vert1, const Eigen::Vector2f& vert2, const Eigen::Vector2f& vert3, float weight)
{
    auto u = (alpha * vert1[0] + beta * vert2[0] + gamma * vert3[0]);
    auto v = (alpha * vert1[1] + beta * vert2[1] + gamma * vert3[1]);

    u /= weight;
    v /= weight;

    return Eigen::Vector2f(u, v);
}

//Screen space rasterization
bool rst::rasterizer::rasterize_triangle_msaa(const DrawMaterial& material, const Triangle& t, const AABB& aabb, const std::array<Eigen::Vector3f, 3>& view_pos)
{
    // TODO: From your HW3, get the triangle rasterization code.
    // TODO: Inside your rasterization loop:
    //    * v[i].w() is the vertex view space depth value z.
    //    * Z is interpolated view space depth for the current pixel
    //    * zp is depth between zNear and zFar, used for z-buffer

    const auto& v = t.v;

    // Backface Culling
    Eigen::Vector3f a = {t.v[0].x()-t.v[1].x(), t.v[0].y()-t.v[1].y(), t.v[0].z()-t.v[1].z()};
    Eigen::Vector3f b = {t.v[0].x()-t.v[2].x(), t.v[0].y()-t.v[2].y(), t.v[0].z()-t.v[2].z()};
    Eigen::Vector3f n = a.cross(b).normalized();
    Eigen::Vector3f face = {0.f, 0.f, -1.f};
    float angle = n.dot(face);
    if (angle > 0.f)
    {
        return false;
    }

    // Triangle mini bounding
    std::vector<Eigen::Vector3i> miniBounding;
    cal_mini_bounding(t, aabb.min, aabb.max, miniBounding);

    // If so, use the following code to get the interpolated z value.
    // TODO : set the current pixel (use the set_pixel function) to the color of the triangle (use getColor function) if it should be painted.
    Eigen::Vector3f p = {0.f, 0.f, 0.f};
    Eigen::Vector3f c = {0.f, 0.f, 0.f};
    bool hasSet = false;

    int minX = aabb.min.x();
    int minY = aabb.min.y();
    int maxX = aabb.max.x();
    int maxY = aabb.max.y();

    if (minX < 0) minX = 0;
    if (minY < 0) minY = 0;
    if (maxX > width) maxX = width;
    if (maxY > height) maxY = height;

    for (int xPix = minX; xPix <= maxX; ++xPix)
    {
        for (int yPix = minY; yPix <= maxY; ++yPix)
        {
//    for (std::vector<Eigen::Vector3i>::iterator it = miniBounding.begin(); it != miniBounding.end(); ++it)
//    {
//        int yPix = it->x();
//
//        for (int xPix = it->y(); xPix <= it->z(); ++xPix)
//        {
            hasSet = false;

            // Calculate pixel depth
            p.x() = float(xPix);
            p.y() = float(yPix);

            // MSAA depth, color
            // --------------------------------------------------
            for (int row = 0; row < msaa_row_num; ++row)
            {
                for (int col = 0; col < msaa_col_num; ++col)
                {

                    float x = xPix + 0.25f + (0.5f * col);
                    float y = yPix + 0.25f + (0.5f * row);

                    if (!insideTriangle(x, y, t.v))
                    {
                        continue;
                    }

                    auto[alpha, beta, gamma] = computeBarycentric2D(x, y, v);
                    float Z = 1.0 / (alpha / v[0].w() + beta / v[1].w() + gamma / v[2].w());
                    float zp = alpha * v[0].z() / v[0].w() + beta * v[1].z() / v[1].w() + gamma * v[2].z() / v[2].w();
                    zp *= Z;
                    p.z() = zp;

                    // TODO: Interpolate the attributes:
                    //Vector3f interpolated_color = alpha*t.color[0] + beta*t.color[1] + gamma*t.color[2];
                    Vector3f interpolated_color = (t.color[0] + t.color[1] + t.color[2])/3;
                    Vector3f interpolated_normal = alpha*t.normal[0] + beta*t.normal[1] + gamma*t.normal[2];
                    Vector2f interpolated_texcoords = alpha*t.tex_coords[0] + beta*t.tex_coords[1] + gamma*t.tex_coords[2];
                    Vector4f tmpv = alpha*t.v[0] + beta*t.v[1] + gamma*t.v[2];
                    Vector3f interpolated_shadingcoords {tmpv.x(), tmpv.y(), tmpv.z()};

                    fragment_shader_payload payload(interpolated_color, interpolated_normal.normalized(), interpolated_texcoords, texture ? &*texture : nullptr, &material);
                    payload.view_pos = alpha*view_pos[0]+beta*view_pos[1]+gamma*view_pos[2];

                    //Instead of passing the triangle's color directly to the frame buffer, pass the color to the shaders first to get the final color;
                    auto pixel_color = fragment_shader(payload);

                    set_msaa_pixel(xPix, yPix, col, row, p.z(), pixel_color);

                    hasSet = true;
                }
            }

            if (!hasSet)
            {
                continue;
            }

            // get mass color
            get_msaa_pixel(xPix, yPix, c);

            const Vector2i p2d = {p.x(), p.y()};

            set_pixel(p2d, c);
        }
    }

    return true;
}

//Screen space rasterization
bool rst::rasterizer::rasterize_triangle(const DrawMaterial& material, const Triangle& t, const AABB& aabb, const std::array<Eigen::Vector3f, 3>& view_pos)
{
    const auto& v = t.v;

    // If so, use the following code to get the interpolated z value.
    // TODO : set the current pixel (use the set_pixel function) to the color of the triangle (use getColor function) if it should be painted.
    Eigen::Vector3f p = {0.f, 0.f, 0.f};
    Eigen::Vector3f c = {0.f, 0.f, 0.f};
    bool hasSet = false;

    int minX = aabb.min.x();
    int minY = aabb.min.y();
    int maxX = aabb.max.x();
    int maxY = aabb.max.y();

    if (minX < 0) minX = 0;
    if (minY < 0) minY = 0;
    if (maxX > width) maxX = width;
    if (maxY > height) maxY = height;

    for (int xPix = minX; xPix <= maxX; ++xPix)
    {
        for (int yPix = minY; yPix <= maxY; ++yPix)
        {
            hasSet = false;

            // Calculate pixel depth
            p.x() = float(xPix);
            p.y() = float(yPix);

            float x = xPix+0.5f;
            float y = yPix+0.5f;

            if (!insideTriangle(x, y, t.v))
            {
                continue;
            }

            auto[alpha, beta, gamma] = computeBarycentric2D(x, y, v);
            float Z = 1.0 / (alpha / v[0].w() + beta / v[1].w() + gamma / v[2].w());
            float zp = alpha * v[0].z() / v[0].w() + beta * v[1].z() / v[1].w() + gamma * v[2].z() / v[2].w();
            zp *= Z;
            p.z() = zp;

            // ----------------------------------------
            int idx = (height - 1 - yPix) * width + xPix;
            if (idx < 0 || idx >=buf_len)
            {
                continue;
            }

            if (p.z() > depth_buf[idx])
            {
                continue;
            }
            depth_buf[idx] = p.z();
            // ----------------------------------------

            // TODO: Interpolate the attributes:
            //Vector3f interpolated_color = alpha*t.color[0] + beta*t.color[1] + gamma*t.color[2];
            Vector3f interpolated_color = (t.color[0] + t.color[1] + t.color[2])/3;
            Vector3f interpolated_normal = alpha*t.normal[0] + beta*t.normal[1] + gamma*t.normal[2];
            Vector2f interpolated_texcoords = alpha*t.tex_coords[0] + beta*t.tex_coords[1] + gamma*t.tex_coords[2];
            Vector4f tmpv = alpha*t.v[0] + beta*t.v[1] + gamma*t.v[2];
            Vector3f interpolated_shadingcoords {tmpv.x(), tmpv.y(), tmpv.z()};

            //fragment_shader_payload payload(interpolated_color, interpolated_normal.normalized(), interpolated_texcoords, texture ? &*texture : nullptr);
            fragment_shader_payload payload(interpolated_color, interpolated_normal.normalized(), interpolated_texcoords, texture ? &*texture : nullptr, &material);

            payload.view_pos = alpha*view_pos[0]+beta*view_pos[1]+gamma*view_pos[2];

            //Instead of passing the triangle's color directly to the frame buffer, pass the color to the shaders first to get the final color;
            auto pixel_color = fragment_shader(payload);
            c = pixel_color;

            const Vector2i p2d = {p.x(), p.y()};
            set_pixel(p2d, c);
        }
    }

    return true;
}

void rst::rasterizer::cal_mini_bounding(const Triangle& t, const Eigen::Vector4f& minPos,
                                        const Eigen::Vector4f& maxPos, std::vector<Eigen::Vector3i>& miniBounding)
{
    int minX = 0;
    int maxX = 0;

    int num = int(maxPos.y() - minPos.y()) + 1;
    for (int i = 0, y = minPos.y(); i < num; ++i)
    {
        Eigen::Vector3i p = {y + i, INT_MAX, INT_MIN};      // {y, min_x, max_x}
        for(int m = 0; m < 3; ++m)
        {
            int n = (m + 1) % 3;

            const Eigen::Vector4f& a = t.v[m];
            const Eigen::Vector4f& b = t.v[n];

            float dx = a.x() - b.x();
            float dy = a.y() - b.y();

            if (0.f == dy)
            {
                if (p.x() == (int)a.y())
                {
                    if (a.x() < p.y()) p.y() = a.x();
                    if (b.x() < p.y()) p.y() = b.x();

                    if (((int)a.x()+1) > p.z()) p.z() = a.x()+1;
                    if (((int)b.x()+1) > p.z()) p.z() = b.x()+1;
                    //if ((int)a.x() > p.z()) p.z() = a.x();
                    //if ((int)b.x() > p.z()) p.z() = b.x();
                }

                continue;
            }

            minX = a.y() < b.y() ? a.y() : b.y();
            maxX = a.y() > b.y() ? a.y() : b.y();

            if (0.f == dx)
            {
                if ((p.x() < minX) || (p.x() > maxX))
                {
                    continue;
                }

                if (a.x() < p.y()) p.y() = a.x();
                if (((int)a.x()+1) > p.z()) p.z() = a.x()+1;
                //if ((int)a.x() > p.z()) p.z() = a.x();

                continue;
            }

            if ((p.x() < minX) || (p.x() > maxX))
            {
                continue;
            }

            const Eigen::Vector4f* left = a.x() < b.x()? &a: &b;
            float x = left->x()+((p.x()+0.5f)-left->y())*(dx/dy);
            if (x < p.y()) p.y() = x;
            if (((int)x+1) > p.z()) p.z() = x+1;
            //if ((int)x > p.z()) p.z() = x;
        }

        miniBounding.push_back(p);
    }
}

void rst::rasterizer::set_model(const Eigen::Matrix4f& m)
{
    model = m;
}

void rst::rasterizer::set_view(const Eigen::Matrix4f& v)
{
    view = v;
}

void rst::rasterizer::set_projection(const Eigen::Matrix4f& p)
{
    projection = p;
}

void rst::rasterizer::clear(rst::Buffers buff)
{
    if ((buff & rst::Buffers::Color) == rst::Buffers::Color)
    {
        memcpy(frame_buf, frame_init_buf, sizeof(Vector3f)*buf_len);

        for (int i = 0, offset = 0, cpysize = sizeof(Vector3f) * buf_len; i < msaa_density; ++i, offset+=buf_len)
        {
            memcpy(&msaa_frame_buf[offset], frame_init_buf, cpysize);
        }
    }

    if ((buff & rst::Buffers::Depth) == rst::Buffers::Depth)
    {
        memcpy(depth_buf, depth_init_buf, sizeof(float)*buf_len);

        for (int i = 0, offset = 0, cpysize = sizeof(float) * buf_len; i < msaa_density; ++i, offset+=buf_len)
        {
            memcpy(&msaa_depth_buf[offset], depth_init_buf, cpysize);
        }
    }
}

rst::rasterizer::rasterizer(int w, int h) : width(w), height(h)
{
    texture = std::nullopt;

    buf_len = w * h;
    NEW_BUF(frame_buf, Eigen::Vector3f, buf_len);
    NEW_BUF(depth_buf, float, buf_len);

    msaa_buf_len = buf_len * msaa_density;
    NEW_BUF(msaa_frame_buf, Eigen::Vector3f, msaa_buf_len);
    NEW_BUF(msaa_depth_buf, float, msaa_buf_len);

    NEW_BUF(frame_init_buf, Eigen::Vector3f, buf_len);
    NEW_BUF(depth_init_buf, float, buf_len);

    // depth init value
    Eigen::Vector3f frameVal = {0, 0, 0};
    float           depthVal = FLT_MIN;
    for(int i = 0; i < buf_len; ++i)
    {
        frame_init_buf[i] = frameVal;
        depth_init_buf[i] = depthVal;
    }

    std::cout << "buf_len:" << buf_len << ", msaa_buf_len:" << msaa_buf_len << '\n';
}

rst::rasterizer::~rasterizer()
{
    DEL_BUF(frame_buf);
    DEL_BUF(depth_buf);

    DEL_BUF(msaa_frame_buf);
    DEL_BUF(msaa_depth_buf);

    DEL_BUF(frame_init_buf);
    DEL_BUF(depth_init_buf);
}

int rst::rasterizer::get_index(int x, int y)
{
    return (height-y)*width + x;
}

void rst::rasterizer::set_pixel(const Vector2i &point, const Eigen::Vector3f &color)
{
    int idx = (height - 1 - point.y()) * width + point.x();

    if (idx < 0 || idx >=buf_len)
    {
        return;
    }

    frame_buf[idx] = color;
    //depth_buf[idx] = point.z();
}

void rst::rasterizer::set_vertex_shader(std::function<Eigen::Vector3f(vertex_shader_payload)> vert_shader)
{
    vertex_shader = vert_shader;
}

void rst::rasterizer::set_fragment_shader(std::function<Eigen::Vector3f(fragment_shader_payload)> frag_shader)
{
    fragment_shader = frag_shader;
}

void rst::rasterizer::set_msaa_pixel(int x, int y, int col, int row, float z, const Eigen::Vector3f& color)
{
    int offset = col | (row<<1);
    int idx = (height - 1 - y) * (width * msaa_density) + (x * msaa_density) + offset;

    if (idx < 0 || idx >=msaa_buf_len)
    {
        return;
    }

    if (z > msaa_depth_buf[idx])
    {
        return;
    }

    msaa_frame_buf[idx] = color;
    msaa_depth_buf[idx] = z;
}

void rst::rasterizer::get_msaa_pixel(int x, int y, Eigen::Vector3f& color)
{
    int idx = (height - 1 - y) * (width * msaa_density) + (x * msaa_density);

    if (idx < 0 || idx >=msaa_buf_len)
    {
        return;
    }

    color = msaa_frame_buf[idx];

    color.setZero();
    for (int i = 0; i < msaa_density; ++i)
    {
        color += msaa_frame_buf[idx + i];
    }

    color /= msaa_density;
}
