#include <sys/time.h>
#include <iostream>
#include <opencv2/opencv.hpp>

#include "global.hpp"
#include "rasterizer.hpp"
#include "Triangle.hpp"
#include "Shader.hpp"
#include "Texture.hpp"

Eigen::Matrix4f get_view_matrix(Eigen::Vector3f eye_pos)
{
    Eigen::Matrix4f view = Eigen::Matrix4f::Identity();

    Eigen::Matrix4f translate;
    translate << 1,0,0,-eye_pos[0],
                 0,1,0,-eye_pos[1],
                 0,0,1,-eye_pos[2],
                 0,0,0,1;

    view = translate*view;

    return view;
}

Eigen::Matrix4f get_model_matrix(float angle)
{
    Eigen::Matrix4f rotation;
    angle = angle * MY_PI / 180.f;
    rotation << cos(angle), 0, sin(angle), 0,
                0, 1, 0, 0,
                -sin(angle), 0, cos(angle), 0,
                0, 0, 0, 1;

    Eigen::Matrix4f scale;
    scale << 2.5, 0,   0,   0,
             0,   2.5, 0,   0,
             0,   0,   2.5, 0,
             0,   0,   0,   1;

    Eigen::Matrix4f translate;
    translate << 1, 0, 0, 0,
                 0, 1, 0, 0,
                 0, 0, 1, 0,
                 0, 0, 0, 1;

    return translate * rotation * scale;
}

Eigen::Matrix4f get_projection_matrix(float eye_fov, float aspect_ratio, float zNear, float zFar)
{
    // TODO: Use the same projection matrix from the previous assignments
    Eigen::Matrix4f projection;
    float theta = eye_fov / 2.0f / 180.f * MY_PI;
    float t = std::tan(theta) * zNear;
    float b = -t;
    float r = aspect_ratio * t;
    float l = -r;

    projection << -2.f*zNear/(r-l),  0.f,             (l+r)/(l-r),               0.f,
                   0.f,             -2.f*zNear/(t-b), (b+t)/(b-t),               0.f,
                   0.f,              0.f,             (zNear+zFar)/(zNear-zFar), 2.f*zNear*zFar/(zFar-zNear),
                   0.f,              0.f,             1.f,                       0.f;

    return projection;
}

Eigen::Vector3f vertex_shader(const vertex_shader_payload& payload)
{
    return payload.position;
}

Eigen::Vector3f normal_fragment_shader(const fragment_shader_payload& payload)
{
    Eigen::Vector3f return_color = (payload.normal.head<3>().normalized() + Eigen::Vector3f(1.0f, 1.0f, 1.0f)) / 2.f;
    Eigen::Vector3f result;
    result << return_color.x() * 255, return_color.y() * 255, return_color.z() * 255;
    return result;
}

static Eigen::Vector3f reflect(const Eigen::Vector3f& vec, const Eigen::Vector3f& axis)
{
    auto costheta = vec.dot(axis);
    return (2 * costheta * axis - vec).normalized();
}

struct light
{
    Eigen::Vector3f position;
    Eigen::Vector3f intensity;
};

Eigen::Vector3f custom_fragment_shader(const fragment_shader_payload& payload)
{
    Eigen::Vector3f return_color = {0, 0, 0};
    if (nullptr == payload.material)
    {
        return return_color;
    }

    const DrawMaterial& mat = *payload.material;

    if (mat.map_Ka)
    {
        float u = payload.tex_coords.x();
        float v = payload.tex_coords.y();

        return_color = mat.map_Ka->getColor(u, v);
    }

    Eigen::Vector3f texture_color;
    texture_color << return_color.x(), return_color.y(), return_color.z();

    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = texture_color / 255.f;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{{20, 20, 20}, {500, 500, 500}};
    auto l2 = light{{-20, 20, 0}, {500, 500, 500}};

    std::vector<light> lights = {l1, l2};
    Eigen::Vector3f amb_light_intensity{10, 10, 10};
    Eigen::Vector3f eye_pos{0, 0, 10};

    float p = 150;

    Eigen::Vector3f color = texture_color;
    Eigen::Vector3f point = payload.view_pos;
    Eigen::Vector3f normal = payload.normal;

    Eigen::Vector3f ambient = ka.cwiseProduct(amb_light_intensity);

    Eigen::Vector3f result_color = {0, 0, 0};
    result_color += ambient;

    for (auto& light : lights)
    {

        Eigen::Vector3f l = light.position - point;
        float r2 = l.x() * l.x() + l.y() * l.y() + l.z() * l.z();
        float ld_max = std::fmax(0.f, normal.dot(l.normalized()));
        Eigen::Vector3f diffuse = kd.cwiseProduct(light.intensity / r2) * ld_max;

        Eigen::Vector3f v = eye_pos - point;
        Eigen::Vector3f h = (v.normalized() + l.normalized()).normalized();
        float ls_max = std::fmax(0.f, normal.dot(h));
        Eigen::Vector3f specular = mat.Ks.cwiseProduct(light.intensity / r2) * std::pow(ls_max, p);

        result_color += diffuse + specular;
    }

    return result_color * 255.f;
}

Eigen::Vector3f texture_fragment_shader(const fragment_shader_payload& payload)
{
    Eigen::Vector3f return_color = {0, 0, 0};
    if (payload.texture)
    {
        // TODO: Get the texture value at the texture coordinates of the current fragment
        float u = payload.tex_coords.x();
        float v = payload.tex_coords.y();

        //return_color = payload.texture->getColor(u, v);
        return_color = payload.texture->getColorBilinear(u, v);
    }

    Eigen::Vector3f texture_color;
    texture_color << return_color.x(), return_color.y(), return_color.z();

    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = texture_color / 255.f;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{{20, 20, 20}, {500, 500, 500}};
    auto l2 = light{{-20, 20, 0}, {500, 500, 500}};

    std::vector<light> lights = {l1, l2};
    Eigen::Vector3f amb_light_intensity{10, 10, 10};
    Eigen::Vector3f eye_pos{0, 0, 10};

    float p = 150;

    Eigen::Vector3f color = texture_color;
    Eigen::Vector3f point = payload.view_pos;
    Eigen::Vector3f normal = payload.normal;

    Eigen::Vector3f ambient = ka.cwiseProduct(amb_light_intensity);

    Eigen::Vector3f result_color = {0, 0, 0};
    result_color += ambient;

    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.

        Eigen::Vector3f l = light.position - point;
        float r2 = l.x() * l.x() + l.y() * l.y() + l.z() * l.z();
        float ld_max = std::fmax(0.f, normal.dot(l.normalized()));
        Eigen::Vector3f diffuse = kd.cwiseProduct(light.intensity / r2) * ld_max;

        Eigen::Vector3f v = eye_pos - point;
        Eigen::Vector3f h = (v.normalized() + l.normalized()).normalized();
        float ls_max = std::fmax(0.f, normal.dot(h));
        Eigen::Vector3f specular = ks.cwiseProduct(light.intensity / r2) * std::pow(ls_max, p);

        result_color += diffuse + specular;
    }

    return result_color * 255.f;
}

Eigen::Vector3f phong_fragment_shader(const fragment_shader_payload& payload)
{
    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = payload.color;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{{20, 20, 20}, {500, 500, 500}};
    auto l2 = light{{-20, 20, 0}, {500, 500, 500}};

    std::vector<light> lights = {l1, l2};
    Eigen::Vector3f amb_light_intensity{10, 10, 10};
    Eigen::Vector3f eye_pos{0, 0, 10};

    float p = 150;

    Eigen::Vector3f color = payload.color;
    Eigen::Vector3f point = payload.view_pos;
    Eigen::Vector3f normal = payload.normal;

    Eigen::Vector3f ambient = ka.cwiseProduct(amb_light_intensity);

    Eigen::Vector3f result_color = {0, 0, 0};
    result_color += ambient;

    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.

        Eigen::Vector3f l = light.position - point;
        float r2 = l.x() * l.x() + l.y() * l.y() + l.z() * l.z();
        float ld_max = std::fmax(0.f, normal.dot(l.normalized()));
        Eigen::Vector3f diffuse = kd.cwiseProduct(light.intensity / r2) * ld_max;

        Eigen::Vector3f v = eye_pos - point;
        Eigen::Vector3f h = (v.normalized() + l.normalized()).normalized();
        float ls_max = std::fmax(0.f, normal.dot(h));
        Eigen::Vector3f specular = ks.cwiseProduct(light.intensity / r2) * std::pow(ls_max, p);

        result_color += diffuse + specular;
    }

    return result_color * 255.f;
}

Eigen::Vector3f displacement_fragment_shader(const fragment_shader_payload& payload)
{
    
    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = payload.color;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{{20, 20, 20}, {500, 500, 500}};
    auto l2 = light{{-20, 20, 0}, {500, 500, 500}};

    std::vector<light> lights = {l1, l2};
    Eigen::Vector3f amb_light_intensity{10, 10, 10};
    Eigen::Vector3f eye_pos{0, 0, 10};

    float p = 150;

    Eigen::Vector3f color = payload.color; 
    Eigen::Vector3f point = payload.view_pos;
    Eigen::Vector3f normal = payload.normal;

    float kh = 0.2, kn = 0.1;
    
    // TODO: Implement displacement mapping here
    // Let n = normal = (x, y, z)
    // Vector t = (x*y/sqrt(x*x+z*z),sqrt(x*x+z*z),z*y/sqrt(x*x+z*z))
    // Vector b = n cross product t
    // Matrix TBN = [t b n]
    // dU = kh * kn * (h(u+1/w,v)-h(u,v))
    // dV = kh * kn * (h(u,v+1/h)-h(u,v))
    // Vector ln = (-dU, -dV, 1)
    // Position p = p + kn * n * h(u,v)
    // Normal n = normalize(TBN * ln)

    // Let n = normal = (x, y, z)
    Eigen::Vector3f n = normal;

    float x = normal.x();
    float y = normal.y();
    float z = normal.z();
    float xz_sqrt = std::sqrt(x*x+z*z);

    // Vector t = (x*y/sqrt(x*x+z*z),sqrt(x*x+z*z),z*y/sqrt(x*x+z*z))
    Eigen::Vector3f t = {x*y/xz_sqrt, xz_sqrt, z*y/xz_sqrt};

    // Vector b = n cross product t
    Eigen::Vector3f b = n.cross(t);

    // Matrix TBN = [t b n]
    Eigen::Matrix3f TBN;
    TBN << t[0], b[0], n[0],
            t[1], b[1], n[1],
            t[2], b[2], n[2];

    float u = payload.tex_coords.x();
    float v = payload.tex_coords.y();
    float h = payload.texture->height;
    float w = payload.texture->width;

    // dU = kh * kn * (h(u+1/w,v)-h(u,v))
    // dV = kh * kn * (h(u,v+1/h)-h(u,v))
    float nu = u+1.0f/(float)w;
    while (nu > 1.0f) nu -= 1.0f;

    float nv = v+1.0f/(float)h;
    while (nv > 1.0f) nv -= 1.0f;

    float uv_norm = payload.texture->getColor(u, v).norm();
    float dU = kh*kn*((payload.texture->getColor(nu, v).norm() - uv_norm));
    float dV = kh*kn*((payload.texture->getColor(u,nv).norm() - uv_norm));

    // Vector ln = (-dU, -dV, 1)
    Eigen::Vector3f ln = {-dU, -dV, 1.0f};

    // Position p = p + kn * n * h(u,v)
    Eigen::Vector3f pos = point + kn * n * uv_norm;

    // Normal n = normalize(TBN * ln)
    n = (TBN * ln).normalized();

    Eigen::Vector3f ambient = ka.cwiseProduct(amb_light_intensity);

    Eigen::Vector3f result_color = {0, 0, 0};
    result_color += ambient;

    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.

        Eigen::Vector3f l = light.position - pos;
        float r2 = l.x() * l.x() + l.y() * l.y() + l.z() * l.z();
        float ld_max = std::fmax(0.f, n.dot(l.normalized()));
        Eigen::Vector3f diffuse = kd.cwiseProduct(light.intensity / r2) * ld_max;

        Eigen::Vector3f v = eye_pos - pos;
        Eigen::Vector3f h = (v.normalized() + l.normalized()).normalized();
        float ls_max = std::fmax(0.f, normal.dot(h));
        Eigen::Vector3f specular = ks.cwiseProduct(light.intensity / r2) * std::pow(ls_max, p);

        result_color += diffuse + specular;
    }

    return result_color * 255.f;
}


Eigen::Vector3f bump_fragment_shader(const fragment_shader_payload& payload)
{
    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = payload.color;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{{20, 20, 20}, {500, 500, 500}};
    auto l2 = light{{-20, 20, 0}, {500, 500, 500}};

    std::vector<light> lights = {l1, l2};
    Eigen::Vector3f amb_light_intensity{10, 10, 10};
    Eigen::Vector3f eye_pos{0, 0, 10};

    float p = 150;

    Eigen::Vector3f color = payload.color; 
    Eigen::Vector3f point = payload.view_pos;
    Eigen::Vector3f normal = payload.normal;

    float kh = 0.2, kn = 0.1;

    // TODO: Implement bump mapping here
    // Let n = normal = (x, y, z)
    // Vector t = (x*y/sqrt(x*x+z*z),sqrt(x*x+z*z),z*y/sqrt(x*x+z*z))
    // Vector b = n cross product t
    // Matrix TBN = [t b n]
    // dU = kh * kn * (h(u+1/w,v)-h(u,v))
    // dV = kh * kn * (h(u,v+1/h)-h(u,v))
    // Vector ln = (-dU, -dV, 1)
    // Normal n = normalize(TBN * ln)

    // Let n = normal = (x, y, z)
    Eigen::Vector3f n = normal;

    float x = normal.x();
    float y = normal.y();
    float z = normal.z();
    float xz_sqrt = std::sqrt(x*x+z*z);

    // Vector t = (x*y/sqrt(x*x+z*z),sqrt(x*x+z*z),z*y/sqrt(x*x+z*z))
    Eigen::Vector3f t = {x*y/xz_sqrt, xz_sqrt, z*y/xz_sqrt};

    // Vector b = n cross product t
    Eigen::Vector3f b = n.cross(t);

    // Matrix TBN = [t b n]
    Eigen::Matrix3f TBN;
    TBN << t[0], b[0], n[0],
           t[1], b[1], n[1],
           t[2], b[2], n[2];

    float u = payload.tex_coords.x();
    float v = payload.tex_coords.y();
    float h = payload.texture->height;
    float w = payload.texture->width;

    // dU = kh * kn * (h(u+1/w,v)-h(u,v))
    // dV = kh * kn * (h(u,v+1/h)-h(u,v))
    float nu = u+1.0f/(float)w;
    while (nu > 1.0f) nu -= 1.0f;

    float nv = v+1.0f/(float)h;
    while (nv > 1.0f) nv -= 1.0f;

    float uv_norm = payload.texture->getColor(u, v).norm();
    float dU = kh*kn*((payload.texture->getColor(nu, v).norm() - uv_norm));
    float dV = kh*kn*((payload.texture->getColor(u,nv).norm() - uv_norm));

    // Vector ln = (-dU, -dV, 1)
    Eigen::Vector3f ln = {-dU, -dV, 1.0f};

    // Normal n = normalize(TBN * ln)
    n = (TBN * ln).normalized();

    //Eigen::Vector3f result_color = n;
    Eigen::Vector3f result_color = n;

    return result_color * 255.f;
}

int main(int argc, const char** argv)
{
    DrawObj*     drawObj;
    //std::vector<Triangle*>  TriangleList;

    float        angle          = 140.0;
    bool         command_line   = false;

    std::string  filename       = "output.png";
    std::string  obj_path       = "../models/spot/";

    // Load .obj File
    drawObj = DrawObj::Load(obj_path.c_str(), "../models/spot/spot_triangulated_good.obj");
    //drawObj = DrawObj::Load("../models/lpshead/", "../models/lpshead/head_tri.obj");
    //drawObj = DrawObj::Load("../models/", "../models/bunny.obj");

    if (nullptr == drawObj)
    {
        return EXIT_FAILURE;
    }

    rst::rasterizer r(700, 700);

    auto texture_path = "hmap.jpg";
    //auto texture_path = "spot_texture.png";
    //auto texture_path = "spot_texture_small.png";
    r.set_texture(Texture(obj_path + texture_path));
    //std::function<Eigen::Vector3f(fragment_shader_payload)> active_shader = custom_fragment_shader;
    //std::function<Eigen::Vector3f(fragment_shader_payload)> active_shader = normal_fragment_shader;
    std::function<Eigen::Vector3f(fragment_shader_payload)> active_shader = texture_fragment_shader;
    //std::function<Eigen::Vector3f(fragment_shader_payload)> active_shader = phong_fragment_shader;

    Eigen::Vector3f eye_pos = {0.f, 0.f, 10.f};

    if (argc >= 2)
    {
        command_line = true;
        filename = std::string(argv[1]);

        if (argc == 3 && std::string(argv[2]) == "texture")
        {
            std::cout << "Rasterizing using the texture shader\n";
            active_shader = texture_fragment_shader;
            //texture_path = "spot_texture_small.png";
            texture_path = "spot_texture.png";
            r.set_texture(Texture(obj_path + texture_path));
        }
        else if (argc == 3 && std::string(argv[2]) == "normal")
        {
            std::cout << "Rasterizing using the normal shader\n";
            active_shader = normal_fragment_shader;
        }
        else if (argc == 3 && std::string(argv[2]) == "phong")
        {
            std::cout << "Rasterizing using the phong shader\n";
            active_shader = phong_fragment_shader;
        }
        else if (argc == 3 && std::string(argv[2]) == "bump")
        {
            std::cout << "Rasterizing using the bump shader\n";
            active_shader = bump_fragment_shader;
        }
        else if (argc == 3 && std::string(argv[2]) == "displacement")
        {
            std::cout << "Rasterizing using the bump shader\n";
            active_shader = displacement_fragment_shader;
        }
        else if (argc == 3 && std::string(argv[2]) == "custom")
        {
            std::cout << "Rasterizing using the custom shader\n";
            active_shader = custom_fragment_shader;
            angle = 20.f;
            eye_pos = {0.f, 0.f, 2.f};
        }
    }

    r.set_vertex_shader(vertex_shader);
    r.set_fragment_shader(active_shader);

    int key = 0;
    int frame_count = 0;

    if (command_line)
    {
        r.clear(rst::Buffers::Color | rst::Buffers::Depth);
        r.set_model(get_model_matrix(angle));
        r.set_view(get_view_matrix(eye_pos));
        r.set_projection(get_projection_matrix(45.0, 1, 0.1, 50));

        r.draw(drawObj);
        cv::Mat image(700, 700, CV_32FC3, r.frame_buffer());
        image.convertTo(image, CV_8UC3, 1.0f);
        cv::cvtColor(image, image, cv::COLOR_RGB2BGR);

        cv::imwrite(filename, image);

        return 0;
    }

    struct  timeval    tv;
    int64   next_time   = 0;
    int64   cur_time    = 0;
    int     frame_rate  = 0;
    int     temp_frame_rate  = 0;

    gettimeofday(&tv, NULL);
    next_time = tv.tv_sec * 1000 + tv.tv_usec / 1000 + 1000;

    while(key != 27)
    {
        r.clear(rst::Buffers::Color | rst::Buffers::Depth);

        r.set_model(get_model_matrix(angle));
        r.set_view(get_view_matrix(eye_pos));
        r.set_projection(get_projection_matrix(45.0, 1, 0.1, 50));

        //r.draw(pos_id, ind_id, col_id, rst::Primitive::Triangle);
        r.draw(drawObj);
        cv::Mat image(700, 700, CV_32FC3, r.frame_buffer());
        image.convertTo(image, CV_8UC3, 1.0f);
        cv::cvtColor(image, image, cv::COLOR_RGB2BGR);

        cv::imshow("image", image);
        cv::imwrite(filename, image);
        key = cv::waitKey(10);

        switch (key)
        {
            case 'a': angle -= 10.f; break;
            case 'd': angle += 10.f; break;
            case 'j': eye_pos.x() -= 2.f; break;
            case 'l': eye_pos.x() += 2.f; break;
            case 'i': eye_pos.z() -= 2.f; break;
            case 'k': eye_pos.z() += 2.f; break;
            case 'u': eye_pos.y() -= 2.f; break;
            case 'o': eye_pos.y() += 2.f; break;
            default: break;
        }

        // calcuate frame rate
        ++temp_frame_rate;

        std::cout << "frame count:" << frame_count++ <<  ", rate: " << frame_rate << std::endl;
        //std::cout << "angle:" << angle << ", eye_pos: x:" << eye_pos.x() << ", y:" << eye_pos.y() << ", z:" << eye_pos.z() << std::endl;

        gettimeofday(&tv, NULL);
        cur_time = tv.tv_sec * 1000 + tv.tv_usec / 1000;
        if (next_time <= cur_time)
        {
            next_time = cur_time + 1000;
            frame_rate = temp_frame_rate;
            temp_frame_rate = 0;
        }
    }

    return 0;
}
