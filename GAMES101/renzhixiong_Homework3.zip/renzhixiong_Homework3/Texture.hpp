//
// Created by LEI XU on 4/27/19.
//

#ifndef RASTERIZER_TEXTURE_H
#define RASTERIZER_TEXTURE_H
#include "global.hpp"
#include <eigen3/Eigen/Eigen>
#include <opencv2/opencv.hpp>
class Texture{
private:
    cv::Mat image_data;

public:
    Texture(const std::string& name)
    {
        image_data = cv::imread(name);
        cv::cvtColor(image_data, image_data, cv::COLOR_RGB2BGR);
        width = image_data.cols;
        height = image_data.rows;
    }

    int width, height;

    Eigen::Vector3f getColor(float u, float v)
    {
        int u_img = u * width;
        int v_img = (1.f - v) * height;

        // protect u, v [0,1)
        if ((u_img >= width) || (u_img < -width)) u_img %= width;
        if (u_img < 0) u_img += width;

        if ((v_img >= height) || (v_img < -height)) v_img %= height;
        if (v_img < 0) v_img += height;

        auto color = image_data.at<cv::Vec3b>(v_img, u_img);
        return Eigen::Vector3f(color[0], color[1], color[2]);
    }

//    Eigen::Vector3f getColorBilinear(float u, float v)
//    {
//        float u_off = u * (float)width;
//        float v_off = (1.f - v) * (float)height;
//
//        int u_idx = (int)u_off;
//        int v_idx = (int)v_off;
//
//        // protect u, v [0,1)
//        if ((u_idx >= width) || (u_idx < -width)) u_idx %= width;
//        if (u_idx < 0) u_idx += width;
//
//        if ((v_idx >= height) || (v_idx < -height)) v_idx %= height;
//        if (v_idx < 0) v_idx += height;
//
//        int u_neig = 0;
//        int v_neig = 0;
//
//        float t = 1.f;
//        float s = 1.f;
//
//        u_off -= (float)u_idx;
//        v_off -= (float)v_idx;
//
//        if (u_off < 0.5f)
//        {
//            u_neig = u_idx-1;
//            s = 0.5f - u_off;
//        }
//        else if (u_off > 0.5f)
//        {
//            u_neig = u_idx+1;
//            s = u_off - 0.5f;
//        }
//
//        if (v_off < 0.5f)
//        {
//            v_neig = v_idx-1;
//            t = 0.5f - v_off;
//        }
//        else if (v_off > 0.5f)
//        {
//            v_neig = v_idx+1;
//            t = v_off - 0.5f;
//        }
//
//        Eigen::Vector3f col1 = {0.f, 0.f, 0.f};
//        Eigen::Vector3f col2 = {0.f, 0.f, 0.f};
//
//        getColorByIndex(u_idx, v_idx, col1);
//
//        if(u_neig != u_idx)
//        {
//            Eigen::Vector3f c;
//            if (getColorByIndex(u_neig, v_idx, c))
//            {
//                lerp(s, col1, c, col1);
//            }
//        }
//
//        if(v_neig != v_idx)
//        {
//            if (getColorByIndex(u_idx, v_neig, col2))
//            {
//                Eigen::Vector3f c;
//                if (getColorByIndex(u_neig, v_neig, c))
//                {
//                    lerp(s, col2, c, col2);
//                }
//            }
//        }
//
//        lerp(t, col1, col2, col1);
//
//        return Eigen::Vector3f(col1[0], col1[1], col1[2]);
//    }

    Eigen::Vector3f getColorBilinear(float u, float v)
    {
        float   x_off   = u * (float)width;
        float   y_off   = v * (float)height;
        int     x_idx   = (int)x_off;
        int     y_idx   = (int)y_off;

        int     nx_idx  = 0;
        int     ny_idx  = 0;

        float   t       = 1.f;
        float   s       = 1.f;

        // protect u, v [0,1)
        if ((x_idx >= width) || (x_idx < -width)) x_idx %= width;
        if (x_idx < 0) x_idx += width;

        if ((y_idx >= height) || (y_idx < -height)) y_idx %= height;
        if (y_idx < 0) y_idx += height;

        x_off -= (float)x_idx;
        y_off -= (float)y_idx;

        if (x_off < 0.5f)
        {
            nx_idx = x_idx - 1;
            s      = 0.5f - x_off;
        }
        else if (x_off > 0.5f)
        {
            nx_idx = x_idx + 1;
            s      = x_off - 0.5f;
        }

        if (y_off < 0.5f)
        {
            ny_idx = y_idx - 1;
            t      = 0.5f - y_off;
        }
        else if (y_off > 0.5f)
        {
            ny_idx = y_idx + 1;
            t      = y_off - 0.5f;
        }

        Eigen::Vector3f col1 = {0.f, 0.f, 0.f};
        Eigen::Vector3f col2 = {0.f, 0.f, 0.f};

        getColorByIndex(x_idx, y_idx, col1);

        if(nx_idx != x_idx)
        {
            Eigen::Vector3f c;
            if (getColorByIndex(nx_idx, y_idx, c))
            {
                lerp(s, col1, c, col1);
            }
        }

        if(ny_idx != y_idx)
        {
            if (getColorByIndex(x_idx, ny_idx, col2))
            {
                Eigen::Vector3f c;
                if (getColorByIndex(nx_idx, ny_idx, c))
                {
                    lerp(s, col2, c, col2);
                }
            }
        }

        lerp(t, col1, col2, col1);

        return Eigen::Vector3f(col1[0], col1[1], col1[2]);
    }

    bool getColorByIndex(int x, int y, Eigen::Vector3f& col)
    {
        col.x() = 0.f;
        col.y() = 0.f;
        col.z() = 0.f;

        if ((x < 0) || (y >= width)) return false;
        if ((y < 0) || (y >= height)) return false;

        col = getColor((float)x/(float)width, (float)y/(float)height);

        return true;
    }

    void lerp(float f, const Eigen::Vector3f& a, const Eigen::Vector3f& b, Eigen::Vector3f& c)
    {
        float df = 1.0f - f;
        c.x() = df * a.x() + f * b.x();
        c.y() = df * a.y() + f * b.y();
        c.z() = df * a.z() + f * b.z();
    }
};
#endif //RASTERIZER_TEXTURE_H
