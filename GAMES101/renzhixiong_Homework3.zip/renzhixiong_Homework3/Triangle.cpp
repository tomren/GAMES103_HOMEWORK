//
// Created by LEI XU on 4/11/19.
//

#include "Triangle.hpp"
#include <algorithm>
#include <array>
#include "Texture.hpp"
#include "OBJ_Loader.h"

Triangle::Triangle() {
    v[0] << 0,0,0,1;
    v[1] << 0,0,0,1;
    v[2] << 0,0,0,1;

    color[0] << 0.0, 0.0, 0.0;
    color[1] << 0.0, 0.0, 0.0;
    color[2] << 0.0, 0.0, 0.0;

    tex_coords[0] << 0.0, 0.0;
    tex_coords[1] << 0.0, 0.0;
    tex_coords[2] << 0.0, 0.0;
}

void Triangle::setVertex(int ind, Vector4f ver){
    v[ind] = ver;
}
void Triangle::setNormal(int ind, Vector3f n){
    normal[ind] = n;
}
void Triangle::setColor(int ind, float r, float g, float b) {
    if((r<0.0) || (r>255.) ||
       (g<0.0) || (g>255.) ||
       (b<0.0) || (b>255.)) {
        fprintf(stderr, "ERROR! Invalid color values");
        fflush(stderr);
        exit(-1);
    }

    color[ind] = Vector3f((float)r/255.,(float)g/255.,(float)b/255.);
    return;
}
void Triangle::setTexCoord(int ind, Vector2f uv) {
    tex_coords[ind] = uv;
}

std::array<Vector4f, 3> Triangle::toVector4() const
{
    std::array<Vector4f, 3> res;
    std::transform(std::begin(v), std::end(v), res.begin(), [](auto& vec) { return Vector4f(vec.x(), vec.y(), vec.z(), 1.f); });
    return res;
}

void Triangle::setNormals(const std::array<Vector3f, 3>& normals)
{
    normal[0] = normals[0];
    normal[1] = normals[1];
    normal[2] = normals[2];
}

void Triangle::setColors(const std::array<Vector3f, 3>& colors)
{
    auto first_color = colors[0];
    setColor(0, colors[0][0], colors[0][1], colors[0][2]);
    setColor(1, colors[1][0], colors[1][1], colors[1][2]);
    setColor(2, colors[2][0], colors[2][1], colors[2][2]);
}

DrawMaterial::~DrawMaterial()
{
    if(nullptr != map_Ka)
    {
        delete map_Ka;
        map_Ka = nullptr;
    }

    if(nullptr != map_Kd)
    {
        delete map_Kd;
        map_Kd = nullptr;
    }

    if(nullptr != map_Ks)
    {
        delete map_Ks;
        map_Ks = nullptr;
    }

    if(nullptr != map_Ns)
    {
        delete map_Ns;
        map_Ns = nullptr;
    }

    if(nullptr != map_d)
    {
        delete map_d;
        map_d = nullptr;
    }

    if(nullptr != map_bump)
    {
        delete map_bump;
        map_bump = nullptr;
    }
}

void DrawMaterial::Init(const char* dirPath, const objl::Material& m)
{
    name = m.name;
    Ka << m.Ka.X, m.Ka.Y, m.Ka.Z;
    Kd << m.Kd.X, m.Kd.Y, m.Kd.Z;
    Ks << m.Ks.X, m.Ks.Y, m.Ks.Z;
    Ns = m.Ns;
    Ni = m.Ni;
    d  = m.d;
    illum = m.illum;

    map_Ka = nullptr;
    map_Kd = nullptr;
    map_Ks = nullptr;
    map_Ns = nullptr;
    map_d = nullptr;
    map_bump = nullptr;

    if(0 != strcmp("", m.map_Ka.c_str()))
    {
        map_Ka = new Texture(dirPath + m.map_Ka);
    }

    if(0 != strcmp("", m.map_Kd.c_str()))
    {
        map_Kd = new Texture(dirPath + m.map_Kd);
    }

    if(0 != strcmp("", m.map_Ks.c_str()))
    {
        map_Ks = new Texture(dirPath + m.map_Ks);
    }

    if(0 != strcmp("", m.map_d.c_str()))
    {
        map_d = new Texture(dirPath + m.map_d);
    }

    if(0 != strcmp("", m.map_bump.c_str()))
    {
        map_bump = new Texture(dirPath + m.map_bump);
    }
}

DrawObj* DrawObj::Load(const char* dir, const char* obj_path)
{
    objl::Loader loader;
    bool res = loader.LoadFile(obj_path);
    if (!res)
    {
        return nullptr;
    }

    DrawObj* drawObj = new DrawObj();

    for(auto mesh:loader.LoadedMeshes)
    {
//        if ( 0 != strcmp("walls", mesh.MeshName.c_str()))
//        {
//            continue;
//        }

        DrawMesh* drawMesh = new DrawMesh();
        drawMesh->meshName = mesh.MeshName;
        drawMesh->material.Init(dir, mesh.MeshMaterial);

        drawMesh->aabb.Clear();

        std::vector<objl::Vertex>& verts = mesh.Vertices;

        //for(int i=0;i<mesh.Vertices.size();i+=1)
        for(int i=0; (i+2)<mesh.Vertices.size(); i+=3)
        {
            Triangle* t = new Triangle();
            for(int j=0;j<3;++j)
            {
                int idx = i+j;
                auto& p = verts[idx].Position;
                auto& n = verts[idx].Normal;
                auto& tex = verts[idx].TextureCoordinate;

                t->setVertex(j, Vector4f(p.X, p.Y, p.Z, 1.0f));
                t->setNormal(j, Vector3f(n.X, n.Y, n.Z));
                t->setTexCoord(j, Vector2f(tex.X, tex.Y));

                drawMesh->aabb.Calc(p.X, p.Y, p.Z);
            }
            drawMesh->triangles.push_back(t);
        }

        drawObj->meshs.push_back(drawMesh);
    }

    return drawObj;
}