完成了普通练习和两个提高部分

生成的图片开启了 MSAA

提高一
- 使用了 rock 和 bunny 模型，eye_pos 调整 (0, 0, 25)
- head_tri.obj 模型，angle为20, eye_pos 调整 (0, 0, 2)

提高二，使用了自己缩放的 256x256 图片作为演示

## 练习

#### normal shader
![](images\normal.png)

#### phong shader
![](images\phong.png)

#### texture shader
![](images\texture.png)

#### bump shader
![](images\bump.png)

#### displacement shader
![](images\displacement.png)

## 提高
### 加载其他模型
/models/rock/rock.obj
![](images\rock_eye_25.png)

/models/bunny.obj
![](images\bunny.png)

/models/lpshead/head_tri.obj
使用的 custom_fragment_shader
![](images\face_msaa.png)

### bilinear 效果
#### 256x256 原图效果
![](images\small_256x256.png)

#### 256x256 bilinear
![](images\small_256x256_bilinear.png)

#### 原图 bilinear
![](images\texture_bilinear.png)

#### bilinear 使用的缩放图
![](images\spot_texture_small.png)