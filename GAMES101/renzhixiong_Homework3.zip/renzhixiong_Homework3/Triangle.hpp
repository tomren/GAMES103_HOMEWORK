//
// Created by LEI XU on 4/11/19.
//

#ifndef RASTERIZER_TRIANGLE_H
#define RASTERIZER_TRIANGLE_H

#include <eigen3/Eigen/Eigen>
#include <float.h>

class Texture;

using namespace Eigen;
namespace objl
{
    class Material;
}

class Triangle{
public:
    Vector4f v[3]; /*the original coordinates of the triangle, v0, v1, v2 in counter clockwise order*/
    /*Per vertex values*/
    Vector3f color[3]; //color at each vertex;
    Vector2f tex_coords[3]; //texture u,v
    Vector3f normal[3]; //normal vector for each vertex

    Texture *tex= nullptr;
    Triangle();

    Eigen::Vector4f const a() { return v[0]; }
    Eigen::Vector4f const b() { return v[1]; }
    Eigen::Vector4f const c() { return v[2]; }

    void setVertex(int ind, Vector4f ver); /*set i-th vertex coordinates */
    void setNormal(int ind, Vector3f n); /*set i-th vertex normal vector*/
    void setColor(int ind, float r, float g, float b); /*set i-th vertex color*/

    void setNormals(const std::array<Vector3f, 3>& normals);
    void setColors(const std::array<Vector3f, 3>& colors);
    void setTexCoord(int ind,Vector2f uv ); /*set i-th vertex texture coordinate*/
    std::array<Vector4f, 3> toVector4() const;
};

// AABB
// ==================================================
class AABB
{
public:
    void Clear()
    {
        min.x() = FLT_MAX;
        min.y() = FLT_MAX;
        min.z() = FLT_MAX;
        min.w() = 1.0f;

        max.x() = FLT_MIN;
        max.y() = FLT_MIN;
        max.z() = FLT_MIN;
        max.w() = 1.0f;
    }

    void Calc(float x, float y, float z)
    {
        if (x < min.x()) min.x() = x;
        if (y < min.y()) min.y() = y;
        if (z < min.z()) min.z() = z;
        if (x > max.x()) max.x() = x;
        if (y > max.y()) max.y() = y;
        if (z > max.z()) max.z() = z;
    }

    bool Test(float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
    {
        if ((max.x() < minX) || (min.x() > maxX)) return false;
        if ((max.y() < minY) || (min.y() > maxY)) return false;
        if ((max.z() < minZ) || (min.z() > maxZ)) return false;
        return true;
    }

    Eigen::Vector4f min;
    Eigen::Vector4f max;
};

// Draw Material Struct
class DrawMaterial
{
public:
    ~DrawMaterial();

    void Init(const char* dirPath, const objl::Material& m);

    // Material Name
    std::string name;
    // Ambient Color
    Eigen::Vector3f Ka;
    // Diffuse Color
    Eigen::Vector3f Kd;
    // Specular Color
    Eigen::Vector3f Ks;
    // Specular Exponent
    float Ns;
    // Optical Density
    float Ni;
    // Dissolve
    float d;
    // Illumination
    int illum;

    // Ambient Texture Map
    Texture* map_Ka;
    // Diffuse Texture Map
    Texture* map_Kd;
    // Specular Texture Map
    Texture* map_Ks;
    // Specular Hightlight Map
    Texture* map_Ns;
    // Alpha Texture Map
    Texture* map_d;
    // Bump Map
    Texture* map_bump;
};

// Draw Mesh Struct
class DrawMesh
{
public:
    // Mesh Name
    std::string             meshName;
    std::vector<Triangle*>  triangles;
    DrawMaterial            material;
    AABB                    aabb;
};

// Draw Obj Struct
class DrawObj
{
public:
    bool isOk = false;
    std::vector<DrawMesh*> meshs;

    static DrawObj* Load(const char* dir, const char* obj_path);
};

// ==================================================

#endif //RASTERIZER_TRIANGLE_H
