//
// Created by LEI XU on 5/16/19.
//

#ifndef RAYTRACING_MATERIAL_H
#define RAYTRACING_MATERIAL_H

#include "Vector.hpp"
#include "Matrix.hpp"
#include "TexPlane.hpp"
#include "Triangle.hpp"
#include "Intersection.hpp"

#define GLINT_SAMPLE_COUNT 4

enum MaterialType { DIFFUSE, GLOSSY, GLINT1, GLINT2, GLINT3, GLINT4, GLINT5};

typedef int length_t;

typedef std::pair<Bounds2, uint32_t> SpatialNode;

class Texture;

struct GaussianElementData
{
    // (u, n(u))
    Vector4f seed;

    // The matrices required for the 2d slice
    Matrix2x2 A;
    Matrix2x2 B;
    Matrix2x2 C;

    // Coefficient that integrates to 1
    float coeff;
};

class Material
{
private:
    // Compute reflection direction
    Vector3f reflect(const Vector3f &I, const Vector3f &N) const
    {
        return I - 2 * dotProduct(I, N) * N;
    }

    // Compute refraction direction using Snell's law
    //
    // We need to handle with care the two possible situations:
    //
    //    - When the ray is inside the object
    //
    //    - When the ray is outside.
    //
    // If the ray is outside, you need to make cosi positive cosi = -N.I
    //
    // If the ray is inside, you need to invert the refractive indices and negate the normal N
    Vector3f refract(const Vector3f &I, const Vector3f &N, const float &ior) const
    {
        float cosi = clamp(-1, 1, dotProduct(I, N));
        float etai = 1, etat = ior;
        Vector3f n = N;
        if (cosi < 0) { cosi = -cosi; } else { std::swap(etai, etat); n= -N; }
        float eta = etai / etat;
        float k = 1 - eta * eta * (1 - cosi * cosi);
        return k < 0 ? 0 : eta * I + (eta * cosi - sqrtf(k)) * n;
    }

    // Compute Fresnel equation
    //
    // \param I is the incident view direction
    //
    // \param N is the normal at the intersection point
    //
    // \param ior is the material refractive index
    //
    // \param[out] kr is the amount of light reflected
    void fresnel(const Vector3f &I, const Vector3f &N, const float &ior, float &kr) const
    {
        float cosi = clamp(-1, 1, dotProduct(I, N));
        float etai = 1, etat = ior;
        if (cosi > 0) {  std::swap(etai, etat); }
        // Compute sini using Snell's law
        float sint = etai / etat * sqrtf(std::max(0.f, 1 - cosi * cosi));
        // Total internal reflection
        if (sint >= 1) {
            kr = 1;
        }
        else {
            float cost = sqrtf(std::max(0.f, 1 - sint * sint));
            cosi = fabsf(cosi);
            float Rs = ((etat * cosi) - (etai * cost)) / ((etat * cosi) + (etai * cost));
            float Rp = ((etai * cosi) - (etat * cost)) / ((etai * cosi) + (etat * cost));
            kr = (Rs * Rs + Rp * Rp) / 2;
        }
        // As a consequence of the conservation of energy, transmittance is given by:
        // kt = 1 - kr;
    }

    Vector3f toWorld(const Vector3f &a, const Vector3f &N)
    {
        Vector3f B, C;
        if (std::fabs(N.x) > std::fabs(N.y)){
            float invLen = 1.0f / std::sqrt(N.x * N.x + N.z * N.z);
            C = Vector3f(N.z * invLen, 0.0f, -N.x *invLen);
        }
        else {
            float invLen = 1.0f / std::sqrt(N.y * N.y + N.z * N.z);
            C = Vector3f(0.0f, N.z * invLen, -N.y *invLen);
        }
        crossProduct(C, N, B);
        return a.x * B + a.y * C + a.z * N;
    }

public:
    MaterialType m_type;
    //Vector3f m_color;
    Vector3f m_emission;
    float ior;
    Vector3f Kd, Ks;
    float specularExponent;
    Texture* texture;

    static void Init();
    void InitGaussianData();

    Material(MaterialType t=DIFFUSE, Vector3f e=Vector3f(0,0,0));
    MaterialType getType();
    //inline Vector3f getColor();
    Vector3f getColorAt(double u, double v);
    Vector3f getEmission();
    bool hasEmission();

    // sample a ray by Material properties
    Vector3f sample(const Vector3f &wi, const Vector3f &N);
    // given a ray, calculate the PdF of this ray
    float pdf(const Vector3f &wi, const Vector3f &wo, const Vector3f &N);
    // given a ray, calculate the contribution of this ray
    Vector3f eval(const Ray& ray, int depth, const Intersection* inter, const Vector3f &wi, const Vector3f &wo, const Vector3f &N);

    // calculate fresnel term
    float fresnelSchlick(const Vector3f& wi, const Vector3f &N);
    float geometryShadowing(const Vector3f& l, const Vector3f &v,
                                   const Vector3f& n, const Vector3f &h);
    float distributionGGX(const Vector3f& n, const Vector3f &h, float a);

    // P-NDF
    void getSampleDifferential(const Vector3f& p, Vector3f* diff);

    float countSpatial(const Bounds2& query);
    float countDirection(const Vector3f &wi, const Vector3f &wo) const;

    Vector3f ChangeBasisTo(Vector3f const& in, Vector3f const& X, Vector3f const& Y, Vector3f const& Z);
    Vector2f Min(const Vector2f& a, const Vector2f& b);
    Vector2f Max(const Vector2f& a, const Vector2f& b);
    Vector2f Mix(const Vector2f& a, const Vector2f& b, float c);

    Vector2f Clamp(Vector2f x, Vector2f minVal, Vector2f maxVal);
    float EvaluatePNDF(Vector2f uv, Vector2f st);
    float EvaluateGaussian(float c, const Vector2f& x, const Vector2f& u, const Matrix2x2& InvCov);
    float GetGaussianCoefficient(const Matrix2x2& InvCov);

    Vector2f SampleNormalMap(Vector2f uv);
    Vector2f SampleRawNormal(int32_t x, int32_t y);
    Vector3f GetColor(int32_t x, int32_t y);

    Matrix2x2 SampleNormalMapJacobian(Vector2f uv);

    void setTexture(Texture* tex)
    {
        texture = tex;
        InitGaussianData();
    }

    static std::vector<Vector4f> set_p;
    GaussianElementData** gaussians;
};

#endif //RAYTRACING_MATERIAL_H
