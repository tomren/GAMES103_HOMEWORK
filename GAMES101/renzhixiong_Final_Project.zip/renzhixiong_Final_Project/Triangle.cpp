#include "Triangle.hpp"
#include "Material.hpp"
#include "OBJ_Loader.hpp"
#include "Intersection.hpp"
#include "BVH.hpp"
#include <cassert>
#include <array>

bool rayTriangleIntersect(const Vector3f& v0, const Vector3f& v1,
                          const Vector3f& v2, const Vector3f& orig,
                          const Vector3f& dir, float& tnear, float& u, float& v)
{
    Vector3f edge1 = v1 - v0;
    Vector3f edge2 = v2 - v0;
    Vector3f pvec;
    crossProduct(dir, edge2, pvec);
    float det = dotProduct(edge1, pvec);
    if (det == 0 || det < 0)
        return false;

    Vector3f tvec = orig - v0;
    u = dotProduct(tvec, pvec);
    if (u < 0 || u > det)
        return false;

    Vector3f qvec;
    crossProduct(tvec, edge1, qvec);
    v = dotProduct(dir, qvec);
    if (v < 0 || u + v > det)
        return false;

    float invDet = 1 / det;

    tnear = dotProduct(edge2, qvec) * invDet;
    u *= invDet;
    v *= invDet;

    return true;
}

Triangle::Triangle(Material* _m) : m(_m)
{

}

void Triangle::Init()
{
    e1 = vertices[1] - vertices[0];
    e2 = vertices[2] - vertices[0];

    crossProduct(e1, e2, normal);
    area = normal.norm() * 0.5f;

    if(m->m_type == GLINT1)
    {
        normal = (normals[0] + normals[1] + normals[2]) / 3.f;
    }
    normalize(normal);

//    Vector2f deltaUV1 = uvs[1]-uvs[0];
//    Vector2f deltaUV2 = uvs[2]-uvs[0];
//    float t = deltaUV1.x * deltaUV2.y - deltaUV1.y * deltaUV2.x;
//    if (t < EPSILON) { t = EPSILON; }
//    float r = 1.0f / t;
//    tangent = (e1*deltaUV2.y - e2*deltaUV1.y)*r;
//    normalize(tangent);
//    bitangent = (e2*deltaUV1.x - e1*deltaUV2.x)*r;
//    normalize(bitangent);

    float DeltaU1 = uvs[1].x - uvs[0].x;
    float DeltaV1 = uvs[1].y - uvs[0].y;
    float DeltaU2 = uvs[2].x - uvs[0].x;
    float DeltaV2 = uvs[2].y - uvs[0].y;

    float f = 1.0f / (DeltaU1 * DeltaV2 - DeltaU2 * DeltaV1);

    tangent.x = f * (DeltaV2 * e1.x - DeltaV1 * e2.x);
    tangent.y = f * (DeltaV2 * e1.y - DeltaV1 * e2.y);
    tangent.z = f * (DeltaV2 * e1.z - DeltaV1 * e2.z);
    normalize(tangent);

    bitangent.x = f * (-DeltaU2 * e1.x - DeltaU1 * e2.x);
    bitangent.y = f * (-DeltaU2 * e1.y - DeltaU1 * e2.y);
    bitangent.z = f * (-DeltaU2 * e1.z - DeltaU1 * e2.z);
    normalize(bitangent);
}

void Triangle::setVertex(int ind, Vector3f ver)
{
    vertices[ind] = ver;
}

void Triangle::setNormal(int ind, Vector3f n)
{
    normals[ind] = n;
    normalize(normals[ind]);
}

void Triangle::setTexCoord(int ind, Vector2f uv)
{
    uvs[ind] = uv;
}

inline bool Triangle::intersect(const Ray& ray)
{
    return true;
}

inline bool Triangle::intersect(const Ray& ray, float& tnear,
                                uint32_t& index) const
{
    return false;
}

inline Bounds3 Triangle::getBounds() { return Union(Bounds3(vertices[0], vertices[1]), vertices[2]); }

inline Intersection* Triangle::getIntersection(IsectBuilder& isectBuilder, const Ray& ray)
{
    if (dotProduct(ray.direction, normal) > 0.f)
    {
        return nullptr;
    }

    float u, v, t_tmp = 0.f;
    Vector3f pvec;
    crossProduct(ray.direction, e2, pvec);          // S1
    float det = dotProduct(e1, pvec);               // S1.E1
    if (fabs(det) < EPSILON)
    {
        return nullptr;
    }

    float det_inv = 1.f / det;                      // 1 / S1.E1
    Vector3f tvec = ray.origin - vertices[0];       // S
    u = dotProduct(tvec, pvec) * det_inv;           // S1.S
    if (u < 0.f || u > 1.f)
    {
        return nullptr;
    }

    Vector3f qvec;                                  // S2
    crossProduct(tvec, e1, qvec);
    v = dotProduct(ray.direction, qvec) * det_inv;  // S2.D
    if ((v < 0.f) || ((u + v) > 1.f))
    {
        return nullptr;
    }

    t_tmp = dotProduct(e2, qvec) * det_inv;         // S2.E2

    // TODO find ray triangle intersection
    if (t_tmp < 0.f)
    {
        return nullptr;
    }

    Intersection* isect = isectBuilder.NewIntersection();
    if (nullptr == isect)
    {
        return nullptr;
    }

    isect->coords = ray(t_tmp);
    isect->obj = this;
    isect->distance = t_tmp;
    isect->normal = normal;
    isect->m = m;

    return isect;
}

inline Vector3f Triangle::evalDiffuseColor(const Vector2f&) const
{
    return Vector3f(0.5, 0.5, 0.5);
}

void Triangle::Sample(Intersection &pos, float &pdf)
{
    float x = std::sqrt(get_random_float()), y = get_random_float();
    pos.coords = vertices[0] * (1.0f - x) + vertices[1] * (x * (1.0f - y)) + vertices[2] * (x * y);
    pos.tcoords = uvs[0] * (1.0f - x) + uvs[1] * (x * (1.0f - y)) + uvs[2] * (x * y);
    pos.normal = this->normal;
    pos.obj = this;
    pos.m = m;
    pdf = 1.0f / area;
}

bool Triangle::hasEmit()
{
    return m->hasEmission();
}

MeshTriangle::MeshTriangle(const std::string& filename, Material *mt = new Material())
{
    objl::Loader loader;
    loader.LoadFile(filename);
    area = 0;
    m = mt;
    assert(loader.LoadedMeshes.size() == 1);
    auto mesh = loader.LoadedMeshes[0];

    Vector3f min_vert = Vector3f{MAX_FLOAT, MAX_FLOAT, MAX_FLOAT};
    Vector3f max_vert = Vector3f{MIN_FLOAT, MIN_FLOAT, MIN_FLOAT};

    for (int i = 0; i < mesh.Vertices.size(); i += 3)
    {
        //std::array<Vector3f, 3> face_vertices;

        Triangle* t = new Triangle(m);

        for (int j = 0; j < 3; j++)
        {
            objl::Vector3& pos = mesh.Vertices[i+j].Position;
            objl::Vector3& nom = mesh.Vertices[i+j].Normal;
            objl::Vector2& tex = mesh.Vertices[i+j].TextureCoordinate;

            t->setVertex(j, Vector3f(pos.X, pos.Y, pos.Z));
            t->setNormal(j, Vector3f(nom.X, nom.Y, nom.Z));
            t->setTexCoord(j,Vector2f(tex.X, tex.Y));

            min_vert = Vector3f(std::min(min_vert.x, pos.X),
                                std::min(min_vert.y, pos.Y),
                                std::min(min_vert.z, pos.Z));
            max_vert = Vector3f(std::max(max_vert.x, pos.X),
                                std::max(max_vert.y, pos.Y),
                                std::max(max_vert.z, pos.Z));
        }

        t->Init();

        triangles.emplace_back(t);
    }

    bounding_box = Bounds3(min_vert, max_vert);

    std::vector<Object*> ptrs;
    for (auto& tri : triangles)
    {
        ptrs.push_back(tri);
        area += tri->area;
    }
    bvh = new BVHAccel(ptrs);
}

bool MeshTriangle::intersect(const Ray& ray, float& tnear, uint32_t& index) const
{
    bool intersect = false;
    for (uint32_t k = 0; k < numTriangles; ++k) {
        const Vector3f& v0 = vertices[vertexIndex[k * 3]];
        const Vector3f& v1 = vertices[vertexIndex[k * 3 + 1]];
        const Vector3f& v2 = vertices[vertexIndex[k * 3 + 2]];
        float t, u, v;
        if (rayTriangleIntersect(v0, v1, v2, ray.origin, ray.direction, t,
                                 u, v) &&
            t < tnear) {
            tnear = t;
            index = k;
            intersect |= true;
        }
    }

    return intersect;
}

void MeshTriangle::getSurfaceProperties(const Vector3f& P, const Vector3f& I,
                          const uint32_t& index, const Vector2f& uv,
                          Vector3f& N, Vector2f& st) const
{
    const Vector3f& v0 = vertices[vertexIndex[index * 3]];
    const Vector3f& v1 = vertices[vertexIndex[index * 3 + 1]];
    const Vector3f& v2 = vertices[vertexIndex[index * 3 + 2]];
    Vector3f e0 = v1 - v0;
    normalize(e0);
    Vector3f e1 = v2 - v1;
    normalize(e1);
    crossProduct(e0, e1, N);
    normalize(N);
    const Vector2f& st0 = stCoordinates[vertexIndex[index * 3]];
    const Vector2f& st1 = stCoordinates[vertexIndex[index * 3 + 1]];
    const Vector2f& st2 = stCoordinates[vertexIndex[index * 3 + 2]];
    st = st0 * (1 - uv.x - uv.y) + st1 * uv.x + st2 * uv.y;
}

Vector3f MeshTriangle::evalDiffuseColor(const Vector2f& st) const
{
    float scale = 5;
    float pattern = (fmodf(st.x * scale, 1) > 0.5) ^ (fmodf(st.y * scale, 1) > 0.5);
    return lerp(Vector3f(0.815, 0.235, 0.031), Vector3f(0.937, 0.937, 0.231), pattern);
}

Intersection* MeshTriangle::getIntersection(IsectBuilder& isectBuilder, const Ray& ray)
{
    if (nullptr == bvh)
    {
        return nullptr;
    }

    return bvh->Intersect(isectBuilder, ray);
}

void MeshTriangle::Sample(Intersection &pos, float &pdf)
{
    bvh->Sample(pos, pdf);
    pos.emit = m->getEmission();
}

bool MeshTriangle::hasEmit()
{
    return m->hasEmission();
}

