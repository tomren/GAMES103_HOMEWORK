//
// Created by LEI XU on 5/16/19.
//

#ifndef RAYTRACING_BVH_H
#define RAYTRACING_BVH_H

#include <atomic>
#include <vector>
#include <list>
#include <memory>
#include <ctime>
#include <unistd.h>
#include "Object.hpp"
#include "Ray.hpp"
#include "Bounds3.hpp"
#include "Intersection.hpp"
#include "Vector.hpp"

struct BVHBuildNode
{
    Bounds3         bounds;
    BVHBuildNode*   left;
    BVHBuildNode*   right;
    Object*         object;
    float           area;

public:
    // BVHBuildNode Public Methods
    BVHBuildNode()
    {
        bounds = Bounds3();
        left = nullptr;right = nullptr;
        object = nullptr;
    }
};

class BVHAccel
{
public:
    // BVHAccel Public Types
    enum class SplitMethod { NAIVE, SAH };

    // BVHAccel Public Methods
    BVHAccel(std::vector<Object*> p, int maxPrimsInNode = 1, SplitMethod splitMethod = SplitMethod::NAIVE);
    Bounds3 WorldBound() const;
    ~BVHAccel();

    inline Intersection* Intersect(IsectBuilder& isectBuilder, const Ray &ray) const
    {
        if (!root->bounds.IntersectP(ray))
        {
            return nullptr;
        }

        float tmin = std::numeric_limits<float>::max();
        bool flag = false;
        return BVHAccel::getIntersection(isectBuilder, root, ray, tmin, flag);
    }

    // 获得碰撞节点信息
    Intersection* getIntersection(IsectBuilder& isectBuilder, const BVHBuildNode* node, const Ray& ray, float& dist, bool& flag)const;

    bool IntersectP(const Ray &ray) const;

    // BVHAccel Private Methods
    BVHBuildNode* SAHBuild(std::vector<Object*>& objects);

    // 按坐标轴排序
    void SortObjectsByAxis(std::vector<Object*>& list, int dim);

    // BVHAccel Private Data
    const int maxPrimsInNode;
    const SplitMethod splitMethod;
    std::vector<Object*> primitives;

    void getSample(BVHBuildNode* node, float p, Intersection &pos, float &pdf);
    void Sample(Intersection &pos, float &pdf);

    BVHBuildNode* root;
};

#endif //RAYTRACING_BVH_H
