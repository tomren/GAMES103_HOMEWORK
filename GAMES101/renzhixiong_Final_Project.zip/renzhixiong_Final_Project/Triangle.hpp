#pragma once

#include <memory>
#include "Object.hpp"

class Material;
class Intersection;
class BVHAccel;

bool rayTriangleIntersect(const Vector3f& v0, const Vector3f& v1,
                          const Vector3f& v2, const Vector3f& orig,
                          const Vector3f& dir, float& tnear, float& u, float& v);

class Triangle : public Object
{
public:
    Vector3f  vertices[3];
    Vector3f  e1, e2;           // 2 edges v1-v0, v2-v0;

    Vector3f  color[3];         //color at each vertex;
    Vector2f  uvs[3];           //texture u,v
    Vector3f  normals[3];

    Vector3f  normal;
    Vector3f  tangent;
    Vector3f  bitangent;

    float     area;
    Material* m;
    Bounds3   bounds;

    Triangle(Material* _m);
    void Init();

    void setVertex(int ind, Vector3f ver); /*set i-th vertex coordinates */
    void setNormal(int ind, Vector3f n); /*set i-th vertex normal vector*/
    void setTexCoord(int ind, Vector2f uv); /*set i-th vertex texture coordinate*/

    bool intersect(const Ray& ray) override;
    bool intersect(const Ray& ray, float& tnear,
                   uint32_t& index) const override;
    Intersection* getIntersection(IsectBuilder& isectBuilder, const Ray& ray) override;
    void getSurfaceProperties(const Vector3f& P, const Vector3f& I,
                              const uint32_t& index, const Vector2f& uv,
                              Vector3f& N, Vector2f& st) const override
    {
        N = normal;
        //        throw std::runtime_error("triangle::getSurfaceProperties not
        //        implemented.");
    }
    Vector3f evalDiffuseColor(const Vector2f&) const override;
    Bounds3 getBounds() override;

    void Sample(Intersection &pos, float &pdf);

    float getArea() { return area; }

    bool hasEmit();
};

class MeshTriangle : public Object
{
public:
    MeshTriangle(const std::string& filename, Material *mt);

    bool intersect(const Ray& ray) { return true; }

    bool intersect(const Ray& ray, float& tnear, uint32_t& index) const;

    Bounds3 getBounds() { return bounding_box; }

    void getSurfaceProperties(const Vector3f& P, const Vector3f& I,
                              const uint32_t& index, const Vector2f& uv,
                              Vector3f& N, Vector2f& st) const;

    Vector3f evalDiffuseColor(const Vector2f& st) const;

    Intersection* getIntersection(IsectBuilder& isectBuilder, const Ray& ray);

    void Sample(Intersection &pos, float &pdf);

    float getArea() { return area; }

    bool hasEmit();

    Bounds3 bounding_box;
    std::unique_ptr<Vector3f[]> vertices;
    uint32_t numTriangles;
    std::unique_ptr<uint32_t[]> vertexIndex;
    std::unique_ptr<Vector2f[]> stCoordinates;

    std::vector<Triangle*>      triangles;

    BVHAccel* bvh;
    float area;

    Material* m;
};