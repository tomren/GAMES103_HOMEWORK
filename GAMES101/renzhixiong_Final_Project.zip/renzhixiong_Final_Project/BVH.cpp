#include <algorithm>
#include <cassert>
#include <sys/time.h>
#include "BVH.hpp"

BVHAccel::BVHAccel(std::vector<Object*> p, int maxPrimsInNode,
                   SplitMethod splitMethod)
    : maxPrimsInNode(std::min(255, maxPrimsInNode)), splitMethod(splitMethod),
      primitives(std::move(p))
{
    int64_t start, stop;
    timeval tv{};
    gettimeofday(&tv, NULL);
    start = tv.tv_sec * 1000 + (tv.tv_usec + 999)/1000;

    if (primitives.empty())
        return;

    root = SAHBuild(primitives);

    gettimeofday(&tv, NULL);
    stop = tv.tv_sec * 1000 + (tv.tv_usec + 999)/1000;
    int64_t diff = stop - start;
    int32_t hrs = diff / 3600000;
    int32_t mins = diff % 3600000 / 60000;
    int32_t secs = diff % 60000 / 1000;
    int32_t msecs = diff % 1000;

    printf("\rBVH Generation complete: \nTime Taken: %i hrs, %i mins, %i secs, %i msecs\n\n", hrs, mins, secs, msecs);
}

// =========================
// SAH
// =========================
BVHBuildNode* BVHAccel::SAHBuild(std::vector<Object*>& objects)
{
    BVHBuildNode* node = new BVHBuildNode();

    // 计算节点包围盒
    for (const auto& obj: objects)
    {
        if (nullptr == obj)
        {
            continue;
        }
        node->bounds.UpdateBounds(obj->getBounds());
    }

    // Compute bounds of all primitives in BVH node
    if (1 == objects.size())
    {
        // Create leaf _BVHBuildNode_
        node->object = objects[0];
        //node->area   = objects[0]->getBounds().SurfaceArea();
        node->area = objects[0]->getArea();
        return node;
    }

    // 拆分2个叶子节点
    if (2 == objects.size())
    {
        std::vector<Object*> leftList = std::vector{objects[0]};
        node->left = SAHBuild(leftList);
        //node->left->area = objects[0]->getBounds().SurfaceArea();
        node->left->area = objects[0]->getArea();

        std::vector<Object*> rightList = std::vector{objects[1]};
        node->right = SAHBuild(rightList);
        //node->right->area = objects[0]->getBounds().SurfaceArea();
        node->right->area = objects[1]->getArea();

        node->area = node->left->area + node->right->area;
        return node;
    }

    // 计算出最大的轴向
    int dim = node->bounds.maxExtent();
    // 将物体按这个轴由小到大排序
    SortObjectsByAxis(objects, dim);

    // 计算轴距
    float axisDist = 0.f;
    float axisMin  = 0.f;
    float axisMax  = 0.f;
    node->bounds.getAxisBound(dim, axisMin, axisMax);
    axisDist = axisMax - axisMin;

    // 分桶，计算每个桶的步长
    const int32_t stepCount = 31;
    float splitStep = axisDist / stepCount;

    float   minCost = std::numeric_limits<float>::max();
    int32_t minIdx  = 0;

    Bounds3 leftBounds;     // 从低到高的包围盒
    Bounds3 rightBounds;    // 从高到低的包围盒
    int32_t objIdx = 0;
    bool    dirty = false;
    int32_t objSize = objects.size();

    // 从低到高按步长移动，当有变更时计算 cost
    for (float left = axisMin + splitStep; left < axisMax; left += splitStep)
    {
        // 如果物体进入桶的范围，则重新计算 left 包围盒
        for (; objIdx < objSize; ++objIdx)
        {
            float dist = objects[objIdx]->getBounds().CentroidByAxis(dim);
            if (dist > left)
            {
                break;
            }

            leftBounds.UpdateBounds(objects[objIdx]->getBounds());
            dirty |= true;
        }

        if (!dirty)
        {
            continue;
        }

        // 重置标记，并计算 right 包围盒
        dirty = false;
        rightBounds.Clear();
        for (int32_t i = objIdx; i < objSize; ++i)
        {
            rightBounds.UpdateBounds(objects[i]->getBounds());
        }

        //if (objIdx < 1) { continue; }

        float cost = .125f + (float)(objIdx + 1) * leftBounds.SurfaceArea();
        cost += (float)(objSize - objIdx) * rightBounds.SurfaceArea();
        cost /= node->bounds.SurfaceArea();

        // 保留最小消耗的数值，并记录下标
        if (cost < minCost)
        {
            minCost = cost;
            minIdx = objIdx;
        }
    }

    // 如果左区小于1个，则至少添加1个
    if (minIdx < 1)
    {
        minIdx = 1;
    }
        // 如果右区小于1个，则至少添加1个
    else if(minIdx == objSize)
    {
        minIdx = objSize -1;
    }

    // 按最小标记为，重新划分两块
    auto middling = objects.begin() + minIdx;
    auto leftshapes = std::vector<Object*>(objects.begin(), middling);
    auto rightshapes = std::vector<Object*>(middling, objects.end());

    assert(objects.size() == (leftshapes.size() + rightshapes.size()));

    node->left = SAHBuild(leftshapes);
    node->right = SAHBuild(rightshapes);

    node->area = node->left->area + node->right->area;

    return node;
}

// =========================
// 按坐标轴排序
// =========================
void BVHAccel::SortObjectsByAxis(std::vector<Object*>& list, int dim)
{
    switch (dim)
    {
        case X_AXIS:
            std::sort(list.begin(), list.end(), [](auto f1, auto f2)
            {
                return f1->getBounds().Centroid().x < f2->getBounds().Centroid().x;
            });
            break;
        case Y_AXIS:
            std::sort(list.begin(), list.end(), [](auto f1, auto f2)
            {
                return f1->getBounds().Centroid().y < f2->getBounds().Centroid().y;
            });
            break;
        case Z_AXIS:
            std::sort(list.begin(), list.end(), [](auto f1, auto f2)
            {
                return f1->getBounds().Centroid().z < f2->getBounds().Centroid().z;
            });
            break;
        default:
            break;
    }
}

// =========================
// 获得碰撞节点信息
// =========================
Intersection* BVHAccel::getIntersection(IsectBuilder& isectBuilder, const BVHBuildNode* node, const Ray& ray, float& dist, bool& flag) const
{
    // TODO Traverse the BVH to find intersection
    if (nullptr == node)
    {
        return nullptr;
    }

    // Leaf Node
    if (nullptr != node->object)
    {
        Intersection* isect = node->object->getIntersection(isectBuilder, ray);
        if (nullptr == isect)
        {
            return nullptr;
        }

        if (isect->distance > dist)
        {
            isectBuilder.DelIntersection(isect);
            return nullptr;
        }

        dist = isect->distance;
        flag |= true;
        return isect;
    }

    Intersection* leftIsect = nullptr;
    float tmin = std::numeric_limits<float>::max();
    if (node->left->bounds.IntersectP(ray, &tmin))
    {
        if (flag)
        {
            if (tmin < dist)
            {
                leftIsect = getIntersection(isectBuilder, node->left, ray, dist, flag);
            }
        }
        else
        {
            leftIsect = getIntersection(isectBuilder, node->left, ray, dist, flag);
        }
    }

    Intersection* rightIsect = nullptr;
    tmin = std::numeric_limits<float>::max();
    if (node->right->bounds.IntersectP(ray, &tmin))
    {
        if (flag)
        {
            if (tmin < dist)
            {
                rightIsect = getIntersection(isectBuilder, node->right, ray, dist, flag);
            }
        }
        else
        {
            rightIsect = getIntersection(isectBuilder, node->right, ray, dist, flag);
        }
    }

    if (nullptr == leftIsect)
    {
        return rightIsect;
    }

    if (nullptr == rightIsect)
    {
        return leftIsect;
    }

    if (leftIsect->distance < rightIsect->distance)
    {
        isectBuilder.DelIntersection(rightIsect);
        return leftIsect;
    }

    isectBuilder.DelIntersection(leftIsect);
    return rightIsect;
}


void BVHAccel::getSample(BVHBuildNode* node, float p, Intersection &pos, float &pdf)
{
    if(node->left == nullptr || node->right == nullptr){
        node->object->Sample(pos, pdf);
        pdf *= node->area;
        return;
    }
    if(p < node->left->area) getSample(node->left, p, pos, pdf);
    else getSample(node->right, p - node->left->area, pos, pdf);
}

void BVHAccel::Sample(Intersection &pos, float &pdf)
{
    float p = std::sqrt(get_random_float()) * root->area;
    getSample(root, p, pos, pdf);
    pdf /= root->area;
}