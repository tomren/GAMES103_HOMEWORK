#include "Material.hpp"
#include <eigen3/Eigen/Eigen>
#include "Texture.hpp"

#define CAMERA_PIXEL_WIDTH 1.f
#define GAMMA_DIRECTION 0.087f
#define PI 3.1415926f
#define H_PI 1.5707963f
#define D_PI 6.2831852f

struct DirectionTri
{
    Vector2f vertices[3];
    DirectionTri(const Vector2f &p1, const Vector2f &p2, const Vector2f &p3)
    {
        vertices[0] = p1, vertices[1] = p2, vertices[2] = p3;
    }

    Vector2f edge_center(int index) const
    {
        int32_t i = index;
        int32_t j = (index + 1) % 3;
        if(theta_is_PI_2(i))
        {
            return Vector2f(vertices[j].x, 0.5f * (vertices[i].y + vertices[j].y));
        }
        else if(theta_is_PI_2(j))
        {
            return Vector2f(vertices[i].x, 0.5f * (vertices[i].y + vertices[j].y));
        }
        else
        {
            return Vector2f(0.5f * (vertices[i].x + vertices[j].x), 0.5f * (vertices[i].y + vertices[j].y));
        }
    }

    bool theta_is_PI_2(int index) const
    {
        return fabsf(vertices[index].y - H_PI) < 1e-4;
    }

    Vector2f operator[](int i) const
    {
        if(i < 0 || i > 3)
        {
            return vertices[0];
        }
        else
        {
            return vertices[i];
        }
    }
};

struct ConicQuery
{
    Vector3f wi, wo;
    float Gamma;
    Matrix3x3 C;

    ConicQuery(const Vector3f& _wi, const Vector3f& _wo, float _Gamma): wi(_wi), wo(_wo), Gamma(_Gamma)
    {
        Vector3f x;
        crossProduct(wi, wo, x);
        normalize(x);

        Vector3f y = wi - wo;
        normalize(y);

        Vector3f z = wi + wo;
        normalize(z);

        float dotWiWo = dotProduct(wi, wo);
        float lambda1 = (dotWiWo + cosf(Gamma)) / (1.f - cosf(Gamma));
        float lambda2 = 1.f / (tanf(Gamma/2)*tanf(Gamma/2));

        Matrix3x3 Q(x, y, z);
        Matrix3x3 A(lambda1, 0.f, 0.f, 0.f, lambda2, 0.f, 0.f, 0.f, -1.f);
        Matrix3x3 QT;

        Q.transpose(QT);
        C = Q * A * QT;
    }

    bool isIn(const Vector2f &direction) const
    {
        Vector3f _m = Vector3f(Spherical2Cartesian(direction));
        Vector3f temp = C.preMult(_m);
        float t = dotProduct(temp, _m);
        return t <= 0.f;
    }

    bool isIntersect(const DirectionTri &_tri) const
    {
        Vector3f tri[3] = {Spherical2Cartesian(_tri[0]), Spherical2Cartesian(_tri[1]), Spherical2Cartesian(_tri[2])};
        Vector3f c, d;
        float param_a, param_b, param_c, axis;
        for(int i = 0; i < 3; i++)
        {
            c = tri[i] + tri[(i + 1) % 3] - Vector3f(0.f, 0.f, 1.f);
            d = tri[i] - tri[(i + 1) % 3];
            param_a = dotProduct(C.preMult(d), d);
            param_b = 2 * dotProduct(C.preMult(d), c);
            param_c = dotProduct(C.preMult(c), c);
            if((param_a - param_b + param_c) * (param_a + param_b + param_c) < 0.f)
            {
                return true;
            }
            else
            {
                axis = -param_b / (2.f * param_a);
                if((axis < -1.f) || (axis > 2.f) || ((param_a * param_c - param_b * param_b) * 0.25f >= 0.f))
                {
                    continue;
                }
                else
                {
                    return true;
                }
            }
        }
        return false;
    }

    bool is_overlap(const DirectionTri &_tri) const
    {
        if(isIntersect(_tri))
            return true;
        else
            return isIn(_tri[0]) && isIn(_tri[1]) && isIn(_tri[2]);
    }

    bool is_contain(const DirectionTri &_tri) const
    {
        return !isIntersect(_tri) && (isIn(_tri[0]) && isIn(_tri[1]) && isIn(_tri[2]));
    }
};

std::vector<Vector4f> Material::set_p;

typedef std::pair<DirectionTri, uint32_t> DirectionNode;

void Material::Init()
{
    float x, y, z, w, u, variance;
    for(int32_t i = 0; i < SET_P_SIZE;)
    {
        x = get_random_float();
        y = (1.f - x) * get_random_float();
        z = (1.f - x - y) * get_random_float();
        w = 1.f - x - y - z;
        u = (x + y + z + w) / 4.f;
        variance = ((x - u)*(x - u) + (y - u)*(y - u) + (z - u)*(z - u) + (w - u)*(w - u)) / 4.f;
        float max = 1.f - 0.96f * powf(1.1f, -i);
        if(variance < max)
        {
            set_p.push_back(Vector4f(x, y, z, w));
            ++i;
        }
    }
}

void Material::InitGaussianData()
{
    if(nullptr != gaussians)
    {
        delete [] gaussians;
    }

    // Amount of gaussians
    int mX = texture->width;    // Texel density
    int mY = texture->height;   // Texel density
    int32_t num = mX * mY;

    gaussians = new GaussianElementData*[num];

    float h = 1.f / mX; // Texel density
    float sigmaH = h / std::sqrt(8.f * std::log(2.f));
    float sigmaR = .005f;

    float sigmaH2 = sigmaH * sigmaH;
    float sigmaR2 = sigmaR * sigmaR;

    float invSigmaH2 = 1.f / sigmaH2;
    float invSigmaR2 = 1.f / sigmaR2;

    for (int i = 0; i < num; i++)
    {
        float x = (i % mX);
        float y = (i / mX);

        Vector2f Xi(x / (float)mX, y / (float)mY);

        GaussianElementData* data = new GaussianElementData();

        Vector2f normal = SampleNormalMap(Xi);
        data->seed = Vector4f(Xi.x, Xi.y, normal.x, normal.y);

        Matrix2x2 jacobian = SampleNormalMapJacobian(Xi);
        Matrix2x2 trJacobian;
        jacobian.transpose(trJacobian);

        data->A = ((trJacobian * jacobian) * invSigmaR2) + Matrix2x2(invSigmaH2);
        data->B = -trJacobian * invSigmaR2;
        data->C = Matrix2x2(invSigmaR2);

        Matrix4x4 invCov4D;

        // Upper left
        invCov4D.m[0][0] = data->A.m[0][0];
        invCov4D.m[0][1] = data->A.m[0][1];
        invCov4D.m[1][0] = data->A.m[1][0];
        invCov4D.m[1][1] = data->A.m[1][1];

        // Upper right
        invCov4D.m[2][0] = data->B.m[0][0];
        invCov4D.m[2][1] = data->B.m[0][1];
        invCov4D.m[3][0] = data->B.m[1][0];
        invCov4D.m[3][1] = data->B.m[1][1];

        // Lower left
        Matrix2x2 trB = -jacobian * invSigmaR2;
        invCov4D.m[0][2] = trB.m[0][0];
        invCov4D.m[0][3] = trB.m[0][1];
        invCov4D.m[1][2] = trB.m[1][0];
        invCov4D.m[1][3] = trB.m[1][1];

        // Lower right
        invCov4D.m[2][2] = data->C.m[0][0];
        invCov4D.m[2][3] = data->C.m[0][1];
        invCov4D.m[3][2] = data->C.m[1][0];
        invCov4D.m[3][3] = data->C.m[1][1];

        Matrix4x4 cov4D;
        invCov4D.invert(cov4D);
        Matrix4x4 detCov4D = cov4D * D_PI;
        float det = detCov4D.det();

        if (det <= 0.f)
        {
            data->coeff = 0.f;
        }
        else
        {
            data->coeff = h * h / sqrt(det);
        }

        gaussians[i] = data;
    }
}

Material::Material(MaterialType t, Vector3f e)
{
    m_type = t;
    //m_color = c;
    m_emission = e;
    texture = nullptr;
    gaussians = nullptr;
}

MaterialType Material::getType(){return m_type;}
///Vector3f Material::getColor(){return m_color;}
Vector3f Material::getEmission() {return m_emission;}
bool Material::hasEmission() {
    if (m_emission.norm() > EPSILON) return true;
    else return false;
}

Vector3f Material::getColorAt(double u, double v) {
    return Vector3f();
}


Vector3f Material::sample(const Vector3f &wi, const Vector3f &N){
    switch(m_type){
        case DIFFUSE:
        case GLOSSY:
        case GLINT1:
        case GLINT2:
        case GLINT3:
        case GLINT4:
        case GLINT5:
        {
            // uniform sample on the hemisphere
            float x_1 = get_random_float(), x_2 = get_random_float();
            float z = std::fabs(1.0f - 2.0f * x_1);
            float r = std::sqrt(1.0f - z * z), phi = 2 * M_PI * x_2;
            Vector3f localRay(r*std::cos(phi), r*std::sin(phi), z);
            return toWorld(localRay, N);
            break;
        }
    }
}

float Material::pdf(const Vector3f &wi, const Vector3f &wo, const Vector3f &N)
{
    switch(m_type){
        case DIFFUSE:
        case GLOSSY:
        case GLINT2:
        case GLINT3:
        case GLINT4:
        case GLINT5:
        {
            // uniform sample probability 1 / (2 * PI)
            if (dotProduct(wo, N) > 0.f)
                return 0.5f / M_PI;
            else
                return 0.f;
            break;
        }
        case GLINT1:
        {
            if (dotProduct(wo, N) > 0.f)
                return 0.5f / M_PI;
            else
                return 0.f;
            break;
        }
        default:
        {
            return 0.f;
        }
            break;
    }
}

Vector3f Material::eval(const Ray& ray, int depth, const Intersection* inter, const Vector3f &wi, const Vector3f &wo, const Vector3f &N)
{
    switch(m_type)
    {
        case DIFFUSE:
        {
            // calculate the contribution of diffuse   model
            float cosalpha = dotProduct(N, wo);
            if (cosalpha > 0.f) {
                Vector3f diffuse = Kd / M_PI;
                return diffuse;
            }
            else
                return Vector3f(0.f);
            break;
        }
        case GLOSSY:
        {
            Vector3f H = wi + wo;
            normalize(H);
            float f = fresnelSchlick(N, H);
            float g = geometryShadowing(wi, wo, N, H);
            float d = distributionGGX(N, H, 0.1f);
            float nio = 4.f * dotProduct(wo, N) * dotProduct(wi, N);
            if (nio < EPSILON)
                nio = EPSILON;
            Vector3f glossy = g / nio * f * d;
            return glossy;
            break;
        }
        case GLINT1:
        {
            if (depth < 1)
            {
                Ray      rayDiff[GLINT_SAMPLE_COUNT];
                Vector2f texDiff[GLINT_SAMPLE_COUNT];
                Vector3f sampleDiff[GLINT_SAMPLE_COUNT];
                Vector3f interDiff[GLINT_SAMPLE_COUNT];
                Vector3f dirdiff[GLINT_SAMPLE_COUNT];

                //getSampleDifferential(ray.near_clip, sampleDiff);
                sampleDiff[0] = ray.diff[0];
                sampleDiff[1] = ray.diff[1];
                sampleDiff[2] = ray.diff[2];
                sampleDiff[3] = ray.diff[3];

                TexPlane plane = TexPlane(inter->coords, inter->normal);
                Triangle* tri = static_cast<Triangle*>(inter->obj);
                plane.SetTriangle(tri);

                for(int i = 0; i < GLINT_SAMPLE_COUNT; ++i)
                {
                    float t;
                    dirdiff[i] = (sampleDiff[i] - ray.origin) / (ray.origin - ray.near_clip).norm();
                    rayDiff[i] = Ray(ray.origin, dirdiff[i]);
                    if(plane.intersect(rayDiff[i], t))
                    {
                        interDiff[i] = (rayDiff[i])(t);
                    }
                    else
                    {
                        return 0.5f;
                    }
                    plane.sampleTexCoord(interDiff[i], texDiff[i]);
                }

                Bounds2 tex_box;
                for(int i = 0; i < GLINT_SAMPLE_COUNT; ++i)
                {
                    tex_box.UpdateBounds(texDiff[i]);
                }

                /* Calculate the reflection half-vector */
                Vector3f wh = wi + wo;
                normalize(wh);
                float D1 = countDirection(wi, wo);
                float A = countSpatial(tex_box);
                float D = A * D1;
                if (D < EPSILON)
                {
                    D = EPSILON;
                }

                /* Fresnel factor */
                //const Vector3f F = fresnelConductorExact(dotProduct(bRec.wi, H), m_eta, m_k) *
                //                   m_specularReflectance->eval(bRec.its);
                float F = fresnelSchlick(N, wh);

                /* shadow-masking function */
                float G = geometryShadowing(wi, wo, N, wh);

                /* Calculate the total amount of reflection */
                float model = dotProduct(wi, wh) * D * G /
                              (tex_box.getArea() * PI * (1 - cosf(GAMMA_DIRECTION)) * wi.z);
                return F * model;
            }
            else
            {
                float cosalpha = dotProduct(N, wo);
                if (cosalpha > 0.f) {
                    Vector3f diffuse = Kd / M_PI;
                    return diffuse;
                }

                return Vector3f(0.f);
            }
            break;
        }
        case GLINT2:
        {
            return Vector3f(0.f);
            break;
        }
        case GLINT3:
        {
            if (depth < 1)
            {
                float cosThetaO = std::fabs(dotProduct(N, wo));
                float cosThetaI = std::fabs(dotProduct(N, wo));
                Vector3f wh = (wi + wo);

                if (cosThetaI == 0.f || cosThetaO == 0.f || (wh.x == 0.f && wh.y == 0.f && wh.z == 0.f)) {
                    //FPdf = 0.f;
                    //RPdf = 0.f;
                    return Vector3f(0.f, 0.f, 0.f);
                }

                // Evaluate our normal distribution function
                normalize(wh);
                float WhCosTheta = dotProduct(wh, N);

                Triangle *tri = static_cast<Triangle *>(inter->obj);
                Vector3f TY;
                crossProduct(N, tri->tangent, TY);
                normalize(TY);
                Vector3f localWh = ChangeBasisTo(wh, tri->tangent, TY, N);

                float D = EvaluatePNDF(inter->tcoords, Vector2f(localWh.x, localWh.y));

                /* Fresnel factor */
                float F = fresnelSchlick(N, wh);

                /* Smith's shadow-masking function */
                float G = geometryShadowing(wi, wo, N, wh);

                //float nio = 4.f * dotProduct(wo, N) * dotProduct(wi, N);
                float nio = 4.f * cosThetaO;
                if (nio < EPSILON)
                    nio = EPSILON;
                Vector3f glossy = G / nio * F * D;
                return glossy;
            }
            else
            {
                float cosalpha = dotProduct(N, wo);
                if (cosalpha > 0.f) {
                    Vector3f diffuse = Kd / M_PI;
                    return diffuse;
                }

                return Vector3f(0.f);
            }
            break;
        }
        default:
        {
            break;
        }
    }
}

float Material::fresnelSchlick(const Vector3f& N, const Vector3f &H)
{
    static const double f0 = 0.8f;
    float ret = f0 + (1.f - f0)*pow(1.f - dotProduct(N, H), 5.f);
    if (ret < EPSILON)
        ret = EPSILON;
    return ret;
}

float Material::geometryShadowing(const Vector3f& l, const Vector3f &v,
                                     const Vector3f& n, const Vector3f &h)
{
    // Kelemenn
    double nh = dotProduct(n, h);
    double nv = dotProduct(n, v);
    double vh = dotProduct(v, h);
    double nl = dotProduct(n, l);

    double a = 2.0f*nh*nv/vh;
    double b = 2.0f*nh*nl/vh;

    if (a > 1.0f)
        a = 1.0f;

    float ret = a > b? b: a;
    if (ret < EPSILON)
        ret = EPSILON;

    return ret;
}

float Material::distributionGGX(const Vector3f& n, const Vector3f &h, float a)
{
    float a2  = a*a;
    float nh  = std::max(dotProduct(n, h), 0.f);
    float nh2 = nh * nh;
    float d   = (nh2 * (a2 - 1.f) + 1.f);

    d = M_PI * d * d;
    float ret = a2 / d;
    if (ret < EPSILON)
    {
        ret = EPSILON;
    }

    return ret;
}

void Material::getSampleDifferential(const Vector3f& p, Vector3f* diff)
{
    int32_t x = (int)(p.x * RESOLUTION_X);
    int32_t y = (int)(p.y * RESOLUTION_Y);
    diff[0] = Vector3f(x * INV_RESOLUTION_X, y * INV_RESOLUTION_Y, 0.f);
    diff[1] = Vector3f((x + CAMERA_PIXEL_WIDTH) * INV_RESOLUTION_X, y * INV_RESOLUTION_Y, 0.f);
    diff[2] = Vector3f((x + CAMERA_PIXEL_WIDTH) * INV_RESOLUTION_X, (y + CAMERA_PIXEL_WIDTH) * INV_RESOLUTION_Y, 0.f);
    diff[3] = Vector3f(x * INV_RESOLUTION_X, (y + CAMERA_PIXEL_WIDTH) * INV_RESOLUTION_Y, 0.f);
}

float Material::countSpatial(const Bounds2& query)
{
    uint32_t count = 0;
    uint32_t splitTimes = 0;
    float p = 0.f;

    Bounds2 clipBox;
    SpatialNode node;
    std::vector<SpatialNode> queue;
    queue.emplace_back(std::make_pair(Bounds2(Vector2f(0.f, 0.f), Vector2f(1.f, 1.f)), SPATIAL_SAMPLE_NUM));

    while(!queue.empty())
    {
        node = queue.back();
        queue.pop_back();
        if(!node.first.Overlaps(query) || (node.second <= 0))
        {
            continue;
        }

        if(query.Contains(node.first))
        {
            count += node.second;
            continue;
        }

        p = count / SPATIAL_SAMPLE_NUM;
        if(sqrt(node.second * p * (1 - p)) < EPSILON_COUNT * count)
        {
            clipBox = node.first;
            clipBox.Clip(query);

            float n = (float)node.second * clipBox.getArea();
            float m = node.first.getArea();
            uint32_t t = (uint32_t)(n / m);
            count += t;
            continue;
        }

        assert(splitTimes < SET_P_SIZE);
        Vector2f center = node.first.Centroid();
        Vector2f min = node.first.min;
        Vector2f max = node.first.max;
        queue.emplace_back(std::make_pair(
                Bounds2(min, center),
                (uint32_t)(node.second * set_p[splitTimes].x)));
        queue.emplace_back(std::make_pair(
                Bounds2(Vector2f(center.x, min.y), Vector2f(max.x, center.y)),
                (uint32_t)(node.second * set_p[splitTimes].y)));
        queue.emplace_back(std::make_pair(
                Bounds2(center, max),
                (uint32_t)(node.second * set_p[splitTimes].z)));
        queue.emplace_back(std::make_pair(
                Bounds2(Vector2f(min.x, center.y), Vector2f(center.x, max.y)),
                (uint32_t)(node.second * set_p[splitTimes].w)));
        ++splitTimes;
    }

    float ret = (float)count / SPATIAL_SAMPLE_NUM;
    return ret;
}

float Material::countDirection(const Vector3f &wi, const Vector3f &wo) const
{
    uint32_t count = 0;
    uint32_t split_times = 1;
    std::vector<DirectionNode> queue;

    ConicQuery query(wi, wo, GAMMA_DIRECTION);

    queue.push_back(std::make_pair(DirectionTri(Vector2f(0.f, 0.f), Vector2f(H_PI, 0.f), Vector2f(0.f, H_PI)),
                                   (uint32_t)(DIRECTION_SAMPLE_NUM * set_p[0].x)));
    queue.push_back(std::make_pair(DirectionTri(Vector2f(H_PI, 0.f), Vector2f(PI, 0.f), Vector2f(0.f, H_PI)),
                                   (uint32_t)(DIRECTION_SAMPLE_NUM * set_p[0].y)));
    queue.push_back(std::make_pair(DirectionTri(Vector2f(PI, 0.f), Vector2f(H_PI + PI, 0.f), Vector2f(0.f, H_PI)),
                                   (uint32_t)(DIRECTION_SAMPLE_NUM * set_p[0].z)));
    queue.push_back(std::make_pair(DirectionTri(Vector2f(PI + H_PI, 0.f), Vector2f(D_PI, 0.f), Vector2f(0.f, H_PI)),
                                   (uint32_t)(DIRECTION_SAMPLE_NUM * set_p[0].w)));
    bool isIntersect;
    float p;

    while(!queue.empty())
    {
        DirectionNode node = queue.back();
        queue.pop_back();
        isIntersect = query.isIntersect(node.first);
        if((!isIntersect && !(query.isIn(node.first[0]) && query.isIn(node.first[1]) && query.isIn(node.first[2]))) ||
           (node.second <= 0.f))
        {
            continue;
        }

        if(!isIntersect && (query.isIn(node.first[0]) && query.isIn(node.first[1]) && query.isIn(node.first[2])))
        {
            count += node.second;
            continue;
        }

        p = count / SPATIAL_SAMPLE_NUM;
        if(sqrt(node.second * p * (1 - p)) < EPSILON_COUNT * count)
        {
            count += node.second;
            continue;
        }

        assert(split_times < SET_P_SIZE);
        queue.push_back(std::make_pair(
                DirectionTri(node.first.edge_center(0), node.first.edge_center(1), node.first.edge_center(2)),
                (uint32_t)(node.second * set_p[split_times].x)));
        queue.push_back(std::make_pair(
                DirectionTri(node.first.edge_center(0), node.first.edge_center(2), node.first[0]),
                (uint32_t)(node.second * set_p[split_times].y)));
        queue.push_back(std::make_pair(
                DirectionTri(node.first.edge_center(0), node.first.edge_center(1), node.first[1]),
                (uint32_t)(node.second * set_p[split_times].z)));
        queue.push_back(std::make_pair(
                DirectionTri(node.first.edge_center(1), node.first.edge_center(2), node.first[2]),
                (uint32_t)(node.second * set_p[split_times].w)));
        ++split_times;
    }

    return (float)count / DIRECTION_SAMPLE_NUM;
}

Vector3f Material::ChangeBasisTo(Vector3f const& in, Vector3f const& X, Vector3f const& Y, Vector3f const& Z)
{
    float a = dotProduct(in, X);
    float b = dotProduct(in, Y);
    float c = dotProduct(in, Z);
    return Vector3f(a, b, c);
}

Vector2f Material::Min(const Vector2f& a, const Vector2f& b)
{
    float x = std::fmin(a.x, b.x);
    float y = std::fmin(a.y, b.y);
    return Vector2f(x, y);
}

Vector2f Material::Max(const Vector2f& a, const Vector2f& b)
{
    float x = std::fmax(a.x, b.x);
    float y = std::fmax(a.y, b.y);
    return Vector2f(x, y);
}

Vector2f Material::Mix(const Vector2f& a, const Vector2f& b, float c)
{
    return (a * (1.f-c)) + (b * c);
}

Vector2f Material::Clamp(Vector2f x, Vector2f minVal, Vector2f maxVal)
{
    return Min(Max(x, minVal), maxVal);
}

float Material::EvaluatePNDF(Vector2f uv, Vector2f st)
{
    int mX = texture->width;
    int mY = texture->height;

    Vector2f regionCenter = uv;
    Vector2f regionSize = Vector2f(12, 12);
    Vector2f from = Clamp(regionCenter - regionSize * .5f, Vector2f(), Vector2f(mX - 1, mY - 1));
    Vector2f to = Clamp(regionCenter + regionSize * .5f, Vector2f(), Vector2f(mX - 1, mY - 1));

    float footprintRadius = regionSize.x * 0.5f / (float)mX;
    float sigmaP = footprintRadius * 0.0625f;

    Matrix2x2 footprintCovariance = Matrix2x2(sigmaP * sigmaP);
    Matrix2x2 footprintCovarianceInv;
    footprintCovariance.invert(footprintCovarianceInv);
    Vector2f footprintMean = (from + regionSize * 0.5f) * Vector2f(1.f / mX, 1.f / mY);

    // Outside our disk
    float len = st.norm();
    if (len > .975f)
    {
        return 0.f;
    }

    float accum = 0.f;

    // For each gaussian in the region...
    for (int gY = from.y; gY < to.y; gY++)
    {
        for (int gX = from.x; gX < to.x; gX++)
        {
            GaussianElementData* data = gaussians[gY * mX + gX];
            Vector4f gaussianSeed = data->seed;

            // Direction, S - N(Xi)
            Vector2f S(st);
            S = S - Vector2f(gaussianSeed.z, gaussianSeed.w);
            normalize(S);

            // We reduce the 4D gaussian into 2D by fixing S, see appendix
            //Matrix2x2 invCov = data->A;
            Matrix2x2 invA;
            data->A.invert(invA);

            Matrix2x2 covAB = -(invA * data->B);
            Vector2f u0 = covAB * S;
            normalize(u0);

            float c = 0.f;
            if (0.f != data->coeff)
            {
                float d1 = dotProduct(S, data->C * S);
                float d2 = dotProduct(u0, data->A * u0);
                float inner = d1 - d2;
                float t = -0.5f * inner;
                //float f = std::sqrt(t);
                float e = exp(t);
                c = data->coeff * t;
            }

            // Calculate the resulting gaussian by multiplying Gp * Gi
            Matrix2x2 resultInvCovariance = data->A + footprintCovarianceInv;
            Matrix2x2 resultCovariance;
            resultInvCovariance.invert(resultCovariance);

            Vector2f resultMean = resultCovariance * (data->A * u0 + footprintCovarianceInv * (footprintMean - Vector2f(gaussianSeed.x, gaussianSeed.y)));

            float resultC = EvaluateGaussian(c, resultMean, u0, data->A) *
                            EvaluateGaussian(GetGaussianCoefficient(footprintCovarianceInv), resultMean, footprintMean - Vector2f(gaussianSeed.x, gaussianSeed.y), footprintCovarianceInv);

            Matrix2x2 resultCovarianceDet = resultCovariance * D_PI;
            float det = resultCovarianceDet.det();

            if ((resultC != 0.f) && (det > 0.f))
            {
                accum += resultC * std::sqrt(det);
                //accum += resultC * det;
            }
        }
    }

    float xx = mX / (float)regionSize.x;
    accum /= xx;

    accum *= 100000000000000.f;

    if (accum > 1.5f) { accum = 1.5f; }
    if (accum < EPSILON) { accum = EPSILON; }

    //accum = 1.f;
    return accum;
}

float Material::EvaluateGaussian(float c, const Vector2f& x, const Vector2f& u, const Matrix2x2& InvCov)
{
    float inner = dotProduct(x - u, InvCov * (x - u));
    return c * exp(-.5f * inner);
}

float Material::GetGaussianCoefficient(const Matrix2x2& InvCov)
{
    Matrix2x2 cov;
    InvCov.invert(cov);

    Matrix2x2 covDet = cov * D_PI;
    float det = covDet.det();

    if (det > 0.f)
    {
        return 1.f / std::sqrt(det);
    }

    return 0.f;
}

Vector2f Material::SampleNormalMap(Vector2f uv)
{
    uv = Vector2f(uv.x - floorf(uv.x), uv.y - floorf(uv.y));

    int32_t x = uv.x * texture->width;
    int32_t y = uv.y * texture->height;

    Vector2f st = Vector2f((uv.x * texture->width) - x, (uv.y * texture->height) - y);

    Vector2f p1 = SampleRawNormal(x, y);
    Vector2f p2 = SampleRawNormal(x + 1, y);
    Vector2f l1 = Mix(p1, p2, st.x);

    Vector2f p3 = SampleRawNormal(x, y + 1);
    Vector2f p4 = SampleRawNormal(x + 1, y + 1);
    Vector2f l2 = Mix(p3, p4, st.x);

    return Mix(l1, l2, st.y);
}

Vector2f Material::SampleRawNormal(int x, int y)
{
    Vector3f c = GetColor(x, y);
    //return Vector2f(c.x, c.y) * 2.0f - Vector2f(1.0);
    return Vector2f(c.x, c.y) / 255.f;
}

Vector3f Material::GetColor(int x, int y)
{
    if (nullptr == texture)
    {
        return Vector3f(0.f, 0.f, 0.f);
    }

    x = clamp(x, 0, texture->width - 1);
    y = clamp(y, 0, texture->height - 1);

    auto color = texture->image_data.at<cv::Vec3b>(x, y);
    return Vector3f(color[0], color[1], color[2]);
}

Matrix2x2 Material::SampleNormalMapJacobian(Vector2f uv)
{
    float hX = 1.f / (float)texture->width;
    float hY = 1.f / (float)texture->height;

    Vector2f xDiff = Vector2f(0.f);
    xDiff = xDiff + SampleNormalMap(uv + Vector2f(hX, hY)) * 1.f;
    xDiff = xDiff + SampleNormalMap(uv + Vector2f(hX, 0)) * 2.f;
    xDiff = xDiff + SampleNormalMap(uv + Vector2f(hX, -hY)) * 1.f;

    xDiff = xDiff + SampleNormalMap(uv - Vector2f(hX, hY)) * -1.f;
    xDiff = xDiff + SampleNormalMap(uv - Vector2f(hX, 0)) * -2.f;
    xDiff = xDiff + SampleNormalMap(uv - Vector2f(hX, -hY)) * -1.f;

    Vector2f yDiff;
    yDiff = yDiff + SampleNormalMap(uv + Vector2f(hX, hY)) * 1.f;
    yDiff = yDiff + SampleNormalMap(uv + Vector2f(0, hY)) * 2.f;
    yDiff = yDiff + SampleNormalMap(uv + Vector2f(-hX, hY)) * 1.f;

    yDiff = yDiff + SampleNormalMap(uv - Vector2f(hX, hY)) * -1.f;
    yDiff = yDiff + SampleNormalMap(uv - Vector2f(0, hY)) * -2.f;
    yDiff = yDiff + SampleNormalMap(uv - Vector2f(-hX, hY)) * -1.f;

    xDiff = xDiff / (8.f * hX);
    yDiff = yDiff / (8.f * hY);

    // Encoded as
    // fx/dx fx/dy
    // fy/dx fy/dy
    // Remember glm is column major
    Matrix2x2 J(xDiff, yDiff);
    //J.m[0][0] = xDiff.x;
    //J.m[0][1] = yDiff.x;

    //J.m[1][0] = xDiff.y;
    //J.m[1][1] = yDiff.y;

    return J;
}