#ifndef RAYTRACING_TEXPLANE_H
#define RAYTRACING_TEXPLANE_H

#include "Vector.hpp"
#include "Ray.hpp"
#include "Triangle.hpp"

#define PLANE_EPSILON 1e-3

class TexPlane
{
public:
    TexPlane(): epsilon(PLANE_EPSILON)
    {

    }

    TexPlane(const Vector3f& _p, const Vector3f& _n): p(_p), n(_n), epsilon(PLANE_EPSILON)
    {

    }

    TexPlane(const Vector3f& p0, const Vector3f& p1, const Vector3f& p2): epsilon(PLANE_EPSILON)
    {
        p = p0;
        Vector3f v0 = p0 - p1;
        Vector3f v1 = p0 - p2;
        crossProduct(v0, v1, n);
        normalize(n);
    }

    TexPlane(const TexPlane* plane): epsilon(PLANE_EPSILON)
    {
        p = plane->p;
        n = plane->n;
    }

    void SetTriangle(const Triangle* tri)
    {
        triPt[0] = tri->vertices[0];
        triPt[1] = tri->vertices[1];
        triPt[2] = tri->vertices[2];

        triTex[0] = tri->uvs[0];
        triTex[1] = tri->uvs[1];
        triTex[2] = tri->uvs[2];
    }

    bool intersectP(const Ray& ray) const
    {
        float parallelTest = dotProduct(ray.direction, n);
        if(std::fabs(parallelTest) < 1e-5)
        {
            return false;
        }
        else
        {
            float t = dotProduct((p-ray.origin), n) / parallelTest;
            return (t > epsilon && t > ray.t_min && t < ray.t_max);
        }
    }

    bool intersect(const Ray& ray, float& hit_t) const
    {
        float parallelTest = dotProduct(ray.direction, n);
        if(std::fabs(parallelTest) < 1e-5)
        {
            return false;
        }
        else
        {
            float t = dotProduct((p - ray.origin), n) / parallelTest;
            if((t > epsilon) && (t > ray.t_min) && (t < ray.t_max))
            {
                hit_t = t;
                return true;
            }
            else
                return false;
        }
    }

    void sampleTexCoord(const Vector3f& p, Vector2f& tex) const
    {
        Vector3f v1 = triPt[1] - triPt[0];
        Vector3f v2 = triPt[2] - triPt[0];

        float D = v1.x * v2.y - v1.y * v2.x;
        float u = ((p.x - triPt[0].x) * v2.y - (p.y - triPt[0].y) * v2.x) / D;
        float v = ((p.y - triPt[0].y) * v1.x - (p.x - triPt[0].x) * v1.y) / D;

        Vector2f e1 = triTex[1] - triTex[0];
        Vector2f e2 = triTex[2] - triTex[0];

        tex = triTex[0] + (u * e1) + (v * e2);
    }
private:
    Vector3f p;
    Vector3f n;
    Vector3f triPt[3];
    Vector2f triTex[3];

    const float epsilon;
};

#endif // RAYTRACING_TEXPLANE_H
