## 选题 渲染复杂表面的闪光
### 完成情况

- 没完成功能，所以没录视频

### Glint1 实现 随机闪光

- 未复现闪光
- ![](images\G1_00.png) 
### Glint3 实现 Position-Normal
- 未复现闪光
- 代码有错误（每次执行的图像会随机执行，多线程下有其他问题未查出）
- ![](images\G2_01.png) 
- ![](images\G2_02.png) 
- ![](models\bunny\04.png) 