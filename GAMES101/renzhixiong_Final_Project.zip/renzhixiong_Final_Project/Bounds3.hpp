//
// Created by LEI XU on 5/16/19.
//

#ifndef RAYTRACING_BOUNDS3_H
#define RAYTRACING_BOUNDS3_H

#include "Ray.hpp"
#include "Vector.hpp"
#include <limits>
#include <array>

class Bounds2
{
public:
    Vector2f min, max; // two points to specify the bounding box

    Bounds2(Vector2f _min, Vector2f _max) : min(_min), max(_max)
    {
    }

    Bounds2()
    {
        min = Vector2f(MAX_FLOAT, MAX_FLOAT);
        max = Vector2f(MIN_FLOAT, MIN_FLOAT);
    }

    inline bool IsValid() const
    {
        if ((max.x < min.x) || (max.y < min.y))
        {
            return false;
        }
        return true;
    }

    inline Vector2f Centroid()
    {
        return (min + max) * 0.5f;
    }

    inline float getArea()
    {
        return (max.x - min.x) * (max.y - min.y);
    }

    inline void Clip(const Bounds2& b)
    {
        min.x = std::max(min.x, b.min.x);
        min.y = std::max(min.y, b.min.y);

        max.x = std::min(max.x, b.max.x);
        max.y = std::min(max.y, b.max.y);
    }

    inline bool Contains(const Bounds2& b) const
    {
        if (!IsValid())
        {
            return false;
        }

        if ((b.min.x < min.x) || (b.min.y < min.y) ||
            (b.max.x > max.x) || (b.max.y > max.y))
        {
            return false;
        }

        return true;
    }

    inline bool Overlaps(const Bounds2& b) const
    {
        if ((max.x < b.min.x) || (max.y < b.min.y) ||
            (min.x > b.max.x) || (min.y > b.max.y))
        {
            return false;
        }
        return true;
    }

    inline void UpdateBounds(const Vector2f& p)
    {
        if (p.x < min.x) { min.x = p.x; }
        if (p.y < min.y) { min.y = p.y; }
        if (p.x > max.x) { max.x = p.x; }
        if (p.y > max.y) { max.y = p.y; }
    }
};

class Bounds3
{
  public:
    Vector3f min, max; // two points to specify the bounding box

    Bounds3()
    {
        max = Vector3f(MIN_FLOAT, MIN_FLOAT, MIN_FLOAT);
        min = Vector3f(MAX_FLOAT, MAX_FLOAT, MAX_FLOAT);
    }

    Bounds3(const Vector3f p1, const Vector3f p2)
    {
        min = Vector3f(fmin(p1.x, p2.x), fmin(p1.y, p2.y), fmin(p1.z, p2.z));
        max = Vector3f(fmax(p1.x, p2.x), fmax(p1.y, p2.y), fmax(p1.z, p2.z));
    }

    void Clear()
    {
        max = Vector3f(MIN_FLOAT, MIN_FLOAT, MIN_FLOAT);
        min = Vector3f(MAX_FLOAT, MAX_FLOAT, MAX_FLOAT);
    }

    Vector3f Diagonal() const { return max - min; }

    int maxExtent() const
    {
        Vector3f d = Diagonal();
        if (d.x > d.y && d.x > d.z)
            return 0;
        else if (d.y > d.z)
            return 1;
        else
            return 2;
    }


    inline void getAxisBound(int dim, float& axisMin, float& axisMax)
    {
        if (X_AXIS == dim)
        {
            axisMin = min.x;
            axisMax = max.x;
            return;
        }

        if (Y_AXIS == dim)
        {
            axisMin = min.y;
            axisMax = max.y;
            return;
        }

        axisMin = min.z;
        axisMax = max.z;
    }

    inline float SurfaceArea() const
    {
        Vector3f d = Diagonal();
        return 2.f * (d.x * d.y + d.x * d.z + d.y * d.z);
    }

    inline void UpdateBounds(const Vector3f& p)
    {
        if (p.x < min.x) { min.x = p.x; }
        if (p.y < min.y) { min.y = p.y; }
        if (p.z < min.z) { min.z = p.z; }
        if (p.x > max.x) { max.x = p.x; }
        if (p.y > max.y) { max.y = p.y; }
        if (p.z > max.z) { max.z = p.z; }
    }

    inline void UpdateBounds(const Bounds3& b)
    {
        if (b.min.x < min.x) { min.x = b.min.x; }
        if (b.min.y < min.y) { min.y = b.min.y; }
        if (b.min.z < min.z) { min.z = b.min.z; }
        if (b.max.x > max.x) { max.x = b.max.x; }
        if (b.max.y > max.y) { max.y = b.max.y; }
        if (b.max.z > max.z) { max.z = b.max.z; }
    }

    inline Vector3f Centroid()
    {
        return (min + max) * 0.5f;
    }

    inline float CentroidByAxis(int dim) const
    {
        if (X_AXIS == dim)
        {
            return (min.x + max.x) * 0.5f;
        }

        if (Y_AXIS == dim)
        {
            return (min.y + max.y) * 0.5f;
        }

        return (min.z + max.z) * 0.5f;
    }

    Bounds3 Intersect(const Bounds3& b)
    {
        return Bounds3(Vector3f(fmax(min.x, b.min.x), fmax(min.y, b.min.y),
                                fmax(min.z, b.min.z)),
                       Vector3f(fmin(max.x, b.max.x), fmin(max.y, b.max.y),
                                fmin(max.z, b.max.z)));
    }

    Vector3f Offset(const Vector3f& p) const
    {
        Vector3f o = p - min;
        if (max.x > min.x)
            o.x /= max.x - min.x;
        if (max.y > min.y)
            o.y /= max.y - min.y;
        if (max.z > min.z)
            o.z /= max.z - min.z;
        return o;
    }

    bool Overlaps(const Bounds3& b1, const Bounds3& b2)
    {
        bool x = (b1.max.x >= b2.min.x) && (b1.min.x <= b2.max.x);
        bool y = (b1.max.y >= b2.min.y) && (b1.min.y <= b2.max.y);
        bool z = (b1.max.z >= b2.min.z) && (b1.min.z <= b2.max.z);
        return (x && y && z);
    }

    bool Inside(const Vector3f& p, const Bounds3& b)
    {
        return (p.x >= b.min.x && p.x <= b.max.x && p.y >= b.min.y &&
                p.y <= b.max.y && p.z >= b.min.z && p.z <= b.max.z);
    }

    inline const Vector3f& operator[](int i) const
    {
        return (i == 0) ? min : max;
    }

    inline bool IntersectP(const Ray& ray, float* dist = nullptr) const;
};



inline bool Bounds3::IntersectP(const Ray& ray, float* dist) const
{
    // invDir: ray direction(x,y,z), invDir=(1.0/x,1.0/y,1.0/z), use this because Multiply is faster that Division
    // dirIsNeg: ray direction(x,y,z), dirIsNeg=[int(x>0),int(y>0),int(z>0)], use this to simplify your logic
    // TODO test if ray bound intersects
    float tmin = (min.x - ray.origin.x) * ray.direction_inv.x;
    float tmax = (max.x - ray.origin.x) * ray.direction_inv.x;

    if (tmin > tmax) std::swap(tmin, tmax);
    if (tmax < 0.f) { return false; }

    float tymin = (min.y - ray.origin.y) * ray.direction_inv.y;
    float tymax = (max.y - ray.origin.y) * ray.direction_inv.y;

    if (tymin > tymax) std::swap(tymin, tymax);
    if (tymax < 0.f) { return false; }

    if ((tmin > tymax) || (tymin > tmax)) { return false; }

    if (tymin > tmin) { tmin = tymin; }
    if (tymax < tmax) { tmax = tymax; }

    float tzmin = (min.z - ray.origin.z) * ray.direction_inv.z;
    float tzmax = (max.z - ray.origin.z) * ray.direction_inv.z;

    if (tzmin > tzmax) std::swap(tzmin, tzmax);
    if (tzmax < 0.f) { return false; }

    if ((tmin > tzmax) || (tzmin > tmax)) { return false; }

    if (nullptr != dist)
    {
        if (tzmin > tmin)
            tmin = tzmin;

        *dist = tmin;
    }

    return true;
}

inline Bounds3 Union(const Bounds3& b1, const Bounds3& b2)
{
    Bounds3 ret;
    ret.min = Vector3f::Min(b1.min, b2.min);
    ret.max = Vector3f::Max(b1.max, b2.max);
    return ret;
}

inline Bounds3 Union(const Bounds3& b, const Vector3f& p)
{
    Bounds3 ret;
    ret.min = Vector3f::Min(b.min, p);
    ret.max = Vector3f::Max(b.max, p);
    return ret;
}

#endif // RAYTRACING_BOUNDS3_H
