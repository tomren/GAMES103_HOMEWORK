//
// Created by goksu on 4/6/19.
//

#pragma once

#include <eigen3/Eigen/Eigen>
#include <algorithm>
#include "global.hpp"
#include "Triangle.hpp"
using namespace Eigen;

namespace rst
{
    enum class Buffers
    {
        Color = 1,
        Depth = 2
    };

    inline Buffers operator|(Buffers a, Buffers b)
    {
        return Buffers((int)a | (int)b);
    }

    inline Buffers operator&(Buffers a, Buffers b)
    {
        return Buffers((int)a & (int)b);
    }

    enum class Primitive
    {
        Line,
        Triangle
    };

    /*
     * For the curious : The draw function takes two buffer id's as its arguments. These two structs
     * make sure that if you mix up with their orders, the compiler won't compile it.
     * Aka : Type safety
     * */
    struct pos_buf_id
    {
        int pos_id = 0;
    };

    struct ind_buf_id
    {
        int ind_id = 0;
    };

    struct col_buf_id
    {
        int col_id = 0;
    };

    class rasterizer
    {
    public:
        rasterizer(int w, int h);
        ~rasterizer();

        pos_buf_id load_positions(const std::vector<Eigen::Vector3f>& positions);
        ind_buf_id load_indices(const std::vector<Eigen::Vector3i>& indices);
        col_buf_id load_colors(const std::vector<Eigen::Vector3f>& colors);

        void set_model(const Eigen::Matrix4f& m);
        void set_view(const Eigen::Matrix4f& v);
        void set_projection(const Eigen::Matrix4f& p);

        void set_pixel(const Eigen::Vector3f& point, const Eigen::Vector3f& color);

        void clear(Buffers buff);

        void draw(pos_buf_id pos_buffer, ind_buf_id ind_buffer, col_buf_id col_buffer, Primitive type);

        Eigen::Vector3f* frame_buffer() { return frame_buf; }

    private:
        void rasterize_triangle(const Triangle& t);

        // VERTEX SHADER -> MVP -> Clipping -> /.W -> VIEWPORT -> DRAWLINE/DRAWTRI -> FRAGSHADER

        int get_index(int x, int y);
        int get_next_id() { return next_id++; }

        void cal_mini_bounding(const Triangle& t, const Eigen::Vector3f& minPos,
                               const Eigen::Vector3f& maxPos, std::vector<Eigen::Vector3i>& miniBounding);

        // MSAA
        void set_msaa_pixel(int x, int y, int col, int row, float z, const Eigen::Vector3f& color);
        void get_msaa_pixel(int x, int y, Eigen::Vector3f& color);
        int  get_mass_color_idx(const Eigen::Vector3f& color);

    private:
        Eigen::Matrix4f model;
        Eigen::Matrix4f view;
        Eigen::Matrix4f projection;

        std::map<int, std::vector<Eigen::Vector3f>> pos_buf;
        std::map<int, std::vector<Eigen::Vector3i>> ind_buf;
        std::map<int, std::vector<Eigen::Vector3f>> col_buf;

        Eigen::Vector3f*                frame_buf       = nullptr;
        float*                          depth_buf       = nullptr;

        int                             width           = 0;
        int                             height          = 0;
        int                             next_id         = 0;
        int                             buf_len         = 0;

        // MSAA Buffer
        // ----------------------------------------
        int                             msaa_density    = 4;
        int                             msaa_row_num    = 2;
        int                             msaa_col_num    = 2;
        int                             msaa_buf_len    = 0;
        int*                            msaa_frame_buf  = nullptr;
        float*                          msaa_depth_buf  = nullptr;

        // Cache Color Buffer
        // ----------------------------------------
        int                             cache_color_len = 32;
        int                             cache_color_num = 0;
        Eigen::Vector3f*                cache_color_buf = nullptr;

        // Clear Buffer
        // ----------------------------------------
        Eigen::Vector3f*                frame_init_buf  = nullptr;
        float*                          depth_init_buf  = nullptr;
    };
}