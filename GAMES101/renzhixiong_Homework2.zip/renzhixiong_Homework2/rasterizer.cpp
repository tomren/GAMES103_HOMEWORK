// clang-format off
//
// Created by goksu on 4/6/19.
//

#include <algorithm>
#include <vector>
#include "rasterizer.hpp"
#include <opencv2/opencv.hpp>

#define NEW_BUF(buf, type, len)\
    if (buf)\
    {\
        delete [] buf;\
    }\
    buf = new type[len];

#define DEL_BUF(buf)\
    if (buf)\
    {\
        delete [] buf;\
    }

rst::pos_buf_id rst::rasterizer::load_positions(const std::vector<Eigen::Vector3f> &positions)
{
    auto id = get_next_id();
    pos_buf.emplace(id, positions);

    return {id};
}

rst::ind_buf_id rst::rasterizer::load_indices(const std::vector<Eigen::Vector3i> &indices)
{
    auto id = get_next_id();
    ind_buf.emplace(id, indices);

    return {id};
}

rst::col_buf_id rst::rasterizer::load_colors(const std::vector<Eigen::Vector3f> &cols)
{
    auto id = get_next_id();
    col_buf.emplace(id, cols);
    return {id};
}

auto to_vec4(const Eigen::Vector3f& v3, float w = 1.0f)
{
    return Vector4f(v3.x(), v3.y(), v3.z(), w);
}


static bool insideTriangle(float x, float y, const Vector3f* _v)
{
    // TODO : Implement this function to check if the point (x, y) is inside the triangle represented by _v[0], _v[1], _v[2]
    float ax = 0.f;
    float ay = 0.f;
    float bx = 0.f;
    float by = 0.f;
    int f = 0;

    for (int m = 0; m < 3; ++m)
    {
        int n = (m + 1) % 3;

        ax = _v[n].x() - _v[m].x();
        ay = _v[n].y() - _v[m].y();

        bx = x - _v[m].x();
        by = y - _v[m].y();

        float c = (ax*by) - (bx*ay);

        if (c < 0)
        {
            f |= 1 << m;
        }

        if (m < 1)
        {
            continue;
        }

        int z = f >> (m - 1);
        if ((0x0 != z) && (0x3 != z))
        {
            return false;
        }
    }

    return true;
}

static std::tuple<float, float, float> computeBarycentric2D(float x, float y, const Vector3f* v)
{
    float c1 = (x*(v[1].y() - v[2].y()) + (v[2].x() - v[1].x())*y + v[1].x()*v[2].y() - v[2].x()*v[1].y()) / (v[0].x()*(v[1].y() - v[2].y()) + (v[2].x() - v[1].x())*v[0].y() + v[1].x()*v[2].y() - v[2].x()*v[1].y());
    float c2 = (x*(v[2].y() - v[0].y()) + (v[0].x() - v[2].x())*y + v[2].x()*v[0].y() - v[0].x()*v[2].y()) / (v[1].x()*(v[2].y() - v[0].y()) + (v[0].x() - v[2].x())*v[1].y() + v[2].x()*v[0].y() - v[0].x()*v[2].y());
    float c3 = (x*(v[0].y() - v[1].y()) + (v[1].x() - v[0].x())*y + v[0].x()*v[1].y() - v[1].x()*v[0].y()) / (v[2].x()*(v[0].y() - v[1].y()) + (v[1].x() - v[0].x())*v[2].y() + v[0].x()*v[1].y() - v[1].x()*v[0].y());
    return {c1,c2,c3};
}

void rst::rasterizer::draw(pos_buf_id pos_buffer, ind_buf_id ind_buffer, col_buf_id col_buffer, Primitive type)
{
    auto& buf = pos_buf[pos_buffer.pos_id];
    auto& ind = ind_buf[ind_buffer.ind_id];
    auto& col = col_buf[col_buffer.col_id];

    float f1 = (50 - 0.1) / 2.0;
    float f2 = (50 + 0.1) / 2.0;

    Eigen::Matrix4f mvp = projection * view * model;
    for (auto& i : ind)
    {
        Triangle t;
        Eigen::Vector4f v[] = {
                mvp * to_vec4(buf[i[0]], 1.0f),
                mvp * to_vec4(buf[i[1]], 1.0f),
                mvp * to_vec4(buf[i[2]], 1.0f)
        };
        //Homogeneous division
        for (auto& vec : v) {
            vec /= vec.w();
        }
        //Viewport transformation
        for (auto & vert : v)
        {
            vert.x() = 0.5*width*(vert.x()+1.0);
            vert.y() = 0.5*height*(vert.y()+1.0);
            vert.z() = vert.z() * f1 + f2;
        }

        for (int i = 0; i < 3; ++i)
        {
            t.setVertex(i, v[i].head<3>());
            t.setVertex(i, v[i].head<3>());
            t.setVertex(i, v[i].head<3>());
        }

        auto col_x = col[i[0]];
        auto col_y = col[i[1]];
        auto col_z = col[i[2]];

        t.setColor(0, col_x[0], col_x[1], col_x[2]);
        t.setColor(1, col_y[0], col_y[1], col_y[2]);
        t.setColor(2, col_z[0], col_z[1], col_z[2]);

        rasterize_triangle(t);
    }
}

//Screen space rasterization
void rst::rasterizer::rasterize_triangle(const Triangle& t)
{
    auto v = t.toVector4();

    Eigen::Vector3f minPos = {FLT_MAX, FLT_MAX, FLT_MAX};
    Eigen::Vector3f maxPos = {FLT_MIN, FLT_MIN, FLT_MIN};

    // TODO : Find out the bounding box of current triangle.
    // iterate through the pixel and find if the current pixel is inside the triangle

    // AABB bounding box
    for (auto it = v.cbegin(); it != v.cend(); ++it)
    {
        if (it->x() < minPos.x()) minPos.x() = it->x();
        if (it->y() < minPos.y()) minPos.y() = it->y();
        if (it->z() < minPos.z()) minPos.z() = it->z();

        if (it->x() > maxPos.x()) maxPos.x() = it->x();
        if (it->y() > maxPos.y()) maxPos.y() = it->y();
        if (it->z() > maxPos.z()) maxPos.z() = it->z();
    }

    // Triangle mini bounding
    std::vector<Eigen::Vector3i> miniBounding;
    cal_mini_bounding(t, minPos, maxPos, miniBounding);

    // If so, use the following code to get the interpolated z value.
    // TODO : set the current pixel (use the set_pixel function) to the color of the triangle (use getColor function) if it should be painted.
    Eigen::Vector3f p = {0.f, 0.f, 0.f};
    Eigen::Vector3f c = {0.f, 0.f, 0.f};
    bool hasSet = false;

//    int minX = minPos.x();
//    int minY = minPos.y();
//    int maxX = maxPos.x() + 1;
//    int maxY = maxPos.y() + 1;
//    for (int i = minX; i <= maxX; ++i)
//    {
//        for (int j = minY; j <= maxY; ++j)
//        {
    for (std::vector<Eigen::Vector3i>::iterator it = miniBounding.begin(); it != miniBounding.end(); ++it)
    {
        int j = it->x();

        for (int i = it->y(); i <= it->z(); ++i)
        {
            hasSet = false;

            // Calculate pixel depth
            p.x() = float(i);
            p.y() = float(j);

            auto[alpha, beta, gamma] = computeBarycentric2D(p.x()+0.5f, p.y()+0.5f, t.v);
            float w_reciprocal = 1.0/(alpha / v[0].w() + beta / v[1].w() + gamma / v[2].w());
            float z_interpolated = alpha * v[0].z() / v[0].w() + beta * v[1].z() / v[1].w() + gamma * v[2].z() / v[2].w();
            z_interpolated *= w_reciprocal;
            p.z() = z_interpolated;

            // MSAA depth, color
            // --------------------------------------------------
            for (int row = 0; row < msaa_row_num; ++row)
            {
                for (int col = 0; col < msaa_col_num; ++col)
                {
                    if (!insideTriangle(i+0.25f+(0.5f*col), j+0.25f+(0.5f*row), t.v))
                    {
                        continue;
                    }

                    // set mass color
                    set_msaa_pixel(i, j, col, row, p.z(), t.getColor());

                    hasSet = true;
                }
            }

            if (!hasSet)
            {
                continue;
            }

            //if (!insideTriangle(i+0.5f, j+0.5f, t.v))
            //{
            //    continue;
            //}

            // get mass color
            get_msaa_pixel(i, j, c);

            set_pixel(p, c);
        }
    }
}

void rst::rasterizer::cal_mini_bounding(const Triangle& t, const Eigen::Vector3f& minPos,
                                        const Eigen::Vector3f& maxPos, std::vector<Eigen::Vector3i>& miniBounding)
{
    int minX = 0;
    int maxX = 0;

    int num = int(maxPos.y() - minPos.x()) + 1;
    for (int i = 0, y = minPos.y(); i < num; ++i)
    {
        Eigen::Vector3i p = {y + i, INT_MAX, INT_MIN};      // {y, min_x, max_x}
        for(int m = 0; m < 3; ++m)
        {
            int n = (m + 1) % 3;

            const Eigen::Vector3f& a = t.v[m];
            const Eigen::Vector3f& b = t.v[n];

            float dx = a.x() - b.x();
            float dy = a.y() - b.y();

            if (0.f == dy)
            {
                if (p.x() == (int)a.y())
                {
                    if (a.x() < p.y()) p.y() = a.x();
                    if (b.x() < p.y()) p.y() = b.x();

                    if ((int)a.x() > p.z()) p.z() = a.x();
                    if ((int)b.x() > p.z()) p.z() = b.x();
                }

                continue;
            }

            minX = a.y() < b.y() ? a.y() : b.y();
            maxX = a.y() > b.y() ? a.y() : b.y();

            if (0.f == dx)
            {
                if ((p.x() < minX) || (p.x() > maxX))
                {
                    continue;
                }

                if (a.x() < p.y()) p.y() = a.x();
                if ((int)a.x() > p.z()) p.z() = a.x();

                continue;
            }

            if ((p.x() < minX) || (p.x() > maxX))
            {
                continue;
            }

            const Eigen::Vector3f* left = a.x() < b.x()? &a: &b;
            float x = left->x()+((p.x()+0.5f)-left->y())*(dx/dy);
            if (x < p.y()) p.y() = x;
            if ((int)x > p.z()) p.z() = x;
        }

        miniBounding.push_back(p);
    }
}

void rst::rasterizer::set_model(const Eigen::Matrix4f& m)
{
    model = m;
}

void rst::rasterizer::set_view(const Eigen::Matrix4f& v)
{
    view = v;
}

void rst::rasterizer::set_projection(const Eigen::Matrix4f& p)
{
    projection = p;
}

void rst::rasterizer::clear(rst::Buffers buff)
{
    if ((buff & rst::Buffers::Color) == rst::Buffers::Color)
    {
        memcpy(frame_buf, frame_init_buf, buf_len);

        memset(msaa_frame_buf, 0, sizeof(int) * buf_len * msaa_density);

        // position 0 for background color
        cache_color_num = 1;
        cache_color_buf[0] = {0.f, 0.f, 0.f};
    }

    if ((buff & rst::Buffers::Depth) == rst::Buffers::Depth)
    {
        memcpy(depth_buf, depth_init_buf, sizeof(float)*buf_len);

        for (int i = 0, offset = 0, cpysize = sizeof(float) * buf_len; i < msaa_density; ++i, offset+=buf_len)
        {
            memcpy(&msaa_depth_buf[offset], depth_init_buf, cpysize);
        }
    }
}

rst::rasterizer::rasterizer(int w, int h) : width(w), height(h)
{
    buf_len = w * h;
    NEW_BUF(frame_buf, Eigen::Vector3f, buf_len);
    NEW_BUF(depth_buf, float, buf_len);

    msaa_buf_len = buf_len * msaa_density;
    NEW_BUF(msaa_frame_buf, int, msaa_buf_len);
    NEW_BUF(msaa_depth_buf, float, msaa_buf_len);

    NEW_BUF(cache_color_buf, Eigen::Vector3f, cache_color_len);

    NEW_BUF(frame_init_buf, Eigen::Vector3f, buf_len);
    NEW_BUF(depth_init_buf, float, buf_len);

    // depth init value
    Eigen::Vector3f frameVal = {0, 0, 0};
    float           depthVal = std::numeric_limits<float>::infinity();
    for(int i = 0; i < buf_len; ++i)
    {
        frame_init_buf[i] = frameVal;
        depth_init_buf[i] = depthVal;
    }

    std::cout << "buf_len:" << buf_len << ", msaa_buf_len:" << msaa_buf_len << '\n';
}

rst::rasterizer::~rasterizer()
{
    DEL_BUF(frame_buf);
    DEL_BUF(depth_buf);

    DEL_BUF(msaa_frame_buf);
    DEL_BUF(msaa_depth_buf);

    DEL_BUF(cache_color_buf);

    DEL_BUF(frame_init_buf);
    DEL_BUF(depth_init_buf);
}


int rst::rasterizer::get_index(int x, int y)
{
    return (height-y)*width + x;
}

void rst::rasterizer::set_pixel(const Eigen::Vector3f& point, const Eigen::Vector3f& color)
{
    //old index: auto ind = point.y() + point.x() * width;
    int ind = (height-1-point.y())*width + point.x();

//    assert((ind >= 0) && (ind < (height * width)));
//    if (point.z() > depth_buf[ind])
//    {
//        return;
//    }

    frame_buf[ind] = color;
    depth_buf[ind] = point.z();
}

void rst::rasterizer::set_msaa_pixel(int x, int y, int col, int row, float z, const Eigen::Vector3f& color)
{
    int offset = col | (row<<1);
    int ind = (height-1-y) * (width*msaa_density) + (x*msaa_density) + offset;

    if (z > msaa_depth_buf[ind])
    {
        return;
    }

    msaa_frame_buf[ind] = get_mass_color_idx(color);
    msaa_depth_buf[ind] = z;
}

void rst::rasterizer::get_msaa_pixel(int x, int y, Eigen::Vector3f& color)
{
    int ind = (height-1-y) * (width*msaa_density) + (x*msaa_density);

    color.setZero();
    for (int i = 0; i < msaa_density; ++i)
    {
        int colorIdx = msaa_frame_buf[ind+i];
        color += cache_color_buf[colorIdx];
    }

    color /= msaa_density;
}

int rst::rasterizer::get_mass_color_idx(const Eigen::Vector3f& color)
{
    for (int i = 0; i < cache_color_num; ++i)
    {
        if ((color.x() == cache_color_buf[i].x()) &&
            (color.y() == cache_color_buf[i].y()) &&
            (color.z() == cache_color_buf[i].z()))
        {
            return i;
        }
    }

    int idx = 0;
    if (cache_color_num < cache_color_len)
    {
        idx = cache_color_num;
        cache_color_buf[cache_color_num++] = color;
    }

    return idx;
}

// clang-format on