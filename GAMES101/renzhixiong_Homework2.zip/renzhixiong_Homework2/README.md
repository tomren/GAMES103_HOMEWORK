#### 完成提高部分

```
判断点是否在三角形内
insideTriangle

计算三角形的最小包围，为了加速计算
cal_mini_bounding

设置 msaa 坐标下的像素颜色和深度
set_msaa_pixel

获得 msaa 下，对应像素的颜色加权值
get_msaa_pixel

查找 msaa 颜色缓存的下标值
get_mass_color_idx
```