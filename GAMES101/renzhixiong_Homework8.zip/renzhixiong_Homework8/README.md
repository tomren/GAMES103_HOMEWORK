## 完成内容

- 完成构造绳子
- 完成半隐式欧拉法
- 完成显式欧拉法
- 完成显式 Verlet 
- 完成阻尼

## 样例

#### 显式欧拉法
##### steps_per_frame 4096
![](images\01.png) 
![](images\02.png) 
##### steps_per_frame 8192
![](images\03.png) 

#### 半隐式欧拉法
##### steps_per_frame 1024
![](images\04.png) 

#### Verlet
##### steps_per_frame 1024
![](images\05.png)
#### 欧拉法 和 Verlet
##### steps_per_frame 1024
![](images\06.png)
![](images\07.png)
![](images\08.png)

