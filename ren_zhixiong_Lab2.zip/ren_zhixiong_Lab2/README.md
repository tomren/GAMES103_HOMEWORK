# GAMES103 Lab2
ren zhixiong

## 完成内容
1. 完成 Implicit Cloth Solver (with Chebyshev)算法
2. 完成 Position-Based Dynamics (PBD) 算法
## 额外完成
3. 完成 Newton-Raphson 算法 newton_model.cs
4. 完成 Jacobi 算法 (with Chebyshev) jacobi_model.cs
5. 完成 Conjugate Gradient 算法 conjugate_gradient_model.cs
6. 完成 Projective Dynamics 算法 projective_dynamics_model.cs

## 使用控件
用于解线性方程

添加 NuGetForUnity https://github.com/GlitchEnzo/NuGetForUnity

添加 MathNet.Numberics.4.15.0

## 函数调整
### 添加 mesh_helper 文件
1. 碰撞处理 Collision_Handling 移动到此文件
2. ResizeMesh 等函数移动到此文件
    - Quick_Sort
    - Quick_Sort_Partition
    - Swap

### 添加 calc_helper 文件
1. 计算合力 CalcForce
2. 计算 $XX^T$
3. 计算 Hessian 矩阵

## 1. Implicit Cloth Solver
### 测试部分
1. 不初始化 $X_i$ 猜测值，收敛变慢
2. 通过 isChebyshev 变量控制是否使用 Chebyshev 加速
     - 默认的 rho = 0.995f 不稳定， 需要改小到 0.95 左右
3. 使用 Chebyshev 加速后，布料初始下落明显加快了

![avatar](./images/implicit_chebyshev.png)

### 参数设置
1. t = 0.0333
2. spring_k = 8000
3. 迭代求解次数 32

<table border="0">
    <tr>
        <td align='center'>Implicit Cloth Solver 算法</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/implicit.gif' width='100%' hight='100%'/></td>
    </tr>
    <tr>
        <td align='center'> Chebyshev Acceleration 不稳定状态</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/implicit_chebyshev.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 2. PBD
### 参数设置
1. t = 0.0333
2. 迭代求解次数 32
<table border="0">
    <tr>
        <td align='center'><img src='./images/pbd.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 3. Newton-Raphson 算法
### 参数设置
1. 由于 A 的 Inverse 求解速度慢，所以只生成了 5x5 的定点网格
2. t = 0.0333
3. spring_k = 1000
4. 迭代求解次数 5
<table border="0">
    <tr>
        <td align='center'><img src='./images/newton.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 4. Jacobi 算法
### 参数设置
1. t = 0.0222
2. spring_k = 500
3. 定点个数 11x11
4. 迭代求解次数 8
### 使用 Chebyshev 参数设置
1. t = 0.015
2. spring_k = 400
3. 定点个数 11x11
4. 迭代求解次数 8

<table border="0">
    <tr>
        <td align='center'>Implicit Cloth Solver 算法</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/jacobi.gif' width='100%' hight='100%'/></td>
    </tr>
    <tr>
        <td align='center'> Chebyshev Acceleration 不稳定状态所以步长调小了</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/jacobi_chebyshev.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 5. Conjugate Gradient 算法
### 参数设置
1. t = 0.0222
2. spring_k = 500
3. 定点个数 11x11
4. 迭代求解次数 10
<table border="0">
    <tr>
        <td align='center'><img src='./images/conjugate_gradient.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 6. Projective Dynamics 算法
由于不是很稳定，所以设置的参数比较小
### 参数设置
1. t = 0.015
2. spring_k = 500
3. 定点个数 5x5
4. 迭代求解次数 5
<table border="0">
    <tr>
        <td align='center'><img src='./images/projective_dynamics.gif' width='100%' hight='100%'/></td>
    </tr>
</table>
