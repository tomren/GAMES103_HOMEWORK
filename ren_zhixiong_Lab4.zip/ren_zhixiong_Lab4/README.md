# GAMES103 Lab4
ren zhixiong

## 完成内容
1. Basic Tasks
2. Bonus Tasks

## 水面网格
网格划分为斜纹和米字型两种，米字型的网格在表现水波时效果更好

<table border="0">
	<tr>
		<td align='center'>Slash Grid</td>
		<td align='center'>Mi Grid</td>
	</tr>
	<tr>
		<td align='center'><img src='./images/slash_grid.png' width='128' hight='128'/></td>
		<td align='center'><img src='./images/mi_grid.png' width='128' hight='128'/></td>
	</tr>
    <tr>
		<td align='center'>Slash Grid</td>
		<td align='center'>Mi Grid</td>
	</tr>
    <tr>
		<td align='center'><img src='./images/slash_wave.png' width='500' hight='500'/></td>
		<td align='center'><img src='./images/mi_wave.png' width='500' hight='500'/></td>
	</tr>
</table>

## 碰撞检测
将平面网格划分成2D的BVH，将Cube与BVH做碰撞求交，然后发出射线测试高度

## 实验效果
<table border="0">
    <tr>
        <td align='center'><img src='./images/wave.gif' width='100%' hight='100%'/></td>
    </tr>
</table>