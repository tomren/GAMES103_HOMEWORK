# GAMES103 Lab3
ren zhixiong

## 完成内容
1. Basic Tasks
2. Bonus Tasks
## 额外完成内容
1. Neo Hookean 王老师PPT公式
2. Neo Hookean 知乎公式
3. Neo Hookean wiki公式
4. Mooney Rivlin 王老师PPT公式
5. Mooney Rivlin wiki公式
6. Fung 王老师PPT公式

## 使用控件
NuGetForUnity https://github.com/GlitchEnzo/NuGetForUnity

添加 Accord.Math 3.8.0

![avatar](./images/accord.png)


## 文件说明
- FVM.cs 主体问题件
- Hyperelastic.cs 超弹性函数

FVM 中可选择弹性类型和开启平滑

![avatar](./images/fvm.png)

# Cauchy-Green
$$
\begin{aligned}
I_c&=tr(C) = \lambda_0^2 + \lambda_1^2 +\lambda_2^2\\
II_c&=tr(C^2) =\lambda_0^4 + \lambda_1^4 +\lambda_2^4\\
III_c&=det(C)) =\lambda_0^2\lambda_1^2\lambda_2^2\\
\end{aligned}
$$

# 1. FVM 算法
$$
\begin{aligned}
Dm&=[X_{10}\;X_{20}\;X_{30}]\\
F&=[x_{10}\;x_{20}\;x_{30}]D_m^{-1}\\
G&=\frac{1}{2}(F^TF-I)\\
P&=F\frac{\partial{w}}{\partial{G}}\\
[f_{1}\;f_{2}\;f_{3}]&=-\frac{1}{6det(D_m^{-1})}PD_m^{-T}\\
f_0&=-f_1-f_2-f_3
\end{aligned}
$$

<table border="0">
    <tr>
        <td align='center'>FVM</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/fvm.gif' width='100%' hight='100%'/></td>
    </tr>
    <tr>
        <td align='center'>FVM Smooth</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/fvm_smooth.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

# 2. Hyperelastic Models
$$
\begin{aligned}
Dm&=[X_{10}\;X_{20}\;X_{30}]\\
F&=[x_{10}\;x_{20}\;x_{30}]D_m^{-1}\\
[U\;\Lambda\;V^T]&=svd(F)\\
P&=Udiag(\frac{\partial{w}}{\partial{\lambda_0}},\frac{\partial{w}}{\partial{\lambda_1}},\frac{\partial{w}}{\partial{\lambda_2}})V^T\\
[f_{1}\;f_{2}\;f_{3}]&=-\frac{1}{6det(D_m^{-1})}PD_m^{-T}\\
f_0&=-f_1-f_2-f_3
\end{aligned}
$$

## 1. The Saint Venant-Kirchhoff model (StVK) 王老师PPT的公式
$$
W = \frac{s_0}{2}(I_c-3)^2+\frac{s_1}{4}(II_c-2I_c+3)
$$
### Matrix Calculus
```
S0/2*(L0^2+L1^2+L2^2-3)^2+S1/4*((L0^2*L1^2+L0^2*L2^2+L1^2*L2^2)-2*(L0^2+L1^2+L2^2)+3)
```
$$
\begin{aligned}
\frac{\partial{w}}{\partial{\lambda_0}} &= \frac{\partial f}{\partial \lambda_0} = (4\cdot \lambda_0\cdot s0\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}-3))/2+(2\cdot \lambda_0\cdot s1\cdot \lambda_1^{2})/4+(2\cdot \lambda_0\cdot s1\cdot \lambda_2^{2})/4-\lambda_0\cdot s1\\
\frac{\partial{w}}{\partial{\lambda_1}} &= \frac{\partial f}{\partial \lambda_1} = (4\cdot \lambda_1\cdot s0\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}-3))/2+(2\cdot \lambda_1\cdot s1\cdot \lambda_0^{2})/4+(2\cdot \lambda_1\cdot s1\cdot \lambda_2^{2})/4-\lambda_1\cdot s1\\
\frac{\partial{w}}{\partial{\lambda_2}} &= \frac{\partial f}{\partial \lambda_2} = (4\cdot \lambda_2\cdot s0\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}-3))/2+(2\cdot \lambda_2\cdot s1\cdot \lambda_0^{2})/4+(2\cdot \lambda_2\cdot s1\cdot \lambda_1^{2})/4-\lambda_2\cdot s1
\end{aligned}
$$

<table border="0">
    <tr>
        <td align='center'>Stvk</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/stvk.gif' width='100%' hight='100%'/></td>
    </tr>
    <tr>
        <td align='center'>Stvk Smooth</td>
    </tr>
    <tr>
        <td align='center'><img src='./images/stvk_smooth.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 2. The Neo-Hookean model 王老师PPT公式
$$
W = s_0(III_c^{-1/3}\cdot I-3)+s_1(III_c^{-1/2}-1)
$$
### Matrix Calculus
```
S0*((L0^2*L1^2*L2^2)^(-1/3)*(L0^2+L1^2+L2^2)-3)+S1*((L0^2*L1^2*L2^2)^(-1/2)-1)
```
$$

\begin{aligned}
\frac{\partial f}{\partial \lambda_0} &= 2\cdot \lambda_0\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_0^{-5/3}\cdot \lambda_1^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3-s1/(\lambda_1\cdot \lambda_2\cdot \lambda_0^{2})\\
\frac{\partial f}{\partial \lambda_1} &= 2\cdot \lambda_1\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_1^{-5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3-s1/(\lambda_0\cdot \lambda_2\cdot \lambda_1^{2})\\
\frac{\partial f}{\partial \lambda_2} &= 2\cdot \lambda_2\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_2^{-5/3)}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3-s1/(\lambda_0\cdot \lambda_1\cdot \lambda_2^{2})
\end{aligned}

$$

## 3. The Neo-Hookean model 知乎公式
```
https://zhuanlan.zhihu.com/p/270606841
```
$$
J = det(F) = \lambda_0 \lambda_1 \lambda_2\\
P = \mu(F-F^{-T})+\lambda log(J)F^{-T}
$$

<table border="0">
    <tr>
        <td align='center'><img src='./images/neo_zhihu.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 4. The Neo-Hookean model wiki公式
```
https://en.wikipedia.org/wiki/Neo-Hookean_solid
```
$$
\begin{aligned}
W&=C_1(I_1-3-2lnJ)+D_1(J-1)^2\\
I_1&=\lambda_1^2+\lambda_2^2+\lambda_3^2\\
J&=det(F)=\lambda_1\lambda_2\lambda_3\\
C_1&=\frac{\mu}{2}; D_1=\frac{k}{2}
\end{aligned}
$$

## 5. The Mooney-Rivlin model 王老师PPT公式
$$
W = s_0(III_c^{-1/3}I_c-3)+s_1(III_c^{-1/2}-1)+s_2(\frac{1}{2}III_c^{-2/3}(I_c^2-II_c)-3)
$$

### Matrix Calculus
```
S0*((L0^2*L1^2*L2^2)^(-1/3)*(L0^2+L1^2+L2^2)-3)+S1*((L0^2*L1^2*L2^2)^(-1/2)-1)+S2*((1/2)*(L0^2*L1^2*L2^2)^(-2/3)*((L0^2+L1^2+L2^2)^2-(L0^4+L1^4+L2^4))-3)
```

$$
\begin{aligned}
\frac{\partial W}{\partial \lambda_0} &= 2\cdot \lambda_0\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_0^{-5/3}\cdot \lambda_1^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&-s1/(\lambda_1\cdot \lambda_2\cdot \lambda_0^{2})-(4\cdot S2\cdot \lambda_0^{-7/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot ((\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})^{2}-(\lambda_0^{4}+\lambda_1^{4}+\lambda_2^{4})))/6\\
&+(4\cdot \lambda_0\cdot S2\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/2-(4\cdot S2\cdot \lambda_0^{3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3})/2\\
\frac{\partial W}{\partial \lambda_1} &= 2\cdot \lambda_1\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_1^{-5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&-s1/(\lambda_0\cdot \lambda_2\cdot \lambda_1^{2})-(4\cdot S2\cdot \lambda_1^{-7/3}\cdot \lambda_0^{-4/3}\cdot \lambda_2^{-4/3}\cdot ((\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})^{2}-(\lambda_0^{4}+\lambda_1^{4}+\lambda_2^{4})))/6\\
&+(4\cdot \lambda_1\cdot S2\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/2-(4\cdot S2\cdot \lambda_1^{3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3})/2\\
\frac{\partial W}{\partial \lambda_2} &= 2\cdot \lambda_2\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_2^{5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&-s1/(\lambda_0\cdot \lambda_1\cdot \lambda_2^{2})-(4\cdot S2\cdot \lambda_2^{-7/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot ((\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})^{2}-(\lambda_0^{4}+\lambda_1^{4}+\lambda_2^{4})))/6\\
&+(4\cdot \lambda_2\cdot S2\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/2-(4\cdot S2\cdot \lambda_2^{3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3})/2
\end{aligned}
$$

## 6. The Mooney-Rivlin model wiki公式
```
https://en.wikipedia.org/wiki/Mooney–Rivlin_solid
```

### Matrix Calculus
$$
\begin{align}
W&=C_1(J^{-2/3}I_1-3)+\frac{1}{D1}(J-1)^2\\
I_1&=\lambda_1^2+\lambda_2^2+\lambda_3^2\\
I_2&=\lambda_1^2\lambda_2^2+\lambda_2^2\lambda_3^2+\lambda_3^2\lambda_1^2\\
J&=det(F)=\lambda_1\lambda_2\lambda_3\\
C_1&=\frac{\mu}{2}; D_1=\frac{k}{2}
\end{align} 
$$

```
0.5*S0*((L0*L1*L2)^(-2/3)*(L0^2+L1^2+L2^2)-3)+(2/S1)*(L0*L1*L2-1)^2
```

$$
\begin{aligned}
\frac{\partial W}{\partial \lambda_0} &= \lambda_0\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\\
&-(s0\cdot \lambda_0^{-5/3}\cdot \lambda_1^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&+(4\cdot \lambda_1\cdot \lambda_2\cdot (\lambda_0\cdot \lambda_1\cdot \lambda_2-1))/s1\\
\frac{\partial W}{\partial \lambda_1} &= \lambda_1\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\\
&-(s0\cdot \lambda_1^{-5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&+(4\cdot \lambda_0\cdot \lambda_2\cdot (\lambda_0\cdot \lambda_1\cdot \lambda_2-1))/s1\\
\frac{\partial W}{\partial \lambda_2} &= \lambda_2\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\\
&-(s0\cdot \lambda_2^{-5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&+(4\cdot \lambda_0\cdot \lambda_1\cdot (\lambda_0\cdot \lambda_1\cdot \lambda_2-1))/s1
\end{aligned}
$$

<table border="0">
    <tr>
        <td align='center'><img src='./images/mr_wiki.gif' width='100%' hight='100%'/></td>
    </tr>
</table>

## 7. The Fung model 王老师PPT公式
$$
W = s_0(III_c^{-1/3}I_c-3)+s_1(III_c^{-1/2}-1)+s_2(e^{s3(III_c^{-1/3}I_c-3)}-1)
$$

### Matrix Calculus
```
S0*((L0^2*L1^2*L2^2)^(-1/3)*(L0^2+L1^2+L2^2)-3)+S1*((L0^2*L1^2*L2^2)^(-1/2)-1)+S2*(exp(s3*(L0^2*L1^2*L2^2)^(-2/3)*(L0^2+L1^2+L2^2)-3)-1)
```

$$
\begin{aligned}
\frac{\partial f}{\partial \lambda_0} &= 2\cdot \lambda_0\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_0^{-5/3}\cdot \lambda_1^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3-s1/(\lambda_1\cdot \lambda_2\cdot \lambda_0^{2})\\
&-(4\cdot S2\cdot s3\cdot \lambda_0^{-7/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot \exp(s3\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})-3)\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&+2\cdot \lambda_0\cdot S2\cdot s3\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \exp(s3\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})-3)\\
\frac{\partial f}{\partial \lambda_1} &= 2\cdot \lambda_1\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_1^{-5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_2^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3-s1/(\lambda_0\cdot \lambda_2\cdot \lambda_1^{2})\\
&-(4\cdot S2\cdot s3\cdot \lambda_1^{-7/3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \exp(s3\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})-3)\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&+2\cdot \lambda_1\cdot S2\cdot s3\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \exp(s3\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})-3)\\
\frac{\partial f}{\partial \lambda_2} &= 2\cdot \lambda_2\cdot s0\cdot \lambda_2^{-2/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}-(2\cdot s0\cdot \lambda_2^{-5/3}\cdot \lambda_0^{-2/3}\cdot \lambda_1^{-2/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3-s1/(\lambda_0\cdot \lambda_1\cdot \lambda_2^{2})\\
&-(4\cdot S2\cdot s3\cdot \lambda_2^{-7/3}\cdot \lambda_1^{-4/3}\cdot \lambda_0^{-4/3}\cdot \exp(s3\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})-3)\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2}))/3\\
&+2\cdot \lambda_2\cdot S2\cdot s3\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot \lambda_0^{-4/3}\cdot \exp(s3\cdot \lambda_0^{-4/3}\cdot \lambda_1^{-4/3}\cdot \lambda_2^{-4/3}\cdot (\lambda_0^{2}+\lambda_1^{2}+\lambda_2^{2})-3)
\end{aligned}
$$

<table border="0">
    <tr>
        <td align='center'><img src='./images/fung.gif' width='100%' hight='100%'/></td>
    </tr>
</table>